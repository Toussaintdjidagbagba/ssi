@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">S'inscrire</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('content')
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="text-center">
          @include('flash::message')
        </div>
      </div>

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Entrer un nouveau code de parrainage ou bénéficier celui de l'administrateur pour le reste de votre création</h1>
                  </div>
                  <form class="user" method="post" action="{{ route('valideParrain') }}">
                    {{ csrf_field() }}
                    
                    <input type="hidden" name="id1" value="{{ $id1 }}">
                     <input type="hidden" name="payerf" value="{{ $payerf }}">
                      <input type="hidden" name="position_actuel" value="{{ $position_actuel }}">
                      <input type="hidden" name="nom" value="{{ $nom }}">
                      <input type="hidden" name="prenom" value="{{ $prenom }}">
                      <input type="hidden" name="sexe" value="{{ $sexe }}">
                      <input type="hidden" name="tel" value="{{ $tel }}">
                      <input type="hidden" name="compteactive" value="{{ $compteactive }}">
                      <input type="hidden" name="mail" value="{{ $email }}">
                      <input type="hidden" name="password" value="{{ $password }}">
                      <input type="hidden" name="pseudo" value="{{ $pseudo }}">
                      <input type="hidden" name="moyendepayement" value="{{ $moyendepayement }}">
                      <input type="hidden" name="compteacreer" value="{{ $compteacreer }}">  
                    <div class="form-group">
                      <label>Code parrain <i style="color: red">*</i></label>
                    <input type="text" class="form-control" name="parrain" id="parrain" placeholder="Code de parrainage" data-original-title="Entrer votre Pays" /> 
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="parain" name="cocherparrain" value="Pas de code de parrainage.">
                      <label class="form-check-label" for="parain">Pas de code de parrainage.</label>
                    </div>
                    </div>

                                        
                    <button type="submit" class="btn btn-user btn-block" id="but">
                      <b>VALIDER</b>
                    </button>
                  
                  </form>
                  <hr>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection('content')