@extends('templatedste._temp')

@section('css')

    <!-- Bootstrap Select Css -->
    <link href="cssdste/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

@endsection

@section('content')

	<div class="container-fluid">
            <div class="block-header">
                <h2>
                    Tableau de bord
                    <small></small>
                </h2>
            </div>
            <div class="row clearfix">
                
            </div>
        </div>

@endsection

@section("model")


@endsection