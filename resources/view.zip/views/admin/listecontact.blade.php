@extends('layouts.template_admin')

@section('content')

<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des contacts
          </header> 

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th><i class="icon_ol"></i> Id</th>
                <th><i class="icon_pin_alt"></i> Nom</th>
                <th><i class="icon_pin_alt"></i> Téléphone</th>
                <th><i class="icon_pin_alt"></i> Statut</th>
                <th><i class="icon_pin_alt"></i> Message</th>
                <th><i class="icon_pin_alt"></i> Répondre</th>
              </tr>
              @forelse($contacts as $contact)
                <tr>
                  <td>{{ $contact->id }}</td>
                  <td>{{ $contact->Nom }}</td>
                  <td>{{ $contact->Tel }}</td>
                  <td>
                    @if($contact->Statut == "oui")
                        <i style="color: white; background-color: green">reponse envoyée</i>
                    @else
                        <i style="color: white; background-color: red">en attente</i> 
                    @endif
                  </td>
                  <td>{{ $contact->Message}}</td>
                  <td>
                  	<form action="{{route('listecontactS')}}" method="post">
                      {{ csrf_field() }}
                  		<input type="hidden" name="id" value="{{$contact->id}}">
                  		<input type="hidden" name="email" value="{{$contact->Email}}">
                      <input type="hidden" name="message" value="{{$contact->Message}}">
                  		<input type="submit" name="repondre" value="Répondre">
                  	</form>
                  </td>
                  
                  
                </tr>
              @empty
                <tr >
                  <td colspan="6" style="text-align: center;">Pas de message disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>

@endsection