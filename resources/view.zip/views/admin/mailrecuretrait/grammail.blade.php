    	<body style="background: #e5e5e5; padding: 30px;" >

		<div style="max-width: 650px; width: 500px; margin: 0 auto; padding: 20px; background: #fff;">
			<table>
						<tr style="border: 1px solid white;">
							
							<td style="text-align: right; width: 20%">
								<img src="https://sourcedusuccesinternational.com/logo.jpeg" style="width: 80px; height: 120px; margin-top: -80px">
							</td>
							<td style="text-align: left; width: 50%">
								<center> <h1 style="color : #25599C; margin-left: 10px;">La Source du Succès International</h1> </center>
							</td>
							<td style=" width: 20%">
								<img src="https://sourcedusuccesinternational.com/img/gram.jpg" style="width: 100px; height: 120px; margin-top: -80px">
							</td>
							
						</tr>
					</table>
			<div style="background-image: ; margin-top: 20px; max-height: 600px; height: 350px; width: 100%">
					<table>
						<tr style="border: 1px solid white;">
							<td style="text-align: left; width: 50%; font-size: 16px; text-align: justify;text-justify: auto;">
							    <b> Objet : {{ $objet }} </b> <br> <br>
								<br> Numéro reçu : {{$reff}} </b> <br> <br>
								Un retrait de {{$montant }} $ SSI / {{$montantf }} F CFA a été effectué ce 
								{{$datevalider}} du compte de {{$nom}} {{$prenom}} résidant à {{$ville}}; {{$pays}}; {{$adresse}} pour {{$motif}}.
								
							</td>
							
						</tr>
					</table>
				<br><br>
				<div style="font-size: 16px; text-align: justify;text-justify: auto;">

					<center>Merci d'avoir choisi la SSI, la plateforme qui vous facilite la vie. <br> <br> 
						Votre satisfaction, notre priorité.
					</center>
				</div>
			</div>
		</div>

		</body>