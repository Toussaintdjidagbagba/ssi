<!--sidebar start-->
<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu">
      <li class="active">
        <a class="" href="{{ route('admin.dashboard') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Tableau de bord</span>
        </a>
      </li>

      <li class="sub-menu">
        <a href="{{ route('admin.index') }}" class="">
            <i class="fas fa-globe"></i>
            <span>Aller au SITE</span>
        </a>
      </li>      

      <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="fas fa-fw fa-cog"></i>
            <span>Configuration</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
            <li><a class="" href="{{ route('coursG') }}">Ajouter un cours</a></li>
            <li><a href="{{ route('nouveaufilleulG') }}">Ajouter un filleul</a></li>
            <li><a href="{{ route('admin.active') }}">Activer compte filleul</a></li>
        </ul>
      </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Opération MLM</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('transfertadmin') }}">Transfert de fond</a></li>
                <li><a class="" href="{{ route('prelevement') }}">Prélever des fonds</a></li>
                <li><a class="" href="{{ route('transfertadminCV') }}">VTE</a></li>
                <li><a class="" href="{{ route('prelevementCV') }}">VPE</a></li>
                <li><a class="" href="{{ route('transfertgainvirtuel') }}">GVTE</a></li>
                <li><a class="" href="{{ route('prelevementgainvirtuel') }}">GVPE</a></li>
                <li><a class="" href="{{ route('histadmin') }}" title="Historique de translation">H T</a></li>
                <li><a class="" href="{{ route('histadminclient') }}" title="Historique de translation Client">H T C</a></li>
                
            </ul>
        </li>
        
        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Service SSI</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('sonebservice') }}">Service SONEB</a></li>
                <li><a class="" href="{{ route('sbeeconventionnelservice') }}">Service SBEE FACTURE</a></li>
                <li><a class="" href="{{ route('sbeecarteservice') }}">Service SBEE À CARTE</a></li>
                <li><a class="" href="{{ route('canalservice') }}">Service CANAL+</a></li>
                <li><a class="" href="{{ route('achat$ssi') }}">Achat Gain</a></li>
                <!--li><a class="" href="{{ route('longrichservice') }}">Service Longrich</a></li-->
                <!--li><a class="" href="{{ route('healthservice') }}">Service H&W </a></li-->
                <li><a class="" href="{{ route('mtnmoovservice') }}">Service MTN / MOOV </a></li>
                <li><a class="" href="{{ route('getSRVISA') }}">Service VISA </a></li>
            </ul>
        </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Demande retrait</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('retraitmtn') }}">Retrait MTN</a></li>
                <li><a class="" href="{{ route('retraitmoov') }}">Retrait MOOV</a></li>
                <li><a class="" href="{{ route('retraitgram') }}">Retrait MONEY GRAM</a></li>
                <li><a class="" href="{{ route('retraitperfect') }}">Retrait PERFECT MONEY</a></li>
                <li><a class="" href="{{ route('retraittrust') }}">Retrait TRUST WALLET</a></li>
                <li><a class="" href="{{ route('retraitwestern') }}">Retrait WESTERN UNION </a></li>
            </ul>
        </li>

       <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="icon_cog"></i>
            <span>Paramètres</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
          <li><a class="" href="{{ route('profiladmin') }}">Profil</a></li>
          <li><a class="" href="{{ route('galerieG')}}">Ajouter d'image</a></li>
          <li><a class="" href="{{ route('evernementG') }}">Créer Conférence</a></li>
          <li><a class="" href="{{ route('listecontact') }}">Liste des contacts</a></li>
        </ul>
      </li>

    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>
<!--sidebar end-->
