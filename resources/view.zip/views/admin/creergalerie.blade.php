@extends('layouts.template_admin')

@section('css')
	
	<style type="text/css">
		#sidebar_right
		{
		    background-color: #f0f8ff;
		    border-bottom: 1px solid #688a7e !important;
		    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.176) !important;
		    
		}

		#link{
		    color: #65BBD6;
		}
		.bg-link
		{
			background-color: #65BBD6;
			color: white; 
		}
	</style>

@endsection

@section('content')

	<!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Creer Galerie</h1>
    </div>
	<hr>
    <!-- Content Row -->
    <div class="col-lg-12">
    	<div class="row">
	    	<div class="col-lg-9">
			      <div class="modal-content">
			        <div class="modal-header">
			       
			          <h4 class="modal-title">Ajouter une image</h4>
			        </div>
			        <div class="modal-body">

			          <form role="form" method="post" enctype="multipart/form-data" action="{{ route('galerieS')}}">
			            {{ csrf_field() }}
			            <div class="form-group">
			              <label for="titre">Nom de l'image (<i style="color: red">*</i>)</label>
			              <input type="text" class="form-control" id="titre" name="titre" placeholder="Titre de l'image" value="{{ old('titre') }}" autofocus autocomplete>
			              @if($errors->has('titre'))
		                      <p style="color: red">{{ $errors->first('titre') }}</p>
		                  @endif
			            </div>

			            <div class="form-group">
			              <label for="cours">Choisissez votre image (<i style="color: red">*</i>)</label>
			              <input type="file" class="form-control" id="document" name="img" >
			            	@if($errors->has('img'))
		                      <p style="color: red">{{ $errors->first('img') }}</p>
		                  	@endif
			            </div>

			            <button type="submit" class="btn btn-primary">Valider</button>  
			          </form>

			        </div>
			      </div>
	    	</div>
	    	
      	</div>
	</div>        		
@endsection