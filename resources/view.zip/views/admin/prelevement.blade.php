@extends('layouts.template_admin')

@section('css') 
  <!-- Custom fonts for this template -->
  <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="{{asset('css/clean-blog.min.css')}}" rel="stylesheet">
  <link href="{{asset('css/mlm.css')}}" rel="stylesheet">
  
@endsection

 
@section('content')
  <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Profil</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        
      </div>

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  <div class="text-center">
                    @include('flash::message')
                  </div>
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Prélever du compte client</h1>
                  </div>
                  <form class="user" method="post" action="{{ route('prelevementS') }}">
                    {{ csrf_field() }}
                     
                    <div class="form-group">
                      <input type="number" class="form-control form-control-user" placeholder="Entrez identifiant du destinataire" name="id">
                      @if($errors->has('id'))
                        <p style="color: red"> {{ $errors->first('id') }}</p>
                      @endif
                    </div>

                     <div class="form-group">
                      <input type="number" step="0.00001" class="form-control form-control-user"  placeholder="Entrez le montant" name="montant">
                      @if($errors->has('montant'))
                        <p style="color: red"> {{ $errors->first('montant') }}</p>
                      @endif
                    </div>

                    
                    
                    <button type="submit" class="btn btn-user btn-block" id="but">
                      <b>PRELEVER</b>
                    </button>
                  
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection