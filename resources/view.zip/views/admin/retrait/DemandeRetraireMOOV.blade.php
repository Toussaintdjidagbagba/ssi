@extends('layouts.template_admin')

@section('css')
  <!-- Custom fonts for this template -->
  <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="{{asset('css/clean-blog.min.css')}}" rel="stylesheet">
  <link href="{{asset('css/mlm.css')}}" rel="stylesheet">

  <style type="text/css">
    .carre{
      width: 200px;
      height: 200px;
      text-align: center;
      color: white;
    }

    .arrondi{
      border-radius: 50%;
      line-height: 100px;
      
    }
  </style>
  
@endsection

@section('content')


<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des demandes de retraire sur mobile money MOOV
          </header> 
          <div class="text-center">
                @include('flash::message')
          </div>
          <table  class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th><i class="icon_ol"></i> Référence No </th> 
                <th><i class="icon_pin_alt"></i> Motif </th>
                <th><i class="icon_pin_alt"></i> Numéro </th>
                <th><i class="icon_pin_alt"></i> Montant </th>
                <th><i class="icon_pin_alt"></i> Identifiant <br> Filleul</th>
                <th><i class="icon_pin_alt"></i> Envoyer le</th>
                <th><i class="icon_pin_alt"></i> Délivré recu</th>
				<th><i class="icon_pin_alt"></i> Délivré le</th>
                <th><i class="icon_pin_alt"></i> Statut</th>
                <th><i class="icon_pin_alt"></i> Action</th>
              </tr>
              @forelse($demandes as $demande)
                <tr>
                  <td>{{ $demande->reff }}</td>
                  <td>{{ $demande->intitule }}</td>
                  <td>{{ $demande->numero }}</td>
                  <td> {{ $demande->montant }} $ SSI</td>
                  <td> {{ $demande->codeperso }} </td>
                  <td>{{ $demande->created_at }}</td>
				  
                  <td> <a href="/moov-recu:reference-{{ $demande->reff }}">Etablir recu</a> </td>
                  <td>{{ $demande->datevalider }}</td>
				  <td>
                    @if($demande->statut == "oui")
                        <i style="color: white; background-color: green">recu envoyée</i>
                    @else
                        <i style="color: white; background-color: red">en attente</i> 
                    @endif
                  </td>
                  <td> 
                    <a class="btn btn-outline-primary btn-circle btn-icon" 
                          style="color:red;font-weight:bold;" 
                          href="{{url('admin/delete-demanderetraitmoov-'.$demande->reff)}}">
                      <i class="fa fa-trash"></i>Supprimer 
                    </a>
                  </td>     
                </tr>
              @empty
                <tr >
                  <td colspan="9" style="text-align: center;">Pas de demande disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </section>
      </div>
    </div>

@endsection