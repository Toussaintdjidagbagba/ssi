@extends('layouts.template_admin')

@section('meta')
    <meta http-equiv="refresh" content="15">
@endsection

@section('content')
    <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Tableau de bord</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
        
        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('canalservice') }}">
        <div class="info-box" style="background-color: #86dad8">
          <div class="count">
            
              {{ $ncanals }} en attente
           

          </div>
          <div class="title">SERVICE CANAL+</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('mtnmoovservice') }}">
        <div class="info-box" style="background-color: #ac7397">
          <div class="count">
            
              {{ $nmtnmoovs }} en attente
           

          </div>
          <div class="title">SERVICE MTN et MOOV</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('achat$ssi') }}">
        <div class="info-box" style="background-color: #3dca90">
          <div class="count">
            
              {{ $nachats }} en attente
           

          </div>
          <div class="title">SERVICE Achat de gain</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('getSRVISA') }}">
        <div class="info-box" style="background-color: #000">
          <div class="count">
            {{ $nvisas }} en attente
          </div>
          <div class="title">SERVICE VISA</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('sbeecarteservice') }}">
        <div class="info-box" style="background-color: #884758">
          <div class="count">
            
              {{ $nbeecartes }} en attente
           

          </div>
          <div class="title">SERVICE SBEE CARTE</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('sbeeconventionnelservice') }}">
        <div class="info-box" style="background-color: #ebaf4c">
          <div class="count">
            
              {{ $nbeeconventiels }} en attente 
           

          </div>
          <div class="title">SERVICE SBEE FACTURE</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('sonebservice') }}">
        <div class="info-box" style="background-color: #00ff">
          <div class="count">
            
              {{ $nsonebs }} en attente
           

          </div>
          <div class="title">SERVICE SONEB</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraitmtn') }}">
        <div class="info-box" style="background-color: #dbab5c">
          <div class="count">
         {{$nmtns }} en attente
          </div>
          <div class="title">DEMANDE RETRAIT MTN</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
        
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraitmoov') }}">
        <div class="info-box" style="background-color: #ac7397">
          <div class="count">
            {{$nmoovs }} en attente
          </div>
          <div class="title">DEMANDE RETRAIT MOOV</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraitwestern') }}">
        <div class="info-box" style="background-color: #3dca90">
          <div class="count">
            {{$nwesterns }} en attente
          </div>
          <div class="title">DEMANDE RETRAIT WESTERN UNION</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraitperfect') }}">
        <div class="info-box" style="background-color: #884758">
          <div class="count">
           {{$nperfects }} en attente
          </div>
          <div class="title">DEMANDE RETRAIT PERFECT MONEY</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraitgram') }}">
        <div class="info-box" style="background-color: #86dad8">
          <div class="count">
           {{$ngrams }} en attente
          </div>
          <div class="title">DEMANDE RETRAIT MONEY GRAM</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="{{ route('retraittrust') }}">
        <div class="info-box" style="background-color: #dbab5c">
          <div class="count">
           {{$ntrusts}} en attente
          </div>
          <div class="title">DEMANDE RETRAIT TRUST WALLET</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
        
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="#">
        <div class="info-box blue-bg">
          <div class="count">{{ $compterecu[0]->compteavoirrecu }} $ SSI</div>
          <div class="title">GAIN RECOLTER</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-item">
          <a href="#">
        <div class="info-box brown-bg">
            <div class="count">{{ $compterecu[0]->compteavoirsortant }} $ SSI </div>
          <div class="title">GAIN DEBITER</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->
      
      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itemb">
          <a href="#">
        <div class="info-box" style="background-color: #838B8B">
          <div class="count">
            
                0 $ SSI
            
          </div>
          <div class="title">Commission sur vente</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>

        <!--
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 at-itemb">
          <a href="#">
        <div class="info-box " style="background-color: #CDB79E">
          <div class="count">
            
                0 $ SSI
            
          </div>
          <div class="title">Gain en nature</div>
        </div>
          </a>
        /.info-box
      </div>-->


      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-item">
          <a href="{{ route('listclient') }}">
        <div class="info-box dark-bg">
          <div class="count">{{ $all }} </div>
          <div class="title">NOMBRE DE CLIENT</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 at-itema">
          <a href="{{ route('nouveaufilleulG') }}">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px">{{$filleuladmin[0]->nombredefilleul}} </div> </div>
          <div class="title">Ajouter un filleul</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

    </div>
    <!--/.row-->
    <div class="horizontal-scrollable">
    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des filleuls utilisant le code du système
          </header> 

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr style="font-size: 12px">
                <th style="text-align: center;"><i class="icon_ol"></i> Nom & Prénom Filleul</th>
                
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Code de parrainage du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Identifiant du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Statut</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Parrain du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Inscrire le</th>
              </tr>
              @forelse($filleuls as $filleul)
                <tr style="text-align: center;">
                  <td>{{ $filleul->nom }} {{ $filleul->prenom }}</td>
                  
                  <td>{{ $filleul->codeunique }}</td>
                  <td>{{ $filleul->codeperso}}</td>
                  <td>
                    @if($filleul->compteactive == "oui")
                        <i style="color: white; background-color: green">actif</i>
                    @else
                        <i style="color: white; background-color: red">inactif</i> 
                    @endif
                  </td>
                  <td>{{ $filleul->parrain }}</td>
                  <td>{{ $filleul->created_at}}</td>
                </tr>
              @empty
                <tr >
                  <td colspan="6" style="text-align: center;">Pas de Filleul disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div> </div>

@endsection