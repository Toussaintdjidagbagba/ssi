@extends('layouts.template_client')

@section('css')
  <!-- Custom fonts for this template -->
  <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="{{asset('css/clean-blog.min.css')}}" rel="stylesheet">
  <link href="{{asset('css/mlm.css')}}" rel="stylesheet">

  <style type="text/css">
    .carre{
      width: 200px;
      height: 200px;
      
      text-align: center;
      color: white;
    }

    .arrondi{
      border-radius: 50%;
      line-height: 100px;
      
    }
  </style>
  
@endsection

@section('content')
	<div class="container">

    <div class="">
      <div class="">
          
          <!-- Titre -->
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Retrait de fond</h1>
              </div>
   
              <div class="text-center">
                @include('flash::message')
              </div>
        
        <!-- Nested Row within Card Body -->
        <div class="" style="padding-left : 20%; padding-right : 20%; padding-top : -5%">
          
          <div class="row align-items-center">
            <div class="" >
              


              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#mtn">
                <div class="carre">
                  <p class="arrondi" style="background-color: #ffc961">
                   <b> MTN MONEY </b>
                  </p>
                </div>  
              </button>

              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#moov">
                <div class="carre">
                  <p class="arrondi" style="background-color: #0000ff">
                   <b> FLOOZ MOOV </b>
                  </p>
                </div>  
              </button>

              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#werstern">
                <div class="carre">
                  <p class="arrondi" style="background-color: #000; color : yellow">
                   <b> WESTERN UNION </b>
                  </p>
                </div>  
              </button>

              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#moneygram">
                <div class="carre">
                  <p class="arrondi" style="background-color: red">
                   <b> MONEY GRAM </b>
                  </p>
                </div>  
              </button>

              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#perfect">
                <div class="carre">
                  <p class="arrondi" style="background-color: #000; color : orange">
                   <b> PERFECT MONEY </b>
                  </p>
                </div>  
              </button>

              <button style="border-style:none;" type="button" data-toggle="modal" data-target="#trust">
                <div class="carre">
                  <p class="arrondi" style="background-color: #000; color: #6495ed">
                   <b> TRUST WALLET </b>
                  </p>
                </div>  
              </button>
              

              <!-- Formulaire MTN -->
              <div class="modal fade" id="mtn" tabindex="-1" role="dialog" aria-labelledby="mtn" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="mtn">Retrait sur MTN</h5>
                      <i style="color : red; text-align : left; font-size:9px">Veuillez entrer l'indicatif suivi du numéro. Exemple : +22900000000</i>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                     
                      <form class="user" method="post" action="{{ route('retraitmtnS') }}">
                        {{ csrf_field() }}
                      
                           <div class="form-group">
                              <label>Renseigner code OTP <i style="color: red">*</i></label>
                              <input required pattern="[0-9]+" type="text" class="form-control" name="otpmtn" placeholder="Entrer le code otp " value="{{ old('otp') }}" data-original-title="Entrer le code otp">
                              <input value="{{$otp}}" type="hidden" name="otpmtnsend">
                           </div>
 
                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Montant <i style="color: red">*</i></label>
                            <input required pattern="^+[0-9]+" min="0" max="{{$max}}" step="0.00001" type="number" class="form-control" name="montantmtn" id="montantmtn" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                            
                          </div>

                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Numéro du compte<i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="number" class="form-control " name="numerom" id="numerom" placeholder="Entrer votre numero : +22961000000" data-original-title="Entrer votre numero">
                              </div>
                        </div>

                          <div class="form-group">
                           <label>Motif<i style="color: red">*</i></label>
                            <input required pattern="[A-Z a-z0-9]+" type="nom" class="form-control " name="nomm" id="nomm" placeholder="Entrer le motif " data-original-title="Entrer le nom du compte">
                           </div>

                        <input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: #ffc961" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <!-- Fin formulaire mtn -->


              <!-- Formulaire MOOV -->
              <div class="modal fade" id="moov" tabindex="-1" role="dialog" aria-labelledby="moov" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div style="background-color: rgba(250,250,250,0.90);" class="modal-content" >
                    <div class="modal-header">
                      <h5 class="modal-title" id="moov">Retrait sur MOOV</h5>
                      <i style="color : red; text-align : left; font-size:9px">Veuillez entrer l'indicatif suivi du numéro. Exemple : +22900000000</i>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    
                    <div class="modal-body">
                      <form class="user" method="post" action="{{ route('retraitmoovS') }}">
                        {{ csrf_field() }}
                      
                        <div class="form-group">
                          <label>Renseigner code OTP <i style="color: red">*</i></label>
                          <input required pattern="[0-9]+" type="text" class="form-control" name="otpmoov" placeholder="Entrer le code otp" value="{{ old('otp') }}" data-original-title="Entrer le code otp">
                          <input value="{{$otp}}" type="hidden" name="otpmoovsend">
                        </div>
 
                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Montant <i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" min="0" max="{{$max}}" step="0.00001" type="number" class="form-control " name="montantmoov" id="montantmoov" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                          </div>

                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Numero du compte<i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="number" class="form-control " name="numeromoov" id="numeromoov" placeholder="Entrer votre numero" data-original-title="Entrer votre numero">
                            
                          </div>
                        </div>
                          <div class="form-group">
                            <label>Motif<i style="color: red">*</i></label>
                            <input required pattern="[A-Z a-z0-9]+" type="text" class="form-control " name="nommoov" id="nom" placeholder="Entrer le motif" data-original-title="Entrer le nom du compte">
                         </div>

                        <input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: #0000ff" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                      
                    </div>
                  </div>
                </div>
              </div>


               <!-- Formulaire western -->
              <div class="modal fade" id="werstern" tabindex="-1" role="dialog" aria-labelledby="werstern" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div style="background-color: rgba(250,250,250,0.90);" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="werstern">Retrait sur Western Union</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form class="user" method="post" action="{{ route('retraitwesternS') }}">
                        {{ csrf_field() }}
                      
                        <div class="form-group">
                            <label>Renseigner code OTP <i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="text" class="form-control" name="otpwestern" placeholder="Entrer le code otp " value="{{ old('otp') }}" data-original-title="Entrer le code otp">
                            <input value="{{$otp}}" type="hidden" name="otpwesternsend">
                        </div>

                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Nom<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="nomwest" id="nomwest" placeholder="Entrer votre nom" data-original-title="Entrer votre nom">
                        </div>
                        
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Prénom<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="prenomwest" id="prenomwest" placeholder="Entrer votre prenom" data-original-title="Entrer votre prenom">
                          </div>
                        </div>
 
                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Adresse<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z: 0-9]+" type="text" class="form-control " name="addwest" id="addwest" placeholder="Entrer votre adresse" data-original-title="Entrer votre adresse">
                           
                          </div>
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Ville<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z' 0-9]+" type="text" class="form-control " name="villewest" id="villewest" placeholder="Entrer votre ville" data-original-title="Entrer votre ville">
                            
                          </div>
                        </div>

                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Pays<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="payswest" id="payswest" placeholder="Entrer votre pays" data-original-title="Entrer votre pays">
                            
                          </div>

                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Montant<i style="color: red">*</i></label>
                            <input required pattern="[.0-9]+" type="number" class="form-control " name="montwest" id="montwest" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                            
                          </div>
                        </div>
                        <div class="form-group">
                           <label>Motif<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="motifwest" id="motifwest" placeholder="Entrer le motif" data-original-title="Entrer le motif">
                            
                        </div>
                        <input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: #000; color : yellow" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <!-- Fin formulaire western -->


               <!-- Formulaire Money gram -->
              <div class="modal fade" id="moneygram" tabindex="-1" role="dialog" aria-labelledby="moneygram" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div style="background-color: rgba(250,250,250,0.90);" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="moneygram">Retrait sur Money Gram</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form class="user" method="post" action="{{ route('retraitgramS') }}">
                        {{ csrf_field() }}
						
						<div class="form-group">
                              <label>Renseigner code OTP <i style="color: red">*</i></label>
                              <input required pattern="[0-9]+" type="number" class="form-control " name="otpgram" placeholder="Entrer le code otp " value="{{ old('otp') }}" data-original-title="Entrer le code otp">
                              <input value="{{$otp}}" type="hidden" name="otpgramsend">
                        </div>
                      
                         <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Nom<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z ]+" type="text" class="form-control " name="nomgram" id="nomgram" placeholder="Entrer votre nom" data-original-title="Entrer votre nom">
                            
                          </div>
						  
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Prénom<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z ]+" type="text" class="form-control " name="prenomgram" id="prenomgram" placeholder="Entrer votre prenom" data-original-title="Entrer votre prenom">
                            
                          </div>
                         </div>
 
                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Adresse<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="addgram" id="addgram" placeholder="Entrer votre adresse" data-original-title="Entrer votre adresse">
                            
                          </div>

                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Ville<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z 0-9]+" type="text" class="form-control " name="villegram" id="villegram" placeholder="Entrer votre ville" data-original-title="Entrer votre ville">
                            
                          </div>
						</div>

                        <div class="form-group row">
                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Pays<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z ]+"type="text" class="form-control " name="paysgram" id="paysgram" placeholder="Entrer votre pays" data-original-title="Entrer votre pays">
							
                          </div>

                          <div class="col-sm-6 mb-3 mb-sm-0">
                            <label>Montant<i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="number" class="form-control " name="montgram" id="montwest" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                            
                          </div>
						</div>

                        <div class="form-group">
                          
                            <label>Motif<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z]+" type="text" class="form-control " name="motifgram" id="motifgram" placeholder="Entrer le motif" data-original-title="Entrer le motif">
                            
                          
                        </div>

                        <input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: red" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <!-- Fin formulaire money gram -->


               <!-- Formulaire perfect -->
              <div class="modal fade" id="perfect" tabindex="-1" role="dialog" aria-labelledby="perfect" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div style="background-color: rgba(250,250,250,0.90);" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="perfect">Retrait sur Perfet Money</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form class="user" method="post" action="{{ route('retraitperfectS') }}">
                        {{ csrf_field() }}
                      
						<div class="form-group">
                            <label>Renseigner code OTP <i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="text" class="form-control " name="otpperfect" placeholder="Entrer le code otp " value="{{ old('otp') }}" data-original-title="Entrer le code otp">
                            <input value="{{$otp}}" type="hidden" name="otpperfectsend">
						</div>
						
						<div class="form-group">
                            <label>Motif<i style="color: red">*</i></label>
                            <input required pattern="[A-Za-z ]+" type="text" class="form-control " name="intitulerperfect" id="nomgram" placeholder="Entrer le motif" data-original-title="Entrer le motif">
                            
                        </div>
						
						<div class="form-group">
                            <label>Montant<i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="number" class="form-control " name="montperfect" id="montwest" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                        </div>
						   
						<div class="form-group"> 
                            <label>Lien ou code <i style="color: red">*</i></label>
                            <input type="text" class="form-control " name="lienperfect" placeholder="Entrer votre adresse $US" data-original-title="Entrer votre adresse $US">
						</div> 
              
						<input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: #000; color : orange" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                    </div>
                  </div>
                </div>
              </div>
			   <!-- fin perfect -->
			  
			  <!-- Formulaire trust -->
              <div class="modal fade" id="trust" tabindex="-1" role="dialog" aria-labelledby="trust" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div style="background-color: rgba(250,250,250,0.90);" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="trust">Retrait sur Trust WALLET / COIN BASE</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form class="user" method="post" action="{{ route('retraittrustS') }}">
                        {{ csrf_field() }}
                      
					  <div class="form-group">
                              <label>Renseigner code OTP <i style="color: red">*</i></label>
                              <input required pattern="[0-9]+" type="text" class="form-control" name="otptrust" placeholder="Entrer le code otp " value="{{ old('otp') }}" data-original-title="Entrer le code otp">
							  <input value="{{$otp}}" type="hidden" name="otptrustsend">
                      </div>
						
					<div class="form-group">
                            <label>Montant<i style="color: red">*</i></label>
                            <input required pattern="[0-9]+" type="number" class="form-control " name="monttrust" id="montwest" placeholder="Entrer le montant" data-original-title="Entrer le montant">
                    </div>
					<div class="form-group">
                        <label>Motif<i style="color: red">*</i></label>
                        <input required pattern="[A-Za-z ]+" type="text" class="form-control " name="intitulertrust" placeholder="Entrer le motif" data-original-title="Entrer le motif">
                    </div>
					
                      <div class="form-group">
                            <label>Lien ou code wallet<i style="color: red">*</i></label>
                            <input type="text" class="form-control " name="lientrust" placeholder="Entrer votre adresse Bitcoin" data-original-title="Entrer votre adresse Bitcoin">
                            
                        </div> 
              
                        <input type="submit" name="Valider le retrait" value="Valider le retrait" class="btn btn-user btn-block" style="background-color: #000; color: #6495ed" />
                        
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">FERMER</button>
                      
                    </div>
                  </div>
                </div>
              </div>
              <hr>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>


@endsection