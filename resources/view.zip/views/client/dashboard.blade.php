@extends('layouts.template_client')

@section('content')
	   <div class="row">
         
      <div class="col-lg-12">
        <h3 class="page-header">Tableau de bord</h3>
        <!--div class="col-lg-8" style="margin-top: -60px">
        <form class="form-inline" method="get" action="">
                  <input class="form-control mr-sm-2" type="search" placeholder="identifiant, pseudo, nom ou prenom" name="motcle" aria-label="Search">
                  <button class="btn btn-outline-info my-2 my-sm-0" type="submit" style="background-color: blue">Rechercher <i class="fa fa-search"></i></button>
                </form>
    </div-->
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>
    

    <div class="row">
      

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb ">
          <a href="{{ route('gains') }}">
        <div class="info-box brown-bg">
            <div class="count"> 
              @if(isset($gains[0]->gainvirtuel)) 
                {{ $gains[0]->gainvirtuel }} $ SSI
              @else
                0 $ SSI
              @endif
            </div>
          <div class="title">Gain Virtuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="{{ route('gains') }}">
        <div class="info-box " style="background-color: #E0B05D">
          <div class="count">
          @if(isset($gains[0]->gainespece)) 
            {{ $gains[0]->gainespece }} $ SSI
            @else
                0 $ SSI
            @endif
          </div>
          <div class="title">Gain en Espèce</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="#">
        <div class="info-box" style="background-color: #838B8B">
          <div class="count">
            @if(isset($gains[0]->gaincommissionvente)) 
            {{ $gains[0]->gaincommissionvente}} $ SSI
            @else
                0 $ SSI
            @endif
            
          </div>
          <div class="title">Commission sur vente</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="#">
        <div class="info-box dark-bg">
          <div style="text-align:center"> Gain en nature</div>
          <div class="col-sm-12 col-xs-12" >
              <div class="col-sm-3 col-xs-3" title="1"> <img src="/nature/1/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/2/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/3/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/4/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/5/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/6/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/7/etape.png" id="signataire"> </div>
              <div class="col-sm-3 col-xs-3"> <img src="/nature/8/etape.png" id="signataire"> </div>
          </div>
        </div>
          </a>
        <!--/.info-box-->
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-item">
          <a href="#">
        <div class="info-box blue-bg">
          <div style="text-align:center"> Gain en nature gagné</div>
            <!--div class="col-sm-12 col-xs-12">
          @switch($etape)
            @case(1)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                @break
            @case(2)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                @break
            @case(3)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                @break
            @case(4)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/4/etape.png" id="signataire"> </div>
                @break
            @case(5)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/4/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/5/etape.png" id="signataire"> </div>
                @break
            @case(6)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/4/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/5/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/6/etape.png" id="signataire"> </div>
                @break
            @case(7)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/4/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/5/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/6/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/7/etape.png" id="signataire"> </div>
                @break
            @case(8)
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/1/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/2/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/3/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/4/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3" title="1"> <img src="/TEST/nature/5/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/6/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/7/etape.png" id="signataire"> </div>
                <div class="col-sm-3 col-xs-3"> <img src="/TEST/nature/8/etape.png" id="signataire"> </div>
                @break
            
            @default
        @endswitch
          </div-->
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itema">
          <a href="{{ route('regle') }}">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px"> {{ $etape }} </div>  </div>
          <div class="title">Etape Actuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->
<?php 
            $n = 0;
            //$filleuls
            foreach($filleuls as $filleul)
            {
                if($filleul->compteactive == "oui")
                    $n++;
            }
            
          ?>
    </div>
    <!--/.row-->
<div class="horizontal-scrollable">
    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste de mes filleuls ({{ $n }})
          </header>

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr style="font-size: 12px">
                <th style="text-align: center;"><i class="icon_ol"></i> Nom & Prénom Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Code de parrainage du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Identifiant du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Statut</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Parrain du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Inscrire le</th>
              </tr>
              @forelse($filleuls as $filleul)
                
                <tr style="text-align: center;">
                  <td>{{ $filleul->nom }} {{ $filleul->prenom }}</td>
                  
                  <td>{{ $filleul->codeunique }}</td>
                  <td>{{ $filleul->codeperso}}</td>
                  <td>
                    @if($filleul->compteactive == "oui")
                        <i style="color: white; background-color: green">actif</i>
                    @endif
                    @if($filleul->compteactive == "non")
                        <i style="color: white; background-color: red">inactif</i> 
                    @endif
                  </td>
                  <td>{{ $filleul->parrain }}</td>
                  <td>{{ $filleul->created_at}}</td>
                </tr>
              @empty
                <tr >
                  <td colspan="6" style="text-align: center;">Pas de Filleul disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>
</div>
@endsection

@section('css')
<style>
#signataire{
	height: 40px;
	width: 40px;
	padding : 2px;
	margin-left: 0px;
	margin-top: 0px;
}
</style>
@endsection