@extends('layouts.template_client')

@section('content')
	<div class="row">
        
      <div class="col-lg-11">
        <h3 class="page-header">Règle du MLM</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="col-lg-12">
      <center><h2 style="color: blue">PLAN MARKETING</h2></center><br><br>
      <img src="img/bas2.png" class="bas" style="width: 30%; height: 30%; margin-left: 35%; margin-top: -50px" ></div>

       <center><h5 style="color: red">ETAPE 1</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 06 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 3 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

          <center><h5 style="color: red">ETAPE 2</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 21 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 3</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 140 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 4</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 770 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 5</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 3500 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 6</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 11200 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 7</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 56000 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br>

           <center><h5 style="color: red">ETAPE 8</h5></center>
         <p style="text-align: justify;">
         A cette étape il faut 14 personnes sous soi pour la valider dont deux filleuls direct.On bénéficie de 280000 $ SSI comme gain d'étape pour passer à l'étape suivante.
          </p><br><br>

          <p style="text-align: justify; color: blue">
         <h3 style="color: blue">NB :</h3><h5 style="color: blue"> Sur chaque personne qui s'inscrit directement avec votre code de parrainnage vous gagnez 10% comme gain en numéraire (en espèce) et 10% comme gain virtuel(servant pour achat dans la boutique)</h5>          </p><br><br>
    </div>
    
    </div>
    

@endsection