@extends('layouts.template_client')

@section('css')
@endsection

@section('content')
    <div class="row">
        
      <div class="col-lg-12">
        ({{ utf8_encode(" Historique � partir du 26 Ao�t 2021 � 15h")}} )
        <div class="text-center">
                @include('flash::message')
              </div>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
          <li style="text-align: right"> <a href="{{ route('histclient') }}">Historique des translations </a> </li>
        </ol>
      </div>
    </div>
    
    <!--/.row-->
    <div class="horizontal-scrollable">
    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
            <div class="table-responsive-sm">
                
          <table class="table table-striped table-bordered table-hover table-sm" style="border-collapse: collapse;">
            <tbody>
              <tr style="font-size: 14px">
                <th style="text-align: center; background-color: #458b00; color: white"> {{ utf8_encode("Libell� de la translation")}} </th>
                <th style="text-align: center; background-color: #458b00; color: white"> {{ utf8_encode("Date de l'op�ration")}}</th>
              </tr>
              @forelse($hists as $hist)
                <tr style="text-align: center">
                  
                  <td > {{ $hist->libelle }}</td>
                  <td > {{ $hist->created_at}}</td>
                </tr>
              @empty
                <tr >
                  <td colspan="2" style="text-align: center; color: red">Historique vide!</td>
                </tr>
              @endforelse
            </tbody>
          </table>
          
          </div>
        </section>
      </div>
    </div>
    </div>

@endsection