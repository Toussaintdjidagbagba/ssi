 <br>
 <br>
 <br>
 <br>
<center> <h1 style="color : #25599C;"> La Source du Succ�s International </h1> </center> <br><br><br>

<center>
    Monsieur Madame <b>{{ $prenom }} {{ $nom }},</b> 
    Bienvenu � la <b>Source du Succ�s International.<b> <br> 
    
    Votre demande d'achat de $ SSI a �chou�. 
    Cause possible : 
    - Nous n'avons pas re�u l'argent sur notre compte. <br>
    
    - La r�f�rence de paiement est peut-�tre mal renseigner. <br>
    
    Pour corriger, veuillez bien rev�rifier soit la r�f�rence soit votre compte.  <br>

</center>
<center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center> 

<br>
<br> 
Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.