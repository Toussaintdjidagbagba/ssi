 <br>
 <br>
 <br>
 <br>
<center> <h1 style="color : #25599C;"> La Source du Succ�s International </h1> </center> <br><br><br>
    <center>
    Monsieur Madame <b>{{ $prenom }} {{ $nom }},</b> 
    Bienvenu � la <b>Source du Succ�s International.<b> <br> 
    
    Un retrait de {{$montant }} $ SSI / {{$montantf }} F CFA a �t� effectu� ce 
    {{$datevalider}} de votre compte sur carte visa dont l'identifiant est {{$idcarte}}. <br>
    Intituler de la carte : {{$intitule}} <br>
    Nom et pr�nom de la carte : {{$nomcarte}}
    
    </center><br>

    <center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center> 

<br>
<br> 
<center> Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message. </center> 
