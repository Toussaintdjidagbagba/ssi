<div> 

	Bonjour. 
	J'ai recu le mail.
	
	<center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center>

</div> 