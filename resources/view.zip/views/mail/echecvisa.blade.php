 <br>
 <br>
 <br>
 <br>
<center> <h1 style="color : #25599C;"> La Source du Succ�s International </h1> </center> <br><br><br>

<center>
    Monsieur Madame <b>{{ $prenom }} {{ $nom }},</b> 
    Bienvenu � la <b>Source du Succ�s International.<b> <br> 
    
    Votre demande de retrait sur carte a �chou�. 
    Cause possible : 
    - Informations de la carte mal renseigner. <br>
    
    Pour corriger, veuillez bien rev�rifier les informations renseigner dans l'historique ou contacter l'administrateur du site.  <br>

</center>
<center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center> 

<br>
<br> 
Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.