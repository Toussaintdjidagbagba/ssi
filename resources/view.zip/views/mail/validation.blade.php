 <br>
 <br>
 <br>
 <br>
<center> <h1 style="color : #25599C;"> La Source du Succès International </h1> </center> <br><br><br>
<center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center> 

<br>
    Monsieur Madame <b>{{ $prenom }} {{ $nom }},</b> 
    Votre compte est validé. <br> <br> 
    Bienvenu à la <b>Source du Succès International.<b> <br> 
    <br>Votre code de parrainage est la suivante : {{ $codeunique }}. <br><br>
    Le nom de votre parrain est : {{ $nomparrain }} <br> <br>
    Votre lien de parrainage est : https://sourcedusuccesinternational.com/inscription-monparrain-{{ $codeunique }} <br> <br>
    Vous pouvez vous connecter grace à l'identifiant suivante {{ $codeperso}} ou à votre pseudo {{ $nomuser }} <br> <br>
    Connectez-vous à votre compte en cliquant sur ce lien <a href="https://sourcedusuccesinternational.com/connexion"> Se connecter </a>
<br>
<br> 
Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.