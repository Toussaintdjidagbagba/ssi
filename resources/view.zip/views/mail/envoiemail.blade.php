 <br>
 <br>
 <br>
 <br>
<center> <h1 style="color : #25599C;"> La Source du Succès International </h1> </center> <br><br><br>
<center style=""> <img src="http://sourcedusuccesinternational.com/logo.jpeg" style="width: 250px; height: 350px"/> </center> 
<h2> {{ $object }} </h2>
<br>
{{ $mess }}
<br>
<br> 
Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.  