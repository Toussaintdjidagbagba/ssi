@extends('layouts.template_admin')

@section('content')

<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des demandes SONEB
          </header> 
          <div class="text-center">
                @include('flash::message')
          </div>
          <table  class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th> Référence No </th> 
                <th> Nom & Prénom </th>
                <th> Mail / WhatsApp </th>
                <th> Numéro Police du compteur</th>
                <th> Présentation </th>
                <th> Montant Facture</th>
                <th> Envoyer le </th>
                <th> Délivré recu</th>
                <th> Statut</th>
                <th> Action</th>
              </tr>
              @forelse($demandes as $demande)
                <tr>
                  <td>{{ $demande->RefRecu }}</td>
                  <td>{{ $demande->Nom }} {{ $demande->Prenom }}</td>
                  <td>{{ $demande->Email }} / {{ $demande->WhatsApp }}</td>
                  <td>{{ $demande->Police }}</td>
                  <td>{{ $demande->Presentation }}</td>
                  <td>{{ $demande->Montant }}</td>
                  <td>{{ $demande->date }}</td>
                  <td> <a href="/soneb-recu:reference-{{ $demande->RefRecu }}">Etablir recu</a> </td>
                  <td>
                    @if($demande->Statut == "oui")
                        <i style="color: white; background-color: green">recu envoyée</i>
                    @else
                        <i style="color: white; background-color: red">en attente</i> 
                    @endif
                  </td>    
                  <td>
                    <a class="btn btn-outline-primary btn-circle btn-icon" 
                          style="color:red;font-weight:bold;" 
                          href="{{url('admin/delete-soneb-'.$demande->RefRecu)}}">
                      <i class="fa fa-trash"></i>Supprimer </a> 
                  </td>
                </tr>
              @empty
                <tr >
                  <td colspan="8" style="text-align: center;">Pas de demande disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>

@endsection