@extends('layouts.template_admin')

@section('content')

<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des demandes d'inscription Longrich
          </header> 
          <div class="text-center">
                @include('flash::message')
          </div>
          <table  class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th><i class="icon_ol"></i> Référence No </th> 
                <th><i class="icon_pin_alt"></i> Pseudo </th>
                <th><i class="icon_pin_alt"></i> Nom & Prénom </th>
                <th><i class="icon_pin_alt"></i> Mail / Téléphone</th>
                <th><i class="icon_pin_alt"></i> Date / Pays </th>
                <th><i class="icon_pin_alt"></i> Montant Payer</th>
                <th><i class="icon_pin_alt"></i> Envoyer le </th>
                <th><i class="icon_pin_alt"></i> Délivré recu</th>
                <th><i class="icon_pin_alt"></i> Statut</th>
              </tr>
              @forelse($demandes as $demande)
                <tr>
                  <td>{{ $demande->RefRecu }}</td>
                  <td>{{ $demande->pseudo }}</td>
                  <td>{{ $demande->Nom }} {{ $demande->Prenom }}</td>
                  <td>{{ $demande->Email }} / {{ $demande->Tel }}</td>
                  <td>{{ $demande->dateL }} <br> {{ $demande->pays }} </td>
                  <td>{{ $demande->MontantPayer }}</td>
                  <td>{{ $demande->date }}</td>
                  <td> <a href="/longrich-recu:reference-{{ $demande->RefRecu }}">Etablir recu</a> </td>
                  <td>
                    @if($demande->Statut == "oui")
                        <i style="color: white; background-color: green">recu envoyée</i>
                    @else
                        <i style="color: white; background-color: red">en attente</i> 
                    @endif
                  </td> 
                </tr>
              @empty
                <tr >
                  <td colspan="9" style="text-align: center;">Pas de demande disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </section>
      </div>
    </div>
@endsection