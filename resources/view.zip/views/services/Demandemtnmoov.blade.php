@extends('layouts.template_admin')

@section('content')

<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des demandes MTN / MOOV
          </header> 

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th> Nom</th>
                <th> Identifiant</th>
                <th> Téléphone</th>
                <th> Libelle</th>
                <th> Envoyer le</th>
                <th> Montant Payer</th>
                <th> Valider le</th>
                <th> Répondre</th>
                <th> Statut</th>
                <th>Action</th>
              </tr>
              @forelse($demandes as $monetique)
                <tr>
                  <td>{{ $monetique->NomUser }}</td>
                  <td>{{ $monetique->CodePersoUser }}</td>
                  <td>{{ $monetique->Tel }}</td>
                  <td>{{ $monetique->libelle }}</td>
                  <td>{{ $monetique->created_at }}</td>
                  <td>{{ $monetique->MontantPayer }}</td>
                  <td>{{ $monetique->DateValider }}</td>
                  
                  <td>
                  	@if($monetique->Statut == "oui")
                        <a href="#"><span class="fa fa-check-square" style="color: #A6ACAF;"></span></a>
                    @else
                        <form action="{{route('mtnmoovrecuS')}}" method="post">
                          {{ csrf_field() }}
                      		<input type="hidden" name="id" value="{{$monetique->id}}">	
                      	<input type="submit" name="valid" style="background: green; color : #fff" value="V">		
                      	</form>
                    @endif
                  </td>
                  <td>
                    @if($monetique->Statut == "oui")
                        <i style="color: white; background-color: green">Servir</i>
                    @else
                        <i style="color: white; background-color: red">Non servir</i> 
                    @endif
                  </td>
                  <td>
                    <a class="btn btn-outline-primary btn-circle btn-icon" 
                          style="color:red;font-weight:bold;" 
                          href="{{url('admin/delete-mtnmoov-'.$monetique->id)}}">
                      <i class="fa fa-trash"></i>Supprimer </a> 
                  </td>  
                  
                </tr>
              @empty
                <tr >
                  <td colspan="7" style="text-align: center;">Pas de demande disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>
            {{ $demandes->links() }}
        </section>
      </div>
    </div>

@endsection