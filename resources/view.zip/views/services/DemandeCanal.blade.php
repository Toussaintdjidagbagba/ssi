@extends('layouts.template_admin')

@section('content')

<div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste des demandes d'abonnement canal+
          </header> 
          <div class="text-center">
                @include('flash::message')
          </div>
          <table  class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th> Référence No </th> 
                <th> Nom & Prénom </th>
                <th> Mail / Téléphone </th>
                <th> Choix du formule <br> Durée en mois </th>
                <th> Numéro Carte </th>
                <th> Montant Payer</th>
                <th> Envoyer le </th>
                <th> Délivré recu</th>
                <th> Statut</th>
                <th>Action</th>
              </tr>
              @forelse($demandes as $demande)
                <tr>
                  <td>{{ $demande->RefRecu }}</td>
                  <td>{{ $demande->Nom }} {{ $demande->Prenom }}</td>
                  <td>{{ $demande->EmailUser }} / {{ $demande->TelUser }}</td>
                  <td> {{ $demande->Choisirformule }} <br> {{ $demande->Dureenmois }} mois</td>
                  <td> {{ $demande->Numerocarte }} </td>
                  <td>{{ $demande->MontantPayer }}</td>
                  <td>{{ $demande->date }}</td>
                  <td> <a href="/canal-recu:reference-{{ $demande->RefRecu }}">Etablir recu</a> </td>
                  <td>
                    @if($demande->Statut == "oui")
                        <i style="color: white; background-color: green">recu envoyée</i>
                    @else
                        <i style="color: white; background-color: red">en attente</i> 
                    @endif
                  </td>    
                  <td>
                    <a class="btn btn-outline-primary btn-circle btn-icon" 
                          style="color:red;font-weight:bold;" 
                          href="{{url('admin/delete-canals-'.$demande->RefRecu)}}">
                      <i class="fa fa-trash"></i>Supprimer </a> 
                  </td> 
                </tr>
              @empty
                <tr >
                  <td colspan="8" style="text-align: center;">Pas de demande disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </section>
      </div>
    </div>
@endsection