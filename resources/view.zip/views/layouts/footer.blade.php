<footer style="background-color: #d5d6df;">
    <div class="container" >
        <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
                
                <p style="color: #4f2e14; margin-top: 5px" class="copyright text-muted">Copyright &copy; Source du Succès International <?php echo date('Y') ?> </p>
            </div>
        </div>
    </div>
</footer>
