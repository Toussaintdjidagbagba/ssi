@extends('layouts.template')

@section('content')
  
@endsection