<?php

namespace App\Http\Controllers;

use App\HistoriqueClient;
use App\Achatssi;
use App\Retraitvisa as Visa;
use App\Historique;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ServiceController extends Controller 
{
    public function setachat(Request $request)
    {
        if (!auth()->guest()) {
            
            Achatssi::create([
                'codeperso' => request('id'), 
                'montant' => request('montant'),
                'referencepaye' => request('ref'),
                'libellecompte' => request('compte')
            ]);
            $libellecompte = "";
            if(request('compte') == 1) $libellecompte = "Compte Espèce";
            if(request('compte') == 2) $libellecompte = "Compte Virtuel";
            $message = "Vous avez demandé un achat de ".request('montant')." $ SSI sur votre ".$libellecompte.". Votre demande est en attente de confirmation..";
            HistoriqueClient::saveHistorique($message, auth()->user()->id );
            
            flash('Votre demande est en attente de confirmation..');
            
            return Back();
		}
		else
		{
		   flash("Vous devez être connecté pour effectuée l'achat de $ SSI. Si vous ne possédez pas de compte, inscrivez-vous et revenez sur Achat $ SSI");
	       return redirect('/connexion');
		}
    }
    
    public function setdeleteachat(Request $request){
        
        DB::table('achatssis')
                    ->where('id', request("id"))
                    ->update([
                    'statut' => "sup"
                    ]);
        
        flash("Demande d'achat $ SSI supprimer avec succès! "); //Filleul supprimer avec succès!
        return Back();
    }
    
    public function getdemandeachat()
    {
        $achats = DB::table('achatssis')->orderByRaw("statut DESC, id DESC ")->where('statut', '!=', 'sup')->paginate(20);
        return view('admin.dashboardachatgain', compact('achats'));
    }
    
    public function setservirachat(Request $request)
    {
        
        $id = request('id');
        
        $achat = DB::table('achatssis')->where('id', $id)->get()[0]; 
        $codeperso = $achat->codeperso;
        //dd(DB::table('users')->where('codeperso', $codeperso)->get()[0]);
        if(isset(DB::table('users')->where('codeperso', $codeperso)->get()[0]))
        {
            
            $user = DB::table('users')->where('codeperso', $codeperso)->get()[0];
            
            // crédit le compte client
            // 1 pour gain espèce 
            // 2 pour gain virtuel
            setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
            date_default_timezone_set('Africa/Porto-Novo');
            if(DB::table('achatssis')->where('id', $id)->first()->statut == "0") {
                flash("L'achat a été déjà confirmer.");
                return Back();
            }else{
                
                if($achat->libellecompte == 1)
                {
                    $soldeactuel = DB::table('avoirs')->where('id_user', $user->id)->get()[0]->gainespece;
                    $soldeac = $soldeactuel + $achat->montant;
                    DB::table('avoirs')
                            ->where('id_user', $user->id)
                            ->update([
                            'gainespece' => $soldeac,
                            'updated_at' => date('Y-m-d H:i:s')
                            ]);
                }
                
                if($achat->libellecompte == 2)
                {
                    $soldeactuel = DB::table('avoirs')->where('id_user', $user->id)->get()[0]->gainvirtuel;
                    $soldeac = $soldeactuel + $achat->montant;
                    DB::table('avoirs')
                            ->where('id_user', $user->id)
                            ->update([
                            'gainvirtuel' => $soldeac, 
                            'updated_at' => date('Y-m-d H:i:s')
                            ]);
                }
                
                        
                DB::table('achatssis')
                        ->where('id', $id)
                        ->update([
                        'statut' => "0",
                        'updated_at' => date('Y-m-d H:i:s')
                        ]);
                
                setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
                date_default_timezone_set('Africa/Porto-Novo');
        
                $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
                $HEURE = date("H:i"); // Heure d'envoi de l'email
        
                $Subject = "Achat de gain SSI - $JOUR $HEURE";
                
                $data = [
                    'prenom' => $user->prenom, 
                    'nom' => $user->nom, 
                    'montant' => $achat->montant ];
                $destinataire = $user->email;  
                $message_reception = "Vous avez reçu un mail comportant le reçu de Achat de GAIN SSI dont le montant est ".$achat->montant." $ SSI ";
                HistoriqueClient::saveHistorique($message_reception, $user->id);
                SendMail::sendachat($destinataire, $Subject, $data);
                flash("Un message de validation a été envoyer");
                return Back();
            }
        
        }else{
            flash("L'utilisateur qui effectue la demande n'existe pas")->error();
            return Back();
        }
        
        
    }
    
    public function setechecachat(Request $request)
    {
        
        $id = request('id');
        
        $achat = DB::table('achatssis')->where('id', $id)->get()[0]; 
        $codeperso = $achat->codeperso;
        //dd(DB::table('users')->where('codeperso', $codeperso)->get()[0]);
        if(isset(DB::table('users')->where('codeperso', $codeperso)->get()[0]))
        {
            
            $user = DB::table('users')->where('codeperso', $codeperso)->get()[0];
            
            setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
            date_default_timezone_set('Africa/Porto-Novo');
    
            $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
            $HEURE = date("H:i"); // Heure d'envoi de l'email
    
            $Subject = "Achat de gain SSI - $JOUR $HEURE";
            
            $data = [
                'prenom' => $user->prenom, 
                'nom' => $user->nom ];
            $destinataire = $user->email;
            
            SendMail::sendachatechec($destinataire, $Subject, $data);
            flash("Un message d'échec a été envoyer");
            return Back();
        
        }else{
            flash("L'utilisateur qui effectue la demande n'existe pas")->error();
            return Back();
        }
    }
    
    // Visa
    public function setretraitvisa(Request $request)
    {
        if (!auth()->guest()) {
            $resultat = auth()->attempt([
                'id' => auth()->user()->id,
                'password' => request('pass')
            ]);
            if($resultat){
    			$soldeactuel = DB::table('avoirs')->where('id_user', auth()->user()->id)->get()[0]->gainespece;
    			
    			if($soldeactuel <= 20)
    			{
    				flash("Votre solde n'atteint pas le seuil minimum de 20 $ SSI !");
                    return Back();
    			}
    			else {
    			    
    			    $montantnet = request('montant');
    				$fraisretrait = $montantnet * 1 / 100;
    				$montantvalider = $montantnet + $fraisretrait;
                
    				if ($soldeactuel < $montantvalider) {
    					flash("Votre solde est insuffissant pour terminer l'opération!!");
    					return Back();
    				} else {
    					
    					// Alors update compte expediteur : decrementer
    					$soldeac = $soldeactuel - $montantvalider;
    					DB::table('avoirs')
    						->where('id_user', auth()->user()->id)
    						->update([
    						'gainespece' => $soldeac
    						]);
    							
    					$montantdemander = request('montant');
    		            
    		            $add = new Visa();
                        $add->codeperso = request('id');
                        $add->intitule = request('intituler'); // Intitulé de la carte
                        $add->nom = request('name'); // Nom et prénom de la carte
                        $add->idcarte = request('identifiant'); //Identifiant de la carte
                        $add->mont = request('montant'); //Montant à crédité en $ SSI
                        $add->save();
                        
                        $message = "Vous avez demandé un retrait de ".request('montant')." $ SSI sur votre ".request('intituler')."
                        dont l'identifiant est ".request('identifiant')." auquel est associé ".request('name').". Votre demande est en attente de confirmation..";
                        HistoriqueClient::saveHistorique($message, auth()->user()->id );
                        
    					        
                        // Argent qui sort
    					$compteadminsort = DB::table('systemadmins')->where('id_AdminPrincipal', 1)->get()[0]->compteavoirsortant;
    
    					$recus=$compteadminsort - $montantvalider;
    
    					DB::table('systemadmins')
    							->where('id_AdminPrincipal', 1)
    							->update([
    							'compteavoirrecu' => $recus
    							]);
    							
    					
    					flash($message);
    				    return Back();
    				}
    			}
    		}else{
    			flash('Mot de passe incorrect!');
    			return Back();
    		}
		}
		else
		{
		   flash("Vous devez être connecté pour effectuée le retrait. Si vous ne possédez pas de compte, inscrivez-vous");
	       return redirect('/connexion');
		}
    }
    
    public function getdemandevisa()
    {
        $visas = DB::table('retraitvisas')->orderByRaw("statut DESC, id DESC ")->where('statut', '!=', 'sup')->paginate(20);
        return view('admin.demandevisa', compact('visas'));
    }
    
    public function setdeletevisa(Request $request){
        
        DB::table('retraitvisas')
                    ->where('id', request("id"))
                    ->update([
                    'statut' => "sup"
                    ]);
        
        flash("Demande de retrait visa supprimer avec succès! ");
        return Back();
    }
    
    public function setservirvisa(Request $request)
    {
        
        $id = request('id');
        
        $visa = DB::table('retraitvisas')->where('id', $id)->get()[0]; 
        $codeperso = $visa->codeperso;
        //dd(DB::table('users')->where('codeperso', $codeperso)->get()[0]);
        if(isset(DB::table('users')->where('codeperso', $codeperso)->get()[0]))
        {
            
            $user = DB::table('users')->where('codeperso', $codeperso)->get()[0];
            
                
            DB::table('retraitvisas')
                    ->where('id', $id)
                    ->update([
                    'statut' => "0",
                    'updated_at' => date('Y-m-d H:i:s')
                    ]);
            
            setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
            date_default_timezone_set('Africa/Porto-Novo');
    
            $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
            $HEURE = date("H:i"); // Heure d'envoi de l'email
    
            $Subject = "Retrait sur carte VISA SSI - $JOUR $HEURE";
            
            $data = [
                'prenom' => $user->prenom, 
                'nom' => $user->nom, 
                'montant' => $visa->mont,
                'intitule' => $visa->intitule,
                'nomcarte' => $visa->nom,
                'idcarte' => $visa->idcarte,
                'montantf' => ServiceController::conversionfcfa($visa->mont),
                'datevalider' => $JOUR.' à '.$HEURE
                ];
            $destinataire = $user->email;  
            $message_reception = "Vous avez reçu un mail comportant le reçu de retrait sur carte visa dont le montant est ".$visa->mont." $ SSI ";
            HistoriqueClient::saveHistorique($message_reception, $user->id);
            SendMail::sendretraitvisa($destinataire, $Subject, $data);
            flash("Un message de validation a été envoyer");
            return Back();
        
        }else{
            flash("L'utilisateur qui effectue la demande n'existe pas")->error();
            return Back();
        }
    }
    
    public function setechecvisa(Request $request)
    {
        
        $id = request('id');
        
        $visa = DB::table('retraitvisas')->where('id', $id)->get()[0]; 
        $codeperso = $visa->codeperso;
        //dd(DB::table('users')->where('codeperso', $codeperso)->get()[0]);
        if(isset(DB::table('users')->where('codeperso', $codeperso)->get()[0]))
        {
            
            $user = DB::table('users')->where('codeperso', $codeperso)->get()[0];
            
            setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
            date_default_timezone_set('Africa/Porto-Novo');
    
            $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
            $HEURE = date("H:i"); // Heure d'envoi de l'email
    
            $Subject = "Retrait sur Carte visa SSI - $JOUR $HEURE";
            
            $data = [
                'prenom' => $user->prenom, 
                'nom' => $user->nom ];
            $destinataire = $user->email;
            
            SendMail::sendechecretraitvisa($destinataire, $Subject, $data);
            flash("Un message d'échec a été envoyer");
            return Back();
        }else{
            flash("L'utilisateur qui effectue la demande n'existe pas")->error();
            return Back();
        }
    }
    
    public function conversionfcfa($value)
    { return $value * 500;}
    
}