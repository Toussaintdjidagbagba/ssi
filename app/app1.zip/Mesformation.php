<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mesformation extends Model
{
	protected $fillable = ['titre', 'doc', 'id_user'];
    //
}
