<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Avoir extends Model
{
    //
    protected $fillable = ['gainvirtuel', 'gainespece', 'gaincommissionvente', 'id_user', 'translation_first'];
}
