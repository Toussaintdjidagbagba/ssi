<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Achatssi extends Model
{
    //
    protected $fillable = ['codeperso', 'montant', 'referencepaye', 'libellecompte'];
}
