<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Galerie extends Model
{
    //
    protected $fillable = ['path', 'image', 'id_user'];
}
