<?php

namespace App\Http\Controllers;

use App\Articlepdf;
use App\Galerie;
use App\Evenement;
use App\Notificationcontact;
use App\User;
use App\Avoir;
use App\Etape;
use App\Mesformation;
use App\MoyenPayement;
use App\Niveau;
use App\Systemadmin;
use App\Translationuser;
use DB;
use Illuminate\Http\Request;

class IndexController extends Controller
{

    public function gettransfert()
    {
        return view('client.transfert');
    }

     public function settransfert(Request $request)
    {
        request()->validate([
            'id' => 'required',
            'montant' => 'required|min:0' ]);

        // Verifier l'existance de id
        if (isset(DB::table('users')->where('codeperso', request('id'))->get()[0]->codeperso)) {
            
            // Verifier le compte actuel du parrain au traver du montant

            $soldeactuel = DB::table('avoirs')->where('id_user', auth()->user()->id)->get()[0]->gainespece;
            //dd($soldeactuel < request('montant'));
            if ($soldeactuel < request('montant')) {
                flash("Votre solde est insuffissant!! 😢 🤔🤔🤔");
                return Back();
            } else {
                // Alors update compte expediteur : decrementer
                $soldeac = $soldeactuel - request('montant');
                DB::table('avoirs')
                    ->where('id_user', auth()->user()->id)
                    ->update([
                    'gainespece' => $soldeac
                    ]);

                // Alors update compte destinataire : incrementer
                $iddest = DB::table('users')->where('codeperso', request('id'))->get()[0]->id;
                $soldeactuel = DB::table('avoirs')->where('id_user', $iddest)->get()[0]->gainespece;
                $soldeac = $soldeactuel + request('montant');
                DB::table('avoirs')
                    ->where('id_user', $iddest)
                    ->update([
                    'gainespece' => $soldeac
                    ]);
                flash("Transfert éffectuer avec succès");
                return Back();
            }
            
        } else {
            flash("L'identifiant n'existe pas");
            return Back();
        }
       
    }


    public function getprofil()
    {
        $users = DB::table('users')
                     ->where('id', auth()->user()->id)
                     ->get();
        $data = ['users' => $users];
        return view('client.profil', $data);
    }

    public function setprofil(Request $request)
    {
        request()->validate([
            'nom' => 'required',
            'prenom' => 'required',
            'sexe' => 'required',
            'tel' => 'required' ]);

            DB::table('users')
            ->where('id', auth()->user()->id)
            ->update([
            'nom' => request('nom'),
            'prenom' =>request('prenom'),
            'sexe' =>request('sexe'),
            'tel' =>request('tel') 
            ]);
            
            $users = DB::table('users')
                     ->where('id', auth()->user()->id)
                     ->get();
            $data = ['users' => $users];
        return view('client.profil', $data);    
        
    }

    public function gettransfertadmin()
    {
        return view('admin.transfertadmin');
    }

    public function settransfertadmin(Request $request)
    {
        request()->validate([
            'id' => 'required',
            'montant' => 'required|min:0' ]);

        // Verifier l'existance de id
        if (isset(DB::table('users')->where('codeperso', request('id'))->get()[0]->codeperso)) {
            
            // Verifier le compte actuel du parrain au traver du montant

            $soldeactuel = DB::table('avoirs')->where('id_user', auth()->user()->id)->get()[0]->gainespece;
            //dd($soldeactuel < request('montant'));
            if ($soldeactuel < request('montant')) {
                flash("Votre solde est insuffissant!! 😢 🤔🤔🤔");
                return Back();
            } else {
                // Alors update compte expediteur : decrementer
                $soldeac = $soldeactuel - request('montant');
                DB::table('avoirs')
                    ->where('id_user', auth()->user()->id)
                    ->update([
                    'gainespece' => $soldeac
                    ]);

                // Alors update compte destinataire : incrementer
                $iddest = DB::table('users')->where('codeperso', request('id'))->get()[0]->id;
                $soldeactuel = DB::table('avoirs')->where('id_user', $iddest)->get()[0]->gainespece;
                $soldeac = $soldeactuel + request('montant');
                DB::table('avoirs')
                    ->where('id_user', $iddest)
                    ->update([
                    'gainespece' => $soldeac
                    ]);

                // Mettre a jour le compte admin
                $soldeactue = DB::table('systemadmins')->where('id_AdminPrincipal', auth()->user()->id)->get()[0]->id_AdminPrincipal;
                $soldea = $soldeactue + request('montant');
                DB::table('systemadmins')
                    ->where('id_AdminPrincipal', auth()->user()->id)
                    ->update([
                    'compteavoirsortant' => $soldea
                    ]);
                flash("Transfert éffectuer avec succès");
                return Back();
            }
            
        } else {
            flash("L'identifiant n'existe pas");
            return Back();
        }
        
    }

    public function getprofiladmin()
    {
        $users = DB::table('users')
                     ->where('id', auth()->user()->id)
                     ->get();
        $data = ['users' => $users];
        return view('admin.profiladmin', $data);
    }

    public function setprofiladmin(Request $request)
    {
        request()->validate([
            'nom' => 'required',
            'prenom' => 'required',
            'sexe' => 'required',
            'tel' => 'required' ]);

            DB::table('users')
            ->where('id', auth()->user()->id)
            ->update([
            'nom' => request('nom'),
            'prenom' =>request('prenom'),
            'sexe' =>request('sexe') ,
            'tel' =>request('tel') 
            ]);

            $users = DB::table('users')
                     ->where('id', auth()->user()->id)
                     ->get();
            $data = ['users' => $users];
        return view('admin.profiladmin', $data);
    }


    /* Les méthodes clients */
	public function index()
	{

        $cours = DB::table('articlepdfs')->select('id','path', 'titre', 'prix', 'description')->get();

        $data = ['cours' => $cours];

		return view('mlm.accueil', $data);
	}

	public function accueil()
	{
		
        $cours = DB::table('articlepdfs')->select('id','path', 'titre', 'prix', 'description')->get();
 
        $data = ['cours' => $cours];

        return view('mlm.accueil', $data);
	}

    public function affichearticle()
    {
        $cour = DB::table('articlepdfs')->select('path', 'titre', 'prix', 'description')->where('id', request('id'))->get();

        $data = ['cour' => $cour];

        return view('mlm.Article', $data);
    }

	public function contact()
	{
		return view('mlm.contact');
	}

    public function setcontact()
    {
        $nom = request('name');
        $email = request('email');
        $tel = request('phone');
        $message = request('message');

        $mes = Notificationcontact::create([
            'Nom' => $nom, 
            'Email' => $email, 
            'Tel' => $tel, 
            'Message' => $message
        ]);

        flash('Message envoyé avec succès!!! Consulter votre mail dans 1h pour avoir la réponse à votre préoccupation. SSI vous remercie.');
        return Back();
    }

	public function galerie()
	{
        $image = DB::table('galeries')->select('path', 'image', 'id_user')->get();

        $data = ['images' => $image];

		return view('mlm.galerie', $data);
	}

    public function getgalerie()
    {
        return view('admin.creergalerie');   
    }

    public function setgalerie()
    {
        request()->validate([
            'img' => ['required', 'mimes:png'],
           'titre' => 'required',
        ]);

        $path = request('img')->store('galerie', 'public');

        $image = './img';

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Galerie::create([
            'path' => $path,
            'image' => request('titre'), 
            'id_user' => auth()->user()->id
        ]);

        flash('Ajout avec succès!!!');
        return Back();

    }

    public function evernement()
    {
        $image = DB::table('evenements')->select('path', 'image', 'date', 'lieu', 'heure', 'description', 'id_user')->get();

        $data = ['images' => $image];

        return view('mlm.evernement', $data);
    }

    public function getevernement()
    {
        return view('admin.creerevernement');   
    }

    public function setevernement()
    {
        request()->validate([
            'img' => ['required', 'mimes:png'],
           'titre' => 'required',
           'date' => 'required',
           'lieu' => 'required',
           'heure' => 'required',
           'description' => 'required',
        ]);

        $path = request('img')->store('evenement', 'public');

        $image = './img';

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Evenement::create([
            'path' => $path,
            'image' => request('titre'),
            'date' => request('date'), 
            'lieu' => request('lieu'), 
            'heure' => request('heure'), 
            'description' => request('description'), 
            'id_user' => auth()->user()->id
        ]);

        flash('Ajout avec succès!!!');
        return Back();
    }

    public function propos()
    {
        return view('mlm.propos');
    }

    public function seconnecter()
    {
        return view('authentification.login');
    }

    public function clientdashboard()
    {
        $type = auth()->user()->type;

        if ($type == "client") {
            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

            $users = DB::table('users')
                     ->where('parrain', auth()->user()->codeunique)
                     ->get();

            $filleuladmin = DB::table('niveaux')->select('nombredefilleul', 'id_user')->where('id_user', auth()->user()->id)->get();

            $data = ['gains' => $gains, 'filleuls' => $users ,'filleuladmin' => $filleuladmin];
            return view('client.dashboard', $data);
        }
        if ($type == "admin") {

            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

            $compterecu = DB::table('systemadmins')->select('compteavoirrecu', 'compteavoirsortant')->where('id_AdminPrincipal', auth()->user()->id)->get();

             $users = DB::table('users')
                     ->select(DB::raw('count(*) as user_count'))
                     ->where('type', 'client')
                     ->get()[0]->user_count;
            $filleuladmin = DB::table('niveaux')->select('nombredefilleul', 'id_user')->where('id_user', auth()->user()->id)->get();

            $userslist = DB::table('users')
                     ->where('parrain', auth()->user()->codeunique)
                     ->get();

            $data = ['gains' => $gains, 'compterecu' => $compterecu, 'filleuls' => $userslist, 'all' => $users, 'filleuladmin' => $filleuladmin];
            return view('admin.dashboard', $data);
        }
    }

    public function admindashboard()
    {
        //return view('client.dashboard');
        
        $type = auth()->user()->type;

        if ($type == "client") {
            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

             $filleuladmin = DB::table('niveaux')->select('nombredefilleul', 'id_user')->where('id_user', auth()->user()->id)->get();

             $users = DB::table('users')
                     ->where('parrain', auth()->user()->codeunique)
                     ->get();

            $data = ['gains' => $gains, 'filleuls' => $users, 'filleuladmin' => $filleuladmin];
            return view('client.dashboard', $data);
        }
        if ($type == "admin") {
            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();
            $compterecu = DB::table('systemadmins')->select('compteavoirrecu', 'compteavoirsortant')->where('id_AdminPrincipal', auth()->user()->id)->get();
            $users = DB::table('users')
                     ->select(DB::raw('count(*) as user_count'))
                     ->where('type', 'client')
                     ->get()[0]->user_count;
            $filleuladmin = DB::table('niveaux')->select('nombredefilleul', 'id_user')->where('id_user', auth()->user()->id)->get();
            $userslist = DB::table('users')
                     ->where('parrain', auth()->user()->codeunique)
                     ->get();
            $data = ['gains' => $gains, 'compterecu' => $compterecu, 'filleuls' => $userslist, 'all' => $users, 'filleuladmin' => $filleuladmin];

            return view('admin.dashboard', $data);
        } 
    }

    public function clientregle()
    {
        return view('client.regle');
    }

    public function clientformation()
    {
        // recuperation de la base de donnée
        $formation = DB::table('mesformations')->select('id','titre', 'doc', 'id_user')->get();

        $data = ['formations' => $formation];
        return view('client.formation', $data);
    }

    public function clientformationdelete()
    {
        DB::table('mesformations')->where('id', request('id'))->delete();

        flash("Mail envoyé!!!");
        return Back();
        
    }

    /*  ****** 1 ********* */
    public function clientmesfilleuls()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.mesfilleuls', $data);
    }

    /*  ****** 2 ********* */
    public function clientmesfilleuls2()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape2', $data);
    }

    /*  ****** 3 ********* */
    public function clientmesfilleuls3()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape3', $data);
    }

    /*  ****** 4 ********* */
    public function clientmesfilleuls4()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape4', $data);
    }

    /*  ****** 5 ********* */
    public function clientmesfilleuls5()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape5', $data);
    }

    /*  ****** 6 ********* */
    public function clientmesfilleuls6()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape6', $data);
    }

    /*  ****** 7 ********* */
    public function clientmesfilleuls7()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape7', $data);
    }

    /*  ****** 8 ********* */
    public function clientmesfilleuls8()
    {

        $moi = DB::table('users')->select('email', 'codeunique', 'nomuser', 'codeperso')->where('id', auth()->user()->id)->get();

        $mesfilleuls = DB::table('users')
            ->select('email', 'nomuser', 'codeperso')
            ->where('parrain', $moi[0]->codeunique)
            ->orderBy('created_at', 'ASC')
            ->get();

        $data = [
            'moi' => $moi,
            'mesfilleuls' => $mesfilleuls
        ];

        return view('client.etape8', $data);
    }

    public function clientgains()
    {
        $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

        // mail
        // code
        $code = "";
        $data = ['gains' => $gains, 'redirect' => "gains", 'xxx' => $code];
        return view('client.gain', $data);
    }

    public function adminlogout()
    {
        auth()->logout();
        return redirect('/connexion');   
    }

    public function get_ip() {
        // IP si internet partagé
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        // IP derrière un proxy
        elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        // Sinon : IP normale
        else {
            return (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');
        }
    }

    public function saveseconnecter(Request $request)
    {

        request()->validate([
            'mail' => 'required|string|max:255',
            'password' => 'required'
        ]);

        $resultat = auth()->attempt([
            'nomuser' => request('mail'),
            'password' => request('password')
        ]);

        if ($resultat) {

            $activation = DB::table('users')
                ->select('compteactive')
                ->where('nomuser', request('mail'))
                ->get()[0]->compteactive;

            if ($activation == "oui") {
                
                if (IndexController::users(request('mail'))) {

                    $email = DB::table('users')
                            ->select('email')
                            ->where('nomuser', request('mail'))
                            ->get()[0]->email;

                    $ip = IndexController::get_ip();


                    // Envoie vers le mail
                    $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                    $message .= "<br>";
                    $message .= "<br>";

                    $sujet = "Connexion réussi!!!";
                    $objet = "Vous etre connecté à votre compte SSI";
                    IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                    return redirect('/admin/dashboard');    
                }
                if (!IndexController::users(request('mail'))) {

                    $email = DB::table('users')
                            ->select('email')
                            ->where('nomuser', request('mail'))
                            ->get()[0]->email;

                    $ip = IndexController::get_ip();

                    // Envoie vers le mail
                    $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                    $message .= "<br>";
                    $message .= "<br>";

                    $sujet = "Connexion réussi!!!";
                    $objet = "Vous etre connecté à votre compte SSI";
                    IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                    return redirect('/dashboard');    
                }                
            }
            else
            {
                $data = ['id_user' => auth()->user()->id ];
                return view('authentification.effectuerpayement', $data);
            }

        } else {

            $resultat = auth()->attempt([
            'codeperso' => request('mail'),
            'password' => request('password')
            ]);

            if ($resultat) {

                $activation = DB::table('users')
                    ->select('compteactive')
                    ->where('codeperso', request('mail'))
                    ->get()[0]->compteactive;

                if ($activation == "oui") {
                    
                    if (IndexController::usersid(request('mail'))) {
                    
                        $email = DB::table('users')
                            ->select('email')
                            ->where('codeperso', request('mail'))
                            ->get()[0]->email;

                        $ip = IndexController::get_ip();

                        // Envoie vers le mail
                        $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                        $message .= "<br>";
                        $message .= "<br>";

                        $sujet = "Connexion réussi!!!";
                        $objet = "Vous etre connecté à votre compte SSI";
                        IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                        return redirect('/admin/dashboard');    
                    }
                    if (!IndexController::usersid(request('mail'))) {
             
                        $email = DB::table('users')
                            ->select('email')
                            ->where('codeperso', request('mail'))
                            ->get()[0]->email;

                            $ip = IndexController::get_ip();

                            // Envoie vers le mail
                            $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                            $message .= "<br>";
                            $message .= "<br>";

                            $sujet = "Connexion réussi!!!";
                            $objet = "Vous etre connecté à votre compte SSI";
                            IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);
                        return redirect('/dashboard');    
                    }                
                }
                else
                {
                    $data = ['id_user' => auth()->user()->id ];
                    return view('authentification.effectuerpayement', $data);
                }

            }
        }
        return Back()->withInput()->withErrors([
                    'mail' => 'Veuillez vérifier le pseudo ou identifiant code',
                    'password' => 'Veuillez vérifier le mot de passe'
                ]);
    }

    public function users($value)
    {
        // Verification du type de l'utilisateur
        $var = DB::table('users')
            ->select('type')
            ->where('nomuser', $value)
            ->get()[0]->type;

        if ($var == "admin") {
            return true;
        }
        if ($var == "client") {
            return false;
        }
    }

    public function usersid($value)
    {
        // Verification du type de l'utilisateur
        $var = DB::table('users')
            ->select('type')
            ->where('codeperso', $value)
            ->get()[0]->type;

        if ($var == "admin") {
            return true;
        }
        if ($var == "client") {
            return false;
        }
    }

    public function sedeconnecter(Request $request)
    {
        auth()->logout();
        return redirect('/connexion');
    }

    public function inscription()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();

        $monnaie = DB::table('systemadmins')
            ->select('Monnaie')
            ->get();

        $pays = DB::table('pays')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps, 'pays' => $pays, 'monnaie' => $monnaie];

        return view('authentification.register', $data);   
    }

    public function getfogot()
    {
        return view('authentification.passwords.getmail');
    }

    public function fogot(Request $request)
    {

        request()->validate([
            'mail' => 'required|string|email|max:255',
            'codeperso' => 'required'
        ]);

        // Générer message
        $string = "";
        $universal_key = 12;

        $user_ramdom_key = 
    "(aLABbC0cEd1[eDf2FghR3ij4kYXQl5Um-OPn6pVq7rJs8*tuW9I+vGw@xHTy&#)K]Z%§!M_S";
        srand((double)microtime()*time());
        for($i=0; $i<$universal_key; $i++) {
        $string .= $user_ramdom_key[rand()%strlen($user_ramdom_key)];
        }

        // Envoie de mail
        $message = $string;

        IndexController::EnvoieMail(request('mail'), $message, "Réinitialisation de mot de passe de l'identifiant".request('codeperso')." :", "Réinitialiser votre mot de passe en renseignant l'information qui suit dans le site");
        // Recuperer d'abord l'adresse email depuis une fenetre
        flash("Mail envoyé!!!");
        $data = ['mail'=> request('mail'), 'message'=> $message, 'codeperso' => request('codeperso')];
        return view('authentification.passwords.forgot-password', $data);
    }

    public function rfogot()
    {
        IndexController::EnvoieMail(request('mail'), request('message'), "Réinitialisation de mot de passe", "Réinitialiser votre mot de passe en renseignant l'information qui suit dans le site");
        // Recuperer d'abord l'adresse email depuis une fenetre
        flash("Mail renvoyé!!!");
        $data = ['mail'=> request('mail'), 'message'=> request('message')];
        return Back();
        //return view('authentification.passwords.forgot-password', $data);   
    }

    public function setfogot(Request $request)
    {
        request()->validate([
            'password' => 'required',
            'passwordbis' => 'required',
            'mes' =>'required'
        ]);

        if (request('password') != request('passwordbis')) {
            flash("Erreur!!! Mot de passe incorrect. Veuillez verifier les mots de passe")->error();
            $data = ['mail'=> request('mail'), 'message'=> request('message'), 'codeperso' => request('codeperso')];
            return view('authentification.passwords.forgot-password', $data);
        }


        $mail = request('mail');
        //dd($mail);
        if ($mail != "") {
            
            if (request('mes') != request('message')) {
                flash("Les informations ne sont pas correct.");
                $data = ['mail'=> request('mail'), 'message'=> request('message'), 'codeperso' => request('codeperso')];
                return view('authentification.passwords.forgot-password', $data);
                //return Back();
            }
            else
            {
                $mdp = DB::table('users')
                    ->where('email', request('mail'))
                    ->where('codeperso', request('codeperso'))
                    ->update(['password' => bcrypt(request('password'))]);

                return redirect('/connexion');
            }
        }
        else
        {
            flash("Erreur!!! Votre session à expirer. Veuillez réeassayer la réinitialisation")->error();
            $data = ['mail'=> request('mail'), 'message'=> request('message'), 'codeperso' => request('codeperso')];
            return view('authentification.passwords.forgot-password', $data);
        }

        flash("Les informations ne sont pas correct.");
        return Back();
    }

    public function getajoutfilleul()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();

        $monnaie = DB::table('systemadmins')
            ->select('Monnaie')
            ->get();

        $pays = DB::table('pays')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps, 'pays' => $pays, 'monnaie' => $monnaie];
        return view('client.ajoutfilleul', $data);
    }

    public function getnouveaufilleul()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();
        $monnaie = DB::table('systemadmins')
                    ->select('Monnaie')
                    ->get();

         $pays = DB::table('pays')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps, 'pays' => $pays, 'monnaie' => $monnaie];
        return view('admin.nouveaufilleul', $data);
    }

    public function ajoutfilleul()
    {
        request()->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'pays' => 'required|max:255',
            'tel' => 'required|int',
            'mail' => 'required|string|email|max:255',
            'educ' => 'required|max:255',
            'sexe' => 'required|max:10',
            'parrain' => 'max:7',
            'pseudo' => 'required|string|max:255',
            'password' => 'required',
            'passwordbis' => 'required',
            'pack' => 'required',
            'payerf' =>'required',
        ]);

        if (request('password') != request('passwordbis')) {
            flash("Mot de passe incorrect! Veuillez vérifier")->error();
            return Back();
        }
        
        $temp_id = array("0");;

        $code_pays = '';
        if (isset(DB::table('pays')->select('code')->where('libelle', request('pays'))->get()[0]->code)) {
            $code_pays = DB::table('pays')->select('code')->where('libelle', request('pays'))->get()[0]->code;
        }

        // Verification si parrain existe

        $exit = IndexController::verificationCodeUnique(request('parrain'));

        // Préparation du compte du filleul
        $cocher = request('cocherparrain');

        //dd($exit);
        if ($exit != "0" && isset($cocher)) {
                flash("Veuillez entrer soit  votre code parrain ou choisir 'Pas de code de parrainage'.")->error();
                return Back();
            }

        if ($exit != "0" || isset($cocher)) {
            // C'est bon
            // Le code de parrainage est bon
            
            $parrain = 0;

            if (isset($cocher)) { // Verification sur checkbox est true 
                // Si oui donner le code parrainage de l'administrateur

                // Code de parrainage de l'admin
                $parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
            }
            else
            {
                $parrain = request('parrain');
            }

            // Combien de compte à creer

            $nombreCompte = 0;

            switch (request('pack')) {
                case '10 $ SSI':
                    $nombreCompte = 1;
                    break;
                case '70 $ SSI':
                    $nombreCompte = 7;
                    break;
                case '630 $ SSI':
                    $nombreCompte = 63;
                    break;
                case '5110 $ SSI':
                    $nombreCompte = 511;
                    break;
                default:
                    flash('Erreur système. Code M1.')->error();
                    return Back();
                    break;
            }

            //  Payer  par parrain
            if (request('payerf') == 'NON'){
                flash("Vous n'avez que le choix de vous fait payer par votre parrain actuel")->error();
                return Back();
            }

            // Variable initialiser retour
            $data = [
                            'id_user' => 1,
                            'nombrefois' => 1,
                            'approbation' => ''
                        ];

            $pseudo_filleul = request('pseudo');


            // Boucle for 
            // nomuser varie = pseudo+i
            for ($i=0; $i < $nombreCompte; $i++) { 
                $temp_ps = $i + 1;
                $temp_pseudo = $pseudo_filleul.''.$temp_ps;
                //echo $i;


            // Si code parrain est de l'admin alors passe

            $var_type = DB::table('users')->select('type')->where('codeunique', $parrain)->get()[0]->type;

            if ($var_type == "admin") {
                // Générer un code Unique comme code de parrainage pour filleul

                $code_unique = IndexController::generercodeunique();

                $code_id_unique = IndexController::genereridunique();

                $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;

                if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => $temp_pseudo,
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                    $users_id = DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', $temp_pseudo)
                            ->get()[0]->id;

                    $data = [
                        'id_user' => $users_id
                    ];

                    array_push($temp_id, $users_id);

                    /* IndexController::EnvoieMail(request('mail'), "https://sourcedusuccesinternational.com/validerpayement", "Validation de compte sur SSI", "Cliquez sur le lien suivant pour finaliser votre inscription");                    
                    
                        flash("Demander à votre filleul de consulter sa boite mail pour valider le paiement et valider son inscription");
                        return Back(); */
                 }
                else
                {
                    flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                    return Back();

                }
            }
            else
            {// si non verifier le nombre de filleul ou d'etape du parrain
                $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

                // Vérification du nombre de filleul trouver
                $filleul = DB::table('users')
                     ->select(DB::raw('count(*) as user_count'))
                     ->where('parrain', $parrain)
                     ->get()[0]->user_count;
                    
                    // Verification de l'etape actuel du parrain

                    $etape_actuel = IndexController::Etape_ActuelParrain($var_id_parrain);

                    if($etape_actuel > 8)
                    {

                        // Veuillez demander un nouveau code de parrainage

                        $data = [
                            'id1' => $temp_id,
                            'payerf' => request('payerf'),
                            'position_actuel' => $temp_ps,
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => $code_pays.''.request('tel'), 
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => request('password'),
                            'pseudo' => $pseudo_filleul,
                            'moyendepayement' => $paiement_id,
                            'compteacreer' => $nombreCompte
                        ];
 
                        return view('authentification.valideparrain', $data);
                }
                else
                {
                    // Laisser passer

                    $code_unique = IndexController::generercodeunique();

                    $code_id_unique = IndexController::genereridunique();

                    $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;
                    
                    if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => $temp_pseudo,
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                        $users_id = DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', request('pseudo'))
                                ->get()[0]->id;

                        array_push($temp_id, $users_id);

                        }
                        else
                        {
                            flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                            return Back();

                        }
                    }
                }

            }
            
                        // Envoie mail d'approbation
                        $mailparrain = IndexController::MailParrain($parrain);
                        $codeapprobation = IndexController::generercodeapprobation();
                        IndexController::EnvoieMail($mailparrain, "Donnez lui ce code d'approbation : ".$codeapprobation." pour qu'il autorise son l'inscription. <br> Rassurez-vous d'avoir le minimum dans votre compte avoir", "Approbation de compte sur SSI", "Donner l'accord à un filleul de défalquer de votre compte pour s'incrire");

                        $result = json_encode([
                            'id_user' => $temp_id,
                            'nombrefois' => $nombreCompte,
                            'approbation' => $codeapprobation  
                        ]);

                        $data = [
                            'idres' => $result
                        ];
                        
                        // recuperer le premier id
                        return view('authentification.approbation', $data);
                        
        }
        else
        {   // renvoyer un message disant que le code de parrainage est inconnue et aucune option n'est cocher.

            flash("Le code de parrainage est inconnue et aucune option n'est cocher. Veuillez vérifier")->error();
            return Back();
        }
    }


    public function saveinscription(Request $request)
    {

        //dd(request('pack'));

        request()->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'pays' => 'required|max:255',
            'tel' => 'required|int',
            'mail' => 'required|string|email|max:255',
            'educ' => 'required|max:255',
            'sexe' => 'required|max:10',
            'parrain' => 'max:8',
            'pseudo' => 'required|string|max:255',
            'password' => 'required',
            'passwordbis' => 'required',
            'pack' => 'required',
            'payerf' =>'required',
        ]);

        if (request('password') != request('passwordbis')) {
            flash("Mot de passe incorrect! Veuillez vérifier")->error();
            return Back();
        }
        
        $temp_id = array("0");;

        
        //$codep = DB::table('pays')->select('code')->where('libelle', request('pays'))->get()[0]->code;
        $code_pays = '';
        if (isset(DB::table('pays')->select('code')->where('libelle', request('pays'))->get()[0]->code)) {
            $code_pays = DB::table('pays')->select('code')->where('libelle', request('pays'))->get()[0]->code;
        }

        // Verification si parrain existe

        $exit = IndexController::verificationCodeUnique(request('parrain'));

        // Préparation du compte du filleul
        $cocher = request('cocherparrain');

        //dd($exit);
        if ($exit != "0" && isset($cocher)) {
                flash("Veuillez entrer soit  votre code parrain ou choisir 'Pas de code de parrainage'.")->error();
                return Back();
            }

        if ($exit != "0" || isset($cocher)) {
            // C'est bon
            // Le code de parrainage est bon

            

            $parrain = 0;

            if (isset($cocher)) { // Verification sur checkbox est true 
                // Si oui donner le code parrainage de l'administrateur

                // Code de parrainage de l'admin
                $parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
            }
            else
            {
                $parrain = request('parrain');
            }

            
            // Combien de compte à creer

            $nombreCompte = 0;

            switch (request('pack')) {
                case '10 $ SSI':
                    $nombreCompte = 1;
                    break;
                case '70 $ SSI':
                    $nombreCompte = 7;
                    break;
                case '630 $ SSI':
                    $nombreCompte = 63;
                    break;
                case '5110 $ SSI':
                    $nombreCompte = 511;
                    break;
                default:
                    flash('Erreur système. Code M1.')->error();
                    return Back();
                    break;
            }

            //  Payer  par parrain
            if (request('payerf') == 'NON'){
                flash("Vous n'avez que le choix de vous fait payer par votre parrain actuel")->error();
                return Back();
            }

            // Variable initialiser retour
            $data = [
                            'id_user' => 1,
                            'nombrefois' => 1,
                            'approbation' => ''
                        ];

            $pseudo_filleul = request('pseudo');


            // Boucle for 
            // nomuser varie = pseudo+i
            for ($i=0; $i < $nombreCompte; $i++) { 
                $temp_ps = $i + 1;
                $temp_pseudo = $pseudo_filleul.''.$temp_ps;
                //echo $i;

                // Si code parrain est de l'admin alors passe

                $var_type = DB::table('users')
                    ->select('type')
                    ->where('codeunique', $parrain)
                    ->get()[0]->type;


                if ($var_type == "admin") {
                
                    // Générer un code Unique comme code de parrainage

                    $code_unique = IndexController::generercodeunique();
                    
                    $code_id_unique = IndexController::genereridunique();

                    $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;

                    if (!isset(DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', $temp_pseudo)
                                ->get()[0]->nomuser)) {

                        $create = User::create([
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => $code_pays.''.request('tel'), 
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => bcrypt(request('password')), 
                            'type' => "client",
                            'codeunique' => $code_unique, 
                            'otp' => '',
                            'nomuser' => $temp_pseudo,
                            'codeperso' => $code_id_unique,
                            'compteavoir' => '',
                            'parrain' => $parrain,
                            'moyendepayement' => $paiement_id
                        ]);

                        $users_id = DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', $temp_pseudo)
                                ->get()[0]->id;

                        array_push($temp_id, $users_id);
                        
                    }
                    else
                    {
                        flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                        return Back();

                    } 
                }
                else
                {// si non. je ne suis pas administrateur
                    //verifier le nombre de filleul ou d'etape du parrain
                    $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

                    // Vérification du nombre de filleul trouver
                    $filleul = DB::table('users')
                         ->select(DB::raw('count(*) as user_count'))
                         ->where('parrain', $parrain)
                         ->get()[0]->user_count;

                    // Verification de l'etape actuel du parrain

                    $etape_actuel = IndexController::Etape_ActuelParrain($var_id_parrain);

                    if($etape_actuel > 8)
                    {

                        // Veuillez demander un nouveau code de parrainage

                        $data = [
                            'id1' => $temp_id,
                            'payerf' => request('payerf'),
                            'position_actuel' => $temp_ps,
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => $code_pays.''.request('tel'), 
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => request('password'),
                            'pseudo' => $pseudo_filleul,
                            'moyendepayement' => $paiement_id,
                            'compteacreer' => $nombreCompte
                        ];
 
                        return view('authentification.valideparrain', $data);

                        //$parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;

                        //flash("Le parrain à atteint le seuil maximal. Veuillez lui demandé ou cocher l'option inconnue pour construire son nouveau réseau.")->error();
                        //return Back();
                    }
                    else
                    {
                        // Laisser passer

                        $code_unique = IndexController::generercodeunique();

                        $code_id_unique = IndexController::genereridunique();

                        $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;
                        
                        if (!isset(DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', $temp_pseudo)
                                ->get()[0]->nomuser)) {
                            
                        $create = User::create([
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => $code_pays.''.request('tel'), 
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => bcrypt(request('password')), 
                            'type' => "client", 
                            'codeunique' => $code_unique, 
                            'otp' => '', 
                            'nomuser' => $temp_pseudo,
                            'codeperso' => $code_id_unique,
                            'compteavoir' => '',
                            'parrain' => $parrain,
                            'moyendepayement' => $paiement_id
                        ]);

                            $users_id = DB::table('users')
                                    ->where('email', request('mail'))
                                    ->where('nomuser', $temp_pseudo)
                                    ->get()[0]->id;
                            array_push($temp_id, $users_id);

                        }
                        else
                        {
                            flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                            return Back();

                        }
                    }
                }

            }
            
                        // Envoie mail d'approbation
                        $mailparrain = IndexController::MailParrain($parrain);
                        $codeapprobation = IndexController::generercodeapprobation();
                        IndexController::EnvoieMail($mailparrain, "Donnez lui ce code d'approbation : ".$codeapprobation." pour qu'il autorise son l'inscription. <br> Rassurez-vous d'avoir le minimum dans votre compte avoir", "Approbation de compte sur SSI", "Donner l'accord à un filleul de défalquer de votre compte pour s'incrire");

                        $result = json_encode([
                            'id_user' => $temp_id,
                            'nombrefois' => $nombreCompte,
                            'approbation' => $codeapprobation  
                        ]);

                        $data = [
                            'idres' => $result
                        ];
                        
                        // recuperer le premier id
                        return view('authentification.approbation', $data);

            // Si le parrain atteint les  8 etapes alors impossible de continuer
        }
        else
        {   // renvoyer un message disant que le code de parrainage est inconnue et aucune option n'est cocher.

            flash("Le code de parrainage est inconnue et aucune option n'est cocher. Veuillez vérifier")->error();
            return Back();
        }
    }


    public function continueinscription(Request $request)
    {

        // Verification si parrain existe

        $exit = IndexController::verificationCodeUnique(request('parrain'));
        $temp_id = request('id1');
        // Préparation du compte du filleul
        $cocher = request('cocherparrain');

        if ($exit != "0" || isset($cocher)) {
            // C'est bon
            // Le code de parrainage est bon

            if ($exit != "0" && isset($cocher)) {
                flash("Veuillez entrer soit  votre code parrain ou choisir 'Pas de code de parrainage'.")->error();
                return Back();
            }

            $parrain = 0;

            if (isset($cocher)) { // Verification sur checkbox est true 
                // Si oui donner le code parrainage de l'administrateur

                // Code de parrainage de l'admin
                $parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
            }
            else
            {
                $parrain = request('parrain');
            }

            
            // Combien de compte à creer

            $nombreCompte = request('compteacreer');

            // Variable initialiser retour
            $data = [
                        'id_user' => 1,
                        'nombrefois' => 1
                    ];

            $pseudo_filleul = request('pseudo');

            // Boucle for 
            // nomuser varie = pseudo+i
            $depart = request('position_actuel') - 1;
            for ($i=$depart; $i < $nombreCompte; $i++) { 
                $temp_ps = $i + 1;
                $temp_pseudo = $pseudo_filleul.''.$temp_ps;

                // Si code parrain est de l'admin alors passe

                $var_type = DB::table('users')->select('type')->where('codeunique', $parrain)->get()[0]->type;


                if ($var_type == "admin") {
                
                    // Générer un code Unique comme code de parrainage

                    $code_unique = IndexController::generercodeunique();
                    
                    $code_id_unique = IndexController::genereridunique();

                    $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;

                    if (!isset(DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', $temp_pseudo)
                                ->get()[0]->nomuser)) {

                        $create = User::create([
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'),
                            'tel' => request('tel'),
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => bcrypt(request('password')), 
                            'type' => "client",
                            'codeunique' => $code_unique, 
                            'otp' => '',
                            'nomuser' => $temp_pseudo,
                            'codeperso' => $code_id_unique,
                            'compteavoir' => '',
                            'parrain' => $parrain,
                            'moyendepayement' => request('moyendepayement')
                        ]);

                        $users_id = DB::table('users')
                                    ->where('email', request('mail'))
                                    ->where('nomuser', $temp_pseudo)
                                    ->get()[0]->id;

                        array_push($temp_id, $users_id);
                        
                    }
                    else
                    {
                        flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                        return Back();

                    } 
                }
                else
                {// si non. je ne suis pas administrateur
                    //verifier le nombre de filleul ou d'etape du parrain
                    $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

                    // Vérification du nombre de filleul trouver
                    $filleul = DB::table('users')
                         ->select(DB::raw('count(*) as user_count'))
                         ->where('parrain', $parrain)
                         ->get()[0]->user_count;

                    // Verification de l'etape actuel du parrain

                    $etape_actuel = IndexController::Etape_ActuelParrain($var_id_parrain);

                    if($etape_actuel > 8)
                    {

                        // Veuillez demander un nouveau code de parrainage

                        $data = [
                            'id1' => $temp_id,
                            'payerf' => request('payerf'),
                            'position_actuel' => $temp_ps,
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => request('tel'),
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => request('password'),
                            'pseudo' => $pseudo_filleul,
                            'moyendepayement' => request('moyendepayement'),
                            'compteacreer' => $nombreCompte
                        ];
 
                        return view('authentification.valideparrain', $data);

                        //$parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;

                        //flash("Le parrain à atteint le seuil maximal. Veuillez lui demandé ou cocher l'option inconnue pour construire son nouveau réseau.")->error();
                        //return Back();
                    }
                    else
                    {
                        // Laisser passer

                        $code_unique = IndexController::generercodeunique();

                        $code_id_unique = IndexController::genereridunique();

                        $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;
                        
                        if (!isset(DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', $temp_pseudo)
                                ->get()[0]->nomuser)) {
                            
                        $create = User::create([
                            'nom' => request('nom'),
                            'prenom' => request('prenom'),
                            'sexe'=> request('sexe'), 
                            'tel' => request('tel'),
                            'compteactive' => "non",
                            'email' => request('mail'),
                            'password' => bcrypt(request('password')), 
                            'type' => "client", 
                            'codeunique' => $code_unique, 
                            'otp' => '', 
                            'nomuser' => $temp_pseudo,
                            'codeperso' => $code_id_unique,
                            'compteavoir' => '',
                            'parrain' => $parrain,
                            'moyendepayement' => $paiement_id
                        ]);

                        $users_id = DB::table('users')
                                    ->where('email', request('mail'))
                                    ->where('nomuser', $temp_pseudo)
                                    ->get()[0]->id;
                        array_push($temp_id, $users_id);
                        
                        }
                        else
                        {
                            flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                            return Back();

                        }
                    }
                }

            }


                            // Envoie mail d'approbation
                        $mailparrain = IndexController::MailParrain($parrain);
                        $codeapprobation = IndexController::generercodeapprobation();
                        IndexController::EnvoieMail($mailparrain, "Donnez lui ce code d'approbation : ".$codeapprobation." pour qu'il autorise son l'inscription. <br> Rassurez-vous d'avoir le minimum dans votre compte avoir", "Approbation de compte sur SSI", "Donner l'accord à un filleul de défalquer de votre compte pour s'incrire");

                        $result = json_encode([
                            'id_user' => $temp_id,
                            'nombrefois' => $nombreCompte,
                            'approbation' => $codeapprobation  
                        ]);

                        $data = [
                            'idres' => $result
                        ];
                        
                        // recuperer le premier id
                        return view('authentification.approbation', $data);
                            /*           
                            if (request('payerf') == 'NON'){
                                return view('authentification.effectuerpayement', $data);
                            }
                            else
                            {
                                return view('authentification.approbation', $data);
                            } */  


            // Si le parrain atteint les  8 etapes alors impossible de continuer
        }
        else
        {   // renvoyer un message disant que le code de parrainage est inconnue et aucune option n'est cocher.

            flash("Le code de parrainage est inconnue et aucune option n'est cocher. Veuillez vérifier")->error();
            //return Back();
        }
    }

    public function generercodeapprobation()
    {
        $code_unique = rand(10000, 99999);

        return 'appr'.$code_unique.'prou';
    }

    public function MailParrain($parrain)
    {
        $mail = DB::table('users')
                    ->where('codeunique', $parrain)
                    ->get()[0]->email;
        return $mail;
    }

    public function activeraccount()
    {
        return view('admin.activercompte');
    }

    // Valider payement à partir de l'API de transaction

    public function valideinscription()
    {
        $id = request('id');
        $act = request('active');
        if (isset($act)) {
            if(!isset(DB::table('users')
                    ->where('codeperso', $id)
                    ->get()[0]->id))
            {
                flash("Le filleul portant l'identifiant saisir n'existe pas");
                return Back();
            }
            else
            {
                $id = DB::table('users')
                    ->where('codeperso', $id)
                    ->get()[0]->id;
            }
        }

        $trans = '';
        if (isset($_GET['transaction_id'])) {
            $trans = $_GET['transaction_id'];
        }

        // Initialisation du compte avoir de l'utilisateur

        $id_avoirs = IndexController::user_init($id, $trans);

        $id_user = $id;

        $valeur_payer = 10;

        // Premiere translation du filleul

        //IndexController::first_Translation($id_user, $id_avoirs, $trans, $valeur_payer);

        // Premiere etapes consiste a mettre a jour les filleuls

        // Recuperer le parrain enregistrer pour l'utilisateur
        //dd($id_user);

        $codeunique_parrain = IndexController::mon_parrain($id_user);

        //dd($codeunique_parrain);
        $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

        // Verification de l'etape actuel du parrain

        $etape_actuel = IndexController::Etape_ActuelParrain($id_parrain);

        // Code parrain de l'administrateur du site

        $code_parrain_admin = IndexController::Code_Parrain_Admin();

        if ($etape_actuel > 8) {
            // Mon parrain n'est plus capable de me prendre comme filleul
            // Je beneficie du code parrain de l'administrateur du site

            $codeunique_parrain = $code_parrain_admin;

            // Mise à jour dans la table du client

            DB::table('users')
                ->where('id', $id_user)
                ->update(['codeunique' => $codeunique_parrain]);        
        }

        // Verification du code parrain

        $typeparrain = IndexController::TypeParrain($codeunique_parrain);

        if ($typeparrain == "admin") {
            // Recuperer id parrain

            $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

            $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

            $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

            DB::table('niveaux')
                ->where('id_user', $id_parrain)
                ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);
        }
        else
        {
            // verification du nombre possible pour le l'etape actuel du parrain dans la table etape

            $nombrepossible = IndexController::FilleulPossible($etape_actuel);

            $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

            if ($nbrefilleul < $nombrepossible) {
                $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

                DB::table('niveaux')
                    ->where('id_user', $id_parrain)
                    ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);       
            }
            else
            {
                if ($nbrefilleul == $nombrepossible) {
                    
                    // Augmente etape de +1
                    $etape_actuel_mise_a_jour = $etape_actuel + 1;
                    $etape_actuel = $etape_actuel + 1;

                    DB::table('niveaux')
                    ->where('id_user', $id_parrain)
                    ->update(['id_etape' => $etape_actuel_mise_a_jour]);

                    // Une etape valider; une valeur ajouter sur gain en espece

                    // Ajouter gain etape à chaque fois.
                    /*
                    // Recuperer valeur ajouter de l'etape valider
                    $valeurajout = IndexController::ValeurAjouterEtape($etape_actuel);

                    $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

                    $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $valeurajout;
                    DB::table('avoirs')
                                ->where('id_user', $id_parrain)
                                ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]); */   

                    // Bravo!!!!!!!!!!!!!!!!!!!!!!!
                    // Une etape franchise

                    // Mail si possible     

                    // initialiser nombrefilleul a 1
                    $nbrefilleul_mise_a_jour = 1;

                    DB::table('niveaux')
                        ->where('id_user', $id_parrain)
                        ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]); 
                }
                // En cas de probleme
            }
        }

        // Deuxieme etapes a mettre a jour les gains

        // Les pourcentage definir du systeme

        $pourcentageespece = IndexController::PourcentageFilleulEspece();

        $pourcentagevirtuel = IndexController::PourcentageFilleulVirtuel();

        // Calcule de la valeur en %

        $gain_espece = $valeur_payer * ($pourcentageespece / 100);

        $gain_virtuel = $valeur_payer * ($pourcentagevirtuel / 100);

        // alors le parrain beneficie de ces valeurs

        $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

        $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $gain_espece;
        DB::table('avoirs')
                    ->where('id_user', $id_parrain)
                    ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

        $gainsvirtuel_actuel = IndexController::VirtuelEspece($id_parrain);

        $gainsvirtuel_actuel_mise_a_jour = $gainsvirtuel_actuel + $gain_virtuel;
        DB::table('avoirs')
                    ->where('id_user', $id_parrain)
                    ->update(['gainvirtuel' => $gainsvirtuel_actuel_mise_a_jour]);

        // ajouter gain d'etape pour chaque filleul qui vient

        $valeurajout = IndexController::ValeurAjouterEtape($etape_actuel);
        $possiblefilleul = IndexController::FilleulPossible($etape_actuel);
        $gainsespece_actuel = IndexController::VirtuelEspece($id_parrain);

        $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + ($valeurajout / $possiblefilleul);
        DB::table('avoirs')
                ->where('id_user', $id_parrain)
                ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

        // Compte de l'administrateur
        $gainsadmin_actuel = IndexController::AdminCompteRecu();

        $gainsadmin_actuel_mise_a_jour = $gainsadmin_actuel + $valeur_payer;
        DB::table('systemadmins')
                    ->where('Admin', 'oui')
                    ->update(['compteavoirrecu' => $gainsadmin_actuel_mise_a_jour]);

        // Activer le compte

        DB::table('users')
                ->where('id', $id_user)
                ->update(['compteactive' => 'oui']);

        $niv = Niveau::create([
            'nombredefilleul' => 0, 
            'id_user' => $id_user,
            'id_etape' => 1
        ]);

        $u = DB::table('users')
            ->select('nom', 'prenom', 'sexe', 'email', 'codeunique', 'nomuser', 'codeperso', 'parrain')
            ->where('id', $id_user)
            ->get();

        $nomparrain = IndexController::NomParrain($u[0]->parrain);
                    $destinataire = $u[0]->email;
                
                     $message  = "Monsieur Madame, <br> <b>".$u[0]->prenom." ".$u[0]->nom.",</b> votre compte est valider. <br> <br> Bienvenu à la <b>Source du Succès International.<b> <br> 
                     <br>Votre code de parrainage est la suivante : ".$u[0]->codeunique." <br><br>
                     Le nom de votre parrain est : ".$nomparrain." <br> <br> 
                     Vous pouvez vous connecter grace à l'identifiant suivante ".$u[0]->codeperso." ou à votre pseudo ".$u[0]->nomuser;
                   IndexController::EnvoieMailConnexion($destinataire, $message, "Compte crée avec succes", "");

        $act = request('active');
        if (isset($act)) {
                flash("Le compte du filleul activé avec succès!!!");
                return Back();
        }

        return view('authentification.validerregister');
    }


    /* Des methodes pour la validation */

    public function AdminCompteSortant()
    {
        return DB::table('systemadmins')->select('compteavoirsortant')->where('Admin', 'oui')->get()[0]->compteavoirsortant;   
    }

    public function AdminCompteRecu()
    {
        return DB::table('systemadmins')->select('compteavoirrecu')->where('Admin', 'oui')->get()[0]->compteavoirrecu;   
    }

    public function VirtuelActuel($id_parrain)
    {
       return DB::table('avoirs')->select('gainvirtuel')->where('id_user', $id_parrain)->get()[0]->gainvirtuel; 
    }  

    public function VirtuelEspece($id_parrain)
    {
        return DB::table('avoirs')->select('gainespece')->where('id_user', $id_parrain)->get()[0]->gainespece;  
    }

    public function PourcentageFilleulEspece()
    {
        return DB::table('systemadmins')->select('pourcentagefilleulespece')->where('Admin', 'oui')->get()[0]->pourcentagefilleulespece;
    }

    public function PourcentageFilleulVirtuel()
    {
        return DB::table('systemadmins')->select('pourcentagefilleulvirtuel')->where('Admin', 'oui')->get()[0]->pourcentagefilleulvirtuel;
    }

    public function ValeurAjouterEtape($etape)
    {
        return DB::table('etapes')->select('ValeurAjouter')->where('id', $etape)->get()[0]->ValeurAjouter;
    }

    public function FilleulPossible($etape)
    {
        return DB::table('etapes')->select('NombrePossible')->where('id', $etape)->get()[0]->NombrePossible;
    }

    public function NbrefilleulActuel($id_user)
    {
        return DB::table('niveaux')->select('nombredefilleul')->where('id_user', $id_user)->get()[0]->nombredefilleul;
    }

    public function TypeParrain($valeur)
    {
        return DB::table('users')->select('type')->where('codeunique', $valeur)->get()[0]->type;
    }

    public function Code_Parrain_Admin()
    {
        return DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
    }

    public function user_init($id, $trans)
    {
        $user_ini = Avoir::create([
                'gainvirtuel' => 0, 
                'gainespece' => 0, 
                'id_user' => $id,
                'translation_first' => $trans
            ]);

        return DB::table('avoirs')->select('id')->where('id_user', $id)->get()[0]->id;
    }

    public function first_Translation($user, $avoirs, $trans, $valeur_payer)
    {
        $user_ini = Translationuser::create([
                'id_user' => $user, 
                'id_avoir' => $avoirs,
                'translation_id' => $trans, 
                'montantrecu' => 0, 
                'montantenvoye' => $valeur_payer
            ]);

        return 0;
    }

    public function mon_parrain($id)
    {
        return DB::table('users')->select('parrain')->where('id', $id)->get()[0]->parrain;
    }

    public function id_mon_parrain($codeunique)
    {
        return DB::table('users')->select('id')->where('codeunique', $codeunique)->get()[0]->id;  
    }

    public function NomParrain($code)
    {
        $t = DB::table('users')->select('nom', 'prenom')->where('codeunique', $code)->get();
        return $t[0]->nom." ".$t[0]->prenom; 
    }

    public function Etape_ActuelParrain($id_parrain)
    {

        //dd($id_parrain);
        return DB::table('niveaux')->select('id_etape')->where('id_user', $id_parrain)->get()[0]->id_etape; 
    }

    /* End Methode */

    public function traitementinscription()
    {

        // Avant d'enregistrer le filleul

        // Verifier le message de retour de kkiapaye

        // Enregistrer l'information dans une table translaction par exemple.

        $parrain = "00000001";
        // Vérification du parrain
        $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

        // Vérification de l'etape du parrain
        $etape_actuel = DB::table('niveaux')->select('id_etape')->where('id_user', $var_id_parrain)->get()[0]->id_etape;

        // Nombre de filleul possible pour cette etape
        $nombre_filleul_possible = DB::table('etapes')->select('NombrePossible')->where('id', $etape_actuel)->get()[0]->NombrePossible;

        // Vérification du nombre de filleul trouver
        $filleul = DB::table('users')
                ->select(DB::raw('count(*) as user_count'))
                ->where('parrain', $parrain)
                ->get()[0]->user_count;

        // Incrémenter le compte des avoirs du parrain de
        // 500 dans gain en espece et 500 dans gain virtuel et somme dans somme

        // Enregistrer dans la table niveaux : le nombre de filleul
        // id_user et id_etape

        // Activer compte filleul
    }

    public function validerpayement()
    {
        return view('authentification.effectuerpayement');
    }

    public function traitementpayement()
    {
        $idres = request('idres');
        $valeur = json_decode($idres, true);
        //dd($valeur['id_user'][0]);

        $approbation = $valeur['approbation'];



        // Verification de l'approbation 
        if ($approbation == request('parraincode')) {
            
            $tableiduser = $valeur['id_user'];
            $nombrefois = $valeur['nombrefois'];

            for ($i=0; $i < $nombrefois; $i++) {
                $iteration = $i + 1; 
                $useridu = $tableiduser[$iteration];

                $active = DB::table('users')->select('compteactive')->where('id', $useridu)->get()[0]->compteactive;

                if ($active == "non") {
                    
                /* Défalquer le nombre de fois du compte à crée dans le compte du parrain */

                //Verifier si le solde du parrain suffit
                $pa = DB::table('users')->select('parrain')->where('id', $useridu)->get()[0]->parrain;

                $id_pa = DB::table('users')->select('id')->where('codeunique', $pa)->get()[0]->id;

                $verifsolde = DB::table('avoirs')->select('gainespece')->where('id_user', $id_pa)->get()[0]->gainespece;

                if ($verifsolde >= 10) {
                                $soldea = $verifsolde - 10;
                                DB::table('avoirs')
                                    ->where('id_user', $id_pa)
                                    ->update(['gainespece' => $soldea]);
                                } else {
                                    return view('echec');
                                }


                /* Methode de validation */

                $id = $useridu;

                $trans = '';
                if (isset($_GET['transaction_id'])) {
                    $trans = $_GET['transaction_id'];
                }

                // Initialisation du compte avoir de l'utilisateur

                $id_avoirs = IndexController::user_init($id, $trans);

                $id_user = $id;

                $valeur_payer = 10;

                // Premiere translation du filleul

                //IndexController::first_Translation($id_user, $id_avoirs, $trans, $valeur_payer);

                // Premiere etapes consiste a mettre a jour les filleuls

                // Recuperer le parrain enregistrer pour l'utilisateur
                //dd($id_user);

                $codeunique_parrain = IndexController::mon_parrain($id_user);

                //dd($codeunique_parrain);
                $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

                // Verification de l'etape actuel du parrain

                $etape_actuel = IndexController::Etape_ActuelParrain($id_parrain);

                // Code parrain de l'administrateur du site

                $code_parrain_admin = IndexController::Code_Parrain_Admin();

                if ($etape_actuel > 8) {
                    // Mon parrain n'est plus capable de me prendre comme filleul
                    // Je beneficie du code parrain de l'administrateur du site

                    $codeunique_parrain = $code_parrain_admin;

                    // Mise à jour dans la table du client

                    DB::table('users')
                        ->where('id', $id_user)
                        ->update(['codeunique' => $codeunique_parrain]);        
                }

                // Verification du code parrain

                $typeparrain = IndexController::TypeParrain($codeunique_parrain);

                if ($typeparrain == "admin") {
                    // Recuperer id parrain

                    $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

                    $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

                    $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

                    DB::table('niveaux')
                        ->where('id_user', $id_parrain)
                        ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);
                }
                else
                {
                    // verification du nombre possible pour le l'etape actuel du parrain dans la table etape

                    $nombrepossible = IndexController::FilleulPossible($etape_actuel);

                    $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

                    if ($nbrefilleul < $nombrepossible) {
                        $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

                        DB::table('niveaux')
                            ->where('id_user', $id_parrain)
                            ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);       
                    }
                    else
                    {
                        if ($nbrefilleul == $nombrepossible) {
                            
                            // Augmente etape de +1
                            $etape_actuel_mise_a_jour = $etape_actuel + 1;
                            $etape_actuel = $etape_actuel + 1;

                            DB::table('niveaux')
                            ->where('id_user', $id_parrain)
                            ->update(['id_etape' => $etape_actuel_mise_a_jour]);

                            // Une etape valider; une valeur ajouter sur gain en espece

                            // Ajouter gain etape à chaque fois.
                            /*
                            // Recuperer valeur ajouter de l'etape valider
                            $valeurajout = IndexController::ValeurAjouterEtape($etape_actuel);

                            $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

                            $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $valeurajout;
                            DB::table('avoirs')
                                        ->where('id_user', $id_parrain)
                                        ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]); */   

                            // Bravo!!!!!!!!!!!!!!!!!!!!!!!
                            // Une etape franchise

                            // Mail si possible     

                            // initialiser nombrefilleul a 1
                            $nbrefilleul_mise_a_jour = 1;

                            DB::table('niveaux')
                                ->where('id_user', $id_parrain)
                                ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]); 
                        }
                        // En cas de probleme
                    }
                }

                // Deuxieme etapes a mettre a jour les gains

                // Les pourcentage definir du systeme

                $pourcentageespece = IndexController::PourcentageFilleulEspece();

                $pourcentagevirtuel = IndexController::PourcentageFilleulVirtuel();

                // Calcule de la valeur en %

                $gain_espece = $valeur_payer * ($pourcentageespece / 100);

                $gain_virtuel = $valeur_payer * ($pourcentagevirtuel / 100);

                // alors le parrain beneficie de ces valeurs

                $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

                $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $gain_espece;
                DB::table('avoirs')
                            ->where('id_user', $id_parrain)
                            ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

                $gainsvirtuel_actuel = IndexController::VirtuelEspece($id_parrain);

                $gainsvirtuel_actuel_mise_a_jour = $gainsvirtuel_actuel + $gain_virtuel;
                DB::table('avoirs')
                            ->where('id_user', $id_parrain)
                            ->update(['gainvirtuel' => $gainsvirtuel_actuel_mise_a_jour]);

                // ajouter gain d'etape pour chaque filleul qui vient

                $valeurajout = IndexController::ValeurAjouterEtape($etape_actuel);
                $possiblefilleul = IndexController::FilleulPossible($etape_actuel);
                $gainsespece_actuel = IndexController::VirtuelEspece($id_parrain);

                $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + ($valeurajout / $possiblefilleul);
                DB::table('avoirs')
                        ->where('id_user', $id_parrain)
                        ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

                // Compte de l'administrateur
                $gainsadmin_actuel = IndexController::AdminCompteRecu();

                $gainsadmin_actuel_mise_a_jour = $gainsadmin_actuel + $valeur_payer;
                DB::table('systemadmins')
                            ->where('Admin', 'oui')
                            ->update(['compteavoirrecu' => $gainsadmin_actuel_mise_a_jour]);

                // Activer le compte

                DB::table('users')
                        ->where('id', $id_user)
                        ->update(['compteactive' => 'oui']);

                $niv = Niveau::create([
                    'nombredefilleul' => 0, 
                    'id_user' => $id_user,
                    'id_etape' => 1
                ]);

                $u = DB::table('users')
                    ->select('nom', 'prenom', 'sexe', 'email', 'codeunique', 'nomuser', 'codeperso', 'parrain')
                    ->where('id', $id_user)
                    ->get();

                    $nomparrain = IndexController::NomParrain($u[0]->parrain);
                    $destinataire = $u[0]->email;
                
                     $message  = "Monsieur Madame, <br> <b>".$u[0]->prenom." ".$u[0]->nom.",</b> votre compte est valider. <br> <br> Bienvenu à la <b>Source du Succès International.<b> <br> 
                     <br>Votre code de parrainage est la suivante : ".$u[0]->codeunique." <br><br>
                     Le nom de votre parrain est : ".$nomparrain." <br> <br> 
                     Vous pouvez vous connecter grace à l'identifiant suivante ".$u[0]->codeperso." ou à votre pseudo ".$u[0]->nomuser;
                   IndexController::EnvoieMailConnexion($destinataire, $message, "Compte crée avec succes", "");

                
                   }
                /* End moethode de validation */
            }
            return view('authentification.validerregister');

        } else {
            flash("Le code saisir est incorrect. Veuillez vérifier")->error();
            //return Back();
        }
        
        
    }

    public function getajoutercours()
    {
        return view('admin.upload_cours');   
    }

    public function setajoutercours()
    {
        request()->validate([
            'cours' => ['required', 'mimes:pdf'],
            'cout' => 'required',
            'titre' => 'required',
            'description' => 'required'
        ]);

        $path = request('cours')->store('cours', 'public');

        $image = './img';

        //$b = IndexController::extract($path, './img', 'png');

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Articlepdf::create([
            'path' => $path,
            'image' => $image,
            'titre' => request('titre'),
            'prix' => request('cout'),
            'description' => request('description')
        ]);

        flash('Ajout avec succès!!!');
        return Back();

    }

    const FORMAT_JPG = 'jpg';
    const FORMAT_PNG = 'png';

    /**
     * @param string $source      source filepath
     * @param string $destination destination filepath
     * @param string $format      destination format
     *
     * @return bool
     */
    public function extract($source, $destination, $format = self::FORMAT_PNG)
    {
        if (!extension_loaded('Imagick')) {
            return false;
        }

        $imagick = new \Imagick($source . '[0]');
        $imagick->setFormat($format);

        return $imagick->writeImage($destination);
    }

    public function verificationCodeUnique($value)
    {
        if (isset(DB::table('users')->select('codeunique')->where('codeunique', $value)->get()[0]->codeunique)) {
            
            return DB::table('users')->select('codeunique')->where('codeunique', $value)->get()[0]->codeunique;
            
        } else {
            return '0';
        }
    }

    public function generercodeunique()
    {
        $code_unique = rand(10000000, 99999999);

        if (IndexController::verificationCodeUnique($code_unique) == 0) {
            return $code_unique;
        }
        else
        {
            IndexController::generercodeunique();
        }
    }

    public function verificationIdUnique($value)
    {
        if (isset(DB::table('users')->select('codeperso')->where('codeperso', $value)->get()[0]->codeperso)) {
            
            return DB::table('users')->select('codeperso')->where('codeperso', $value)->get()[0]->codeperso;
            
        } else {
            return '0';
        }   
    }

    public function genereridunique()
    {
        $id_unique = rand(10000000, 99999999);

        if (IndexController::verificationIdUnique($id_unique) == 0) {
            return $id_unique;
        }
        else
        {
            IndexController::genereridunique();
        }
    }

	public function create()
    {
        //$pdf = app('Fpdf');


        //return view('admins.PDFOM');

        //return PDF::loadFile(public_path().'../resources/views/admins/PDFOM')->save('/path-to/my_stored_file.pdf')->stream('download.pdf');

        //$data = ['title' => 'Welcome to OM'];
        //$pdf = PDF::loadView('admins.PDFOM', $data);
        //$pdf = App::make('dompdf.wrapper');

        //create pdf document
        $pdf = app('Fpdf');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(40,10,'Hello World!');
        $pdf->Output('F', 'test.PDF');
        //save file
        //Storage::put('',$pdf->Output('F', 'tous.pdf'));

        /* Exemple sur site debut */
        /*
        use Illuminate\Support\Facades\Storage;

        //create pdf document
        $pdf = app('Fpdf');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(40,10,'Hello World!');

        //save file
        Storage::put($pdf->Output('S'));
        */
        /* Exemple sur site */



        //$html = "";

        //$pdf->loadHTML($pdf);
        //return $pdf->stream();

        //return $pdf->download('tom.pdf');
    }




    public function EnvoieMailConnexion($destinataire, $message, $sujet, $objet)
    {
        $controle = 0;

    $to = $destinataire; // Mettez l'email de réception
    $from = "ssi@sourcedusuccesinternational.com"; // Adresse email du destinataire de l'envoi

    $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
    $HEURE = date("H:i"); // Heure d'envoi de l'email

    $Subject = "$sujet - $JOUR $HEURE";
    $mail_Data = "";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <center> <h1 style=\"color : #25599C;\"> La Source du Succès International </h1> </center> <br><br><br>\n";
    $mail_Data .= "<center> </center> \n";
    $mail_Data .= "<h2> $objet </h2> \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <h3> </h3>  $message \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br> \n";
    $mail_Data .= " Si vous n'avez pas une idée du message, veuillez ignorer ou supprimer ce message.  \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $headers  = "MIME-Version: 1.0 \n";
    $headers .= "Content-type: text/html; charset=iso-8859-1 \n";
    $headers .= "From: $from  \n";
    $headers .= "Disposition-Notification-To: $from  \n";

   // Message de Priorité haute
   // -------------------------
   $headers .= "X-Priority: 1  \n";
   $headers .= "X-MSMail-Priority: High \n";

   $CR_Mail = TRUE;

   $CR_Mail = @mail($to, $Subject, $mail_Data, $headers);
 
   if ($CR_Mail === FALSE)   
        $controle = 1;
        //echo " ### CR_Mail=$CR_Mail - Erreur envoi mail \n";
   else                      
        $controle = 0;
        //echo " *** CR_Mail=$CR_Mail - Mail envoyé \n";  

    // Controle du success

    //if ($controle != 0) echo "Succes..."; else echo "Echec...";

    }

    public function EnvoieMail($destinataire, $message, $sujet, $objet)
    {
        $controle = 0;

    $to = $destinataire; // Mettez l'email de réception
    $from = "ssi@sourcedusuccesinternational.com"; // Adresse email du destinataire de l'envoi

    $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
    $HEURE = date("H:i"); // Heure d'envoi de l'email

    $Subject = "$sujet - $JOUR $HEURE";
    $mail_Data = "";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <center> <h1 style=\"color : #25599C;\"> La Source du Succès International </h1> </center> <br><br><br>\n";
    $mail_Data .= "<center> </center> \n";
    $mail_Data .= "<h2> $objet </h2> \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <h3> </h3>  $message \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br> \n";
    $mail_Data .= " Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.  \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $headers  = "MIME-Version: 1.0 \n";
    $headers .= "Content-type: text/html; charset=iso-8859-1 \n";
    $headers .= "From: $from  \n";
    $headers .= "Disposition-Notification-To: $from  \n";

   // Message de Priorité haute
   // -------------------------
   $headers .= "X-Priority: 1  \n";
   $headers .= "X-MSMail-Priority: High \n";

   $CR_Mail = TRUE;

   $CR_Mail = @mail($to, $Subject, $mail_Data, $headers);
 
   if ($CR_Mail === FALSE)   
        $controle = 1;
        //echo " ### CR_Mail=$CR_Mail - Erreur envoi mail \n";
   else                      
        $controle = 0;
        //echo " *** CR_Mail=$CR_Mail - Mail envoyé \n";  

    // Controle du success

    //if ($controle != 0) echo "Succes..."; else echo "Echec...";

    }
}
  