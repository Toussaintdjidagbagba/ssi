@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>


            <span class="subheading">A propos de nous</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">

    .img-galerie{
    	text-align: center;
    	width: 100%
    }
  </style>

@endsection


@section('content')
	
	<nav class="navbar">
      <div class="img-galerie" >
           <hr>
       <div class="col-lg-12">
        <center><h5 style="color: blue">A PROPOS DE NOUS</h5></center>
        <img src="img/bas2.png" class="bas" style="width: 32%; height: 32%; margin-left: 0%; margin-top: -15px" ></div>
       
        
        <p style="text-align: justify;">
          La Source du Succès International est une entreprise basé sur des formations en éducation financière et social et en entrepreneuriat.Elle est ouverte à toute personne désireuse d'entreprendre ,de réaliser ses projets et atteindre ses objectifs.Elle dispose également des services comme le payement des facture d'électricité(SBEE) et d'eau(SONEB) ,réabonnement CANAL+ possible.
          </p>
        </div>
      </div>
	</nav>
@endsection