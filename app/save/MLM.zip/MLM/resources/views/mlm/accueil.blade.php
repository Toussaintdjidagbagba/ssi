@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Accueil</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">
    .articlepdf{
      background-color: #f0f8ff;
      text-align: center;
      width: 300px;
      max-width: 250px;
      border-radius: 3px; 
      max-height: 450px;
      height: 500px;
      margin: 5px;
      padding: 5px;
    }

    .articledescription{
      max-height: 100px;
      word-wrap: break-word;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  </style>

@endsection


@section('content')
	
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h5 style="color: blue"><center>BIENVENUE A LA SOURCE DU SUCCÈS INTERNATIONAL</center></h5>
        
          <div class="col-lg-12">
          <img src="img/bas2.png" class="bas" style="width: 35%; height: 35%; margin-left: 32%; margin-top: -15px" >
        </div>
         <p style="text-align: justify;">
          L'ENTREPRISE QUI A POUR MISSION DE VOUS SERVIR, TRANSFORMER VOTRE VIE, VOUS AIDÉ A LUTTER CONTRE LE CHOMAGE, LA PAUVRET, VOUS CONDUIRE A LA REALISATION DE VOS PROJETS DE VIE VOUS PROPULSE AU SOMMET ET S'OCCUPER DE VOTRE BIEN ÊTRE.
          ELLE MET A LA DISPOSITION DE SES MEMBRES DES FORMATIONS EN ÉDUCATION FINANCIÈRE  DÉVELOPPEMENT PERSONNEL, SECURITE ALIMENTAIRE ET FINANCIÈRE AFIN DE LES AMENÉ A DEVENIR UNE AIDE POUR LA SOCIÉTÉ .
        </p>

        <hr>
        <div class="col-lg-12">
        <center><h5 style="color: blue">A PROPOS DE NOUS</h5></center>
        <img src="img/bas1.png" class="bas" style="width: 32%; height: 32%; margin-left: 33%; margin-top: -15px" ></div>
       
        
        <p style="text-align: justify;">
          La Source du Succès International est une entreprise basé sur des formations en éducation financière et social et en entrepreneuriat.Elle est ouverte à toute personne désireuse d'entreprendre ,de réaliser ses projets et atteindre ses objectifs.Elle dispose également des services comme le payement des facture d'électricité(SBEE) et d'eau(SONEB), réabonnement CANAL+ possible.
          </p>
        </div>
       
      </div>
    </div>
  </div>

  <div class="container"><div class="row"><div class="col-lg-12">
    <hr>
    <div class="col-lg-12">
          <center><h5 style="color: blue">LES FORMATIONS DISPONIBLES</h5></center>
          <img src="img/bas1.png" class="bas" style="width: 32%; height: 32%; margin-left: 33%; margin-top: -15px" ></div>
        </div>
	<nav class="navbar">
    @forelse($cours as $cour)
    
        <div class="articlepdf " >
          {{ $cour->titre}} <br> 
         <a href="article-{{$cour->id}}"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : {{ $cour->prix }} F CFA<br></p>
         
         {{ $cour->description }}
          <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px">
          </div>
          <div>
            <a href="article-{{$cour->id}}" style="text-align: right; margin-right: 15px">PLUS >> </a>
          </div>
          </div>
    @empty
      <div class="articlepdf " >
          Pas de cours disponible <br> 
         <a href="#"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : 0 F CFA<br></p>
         
        <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px"> Pas de description
          </div>
          </div>
    @endforelse
    </div></div></div>


	</nav>

  <br><br>

        <center><h5 style="color: blue">LES SERVICES DISPONIBLES</h5></center><br><br>
        <div class="container"><div class="row">
        <div class="col-lg-12">
        <nav class="navbar col-lg-12" >
        

        <div >
         <a href="#"> <img src="img/soneb.jpg" class="article_img"> </a> <br><br>
         <p style="text-align: left; margin-left: 50px">SONEB<br></p>
        </div>

        <div >
         <a href="#"> <img src="img/sbee.jpg" class="article_img"> </a> <br><br>
         <p style="text-align: left; margin-left: 50px">SBEE<br></p>
        </div>

        <div >
         <a href="#"> <img src="img/canal.png" class="article_img"> </a><br><br> 
         <p style="text-align: left; margin-left: 50px">CANAL+<br></p>
        </div>
        </nav>
        </div>
        </div></div>
@endsection