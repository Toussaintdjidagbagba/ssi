@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Se connecter ou S'inscrire</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection 

@section('content')
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="progress">
                <div class=" progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" id="progres" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="form-group">
                </div>
                <div class="p-5">
                  <div class="text-center">
                      <img src="img/vali.png" style="height: 200px; width: 100px">
                  </div>
                  <center>
                    <h1>FELICITATION!!!</h1>
                    <h2>CREATION DE COMPTE(S) EFFECTUEE AVEC SUCCES.</h2>
                  </center>
                  <hr>
                  <div class="text-center">
                    <a class="small" href="{{ route('seconnecter')}}" id="link">Se connecter à présent.</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection('content')