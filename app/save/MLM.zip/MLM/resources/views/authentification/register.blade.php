@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">S'incrire</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('content')
  <div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <div class="progress">
            <div class=" progress-bar-striped progress-bar-animated" role="progressbar" style="width: 30%" id="progres" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-8">
            <div class="p-5">
              <!-- Titre -->
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Créer un Compte</h1>
              </div>

              <div class="text-center">
                @include('flash::message')
              </div>
              <!-- Formulaire de création de compte -->
              <form class="user" method="post" action="{{ route('inscriptionS') }}">
                {{ csrf_field() }}

                <!-- Pseudo -->
                <div class="form-group">
                  <label>Pseudo <i style="color: red">*</i></label>
                  <input type="text" class="form-control " name="pseudo" id="pseudo" placeholder="Entrer votre Pseudo" value="{{ old('pseudo') }}" data-original-title="Entrer votre Pseudo">
                  @if($errors->has('pseudo'))
                      <p style="color: red"> {{ $errors->first('pseudo') }}</p>
                  @endif
                </div>

                <!-- Nom et Prénom -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Nom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="nom" id="nom" placeholder="Entrer votre nom" data-original-title="Entrer votre nom">
                    @if($errors->has('nom'))
                      <p style="color: red"> <?php echo "Le nom ne peux pas etre vide."; ?></p>
                    @endif
                  </div>
                  
                  <div class="col-sm-6">
                    <label>Prenom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="prenom" id="prenom" placeholder="Entrer votre prénom" data-original-title="Entrer votre prénom">
                    @if($errors->has('prenom'))
                      <p style="color: red"> {{ $errors->first('prenom') }}</p>
                    @endif
                  </div>
                </div>
                
                <!-- Pays et Tel -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees--> 
                    <label>Pays <i style="color: red">*</i></label> 
                    <select type="mail" class="form-control"  name="pays" id="pays" placeholder="Entrer votre Pays" data-original-title="Entrer votre Pays">
                        <option>Bénin</option>
                        @foreach($pays as $pay)
                        <option>{{ $pay->libelle }}</option>
                      @endforeach
                    </select>
                  </div>
                  <div class="col-sm-6">
                    <label>Téléphone <i style="color: red">*</i></label>
                    <input type="tel" class="form-control " name="tel" id="tel" placeholder="Entrer votre téléphone" data-original-title="Entrer votre téléphone">
                    @if($errors->has('tel'))
                      <p style="color: red"> {{ $errors->first('tel') }}</p>
                    @endif
                  </div>
                </div>
 
                <!-- Mail -->
                <div class="form-group">
                  <label>E-mail <i style="color: red">*</i></label>
                  <input type="mail" class="form-control" name="mail" id="mail" placeholder="Entrer votre E-mail" value="{{ old('mail') }}" data-original-title="Entrer votre E-mail">
                  @if($errors->has('mail'))
                      <p style="color: red"> {{ $errors->first('mail') }}</p>
                  @endif
                </div>

                <!-- Parrain et Payement -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Code parrain <i style="color: red">*</i></label>
                    <input type="text" class="form-control" name="parrain" id="parrain" placeholder="Code de parrainage" data-original-title="Entrer code parrain" /> 
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="parain" name="cocherparrain" value="Pas de code de parrainage.">
                      <label class="form-check-label" for="parain">Pas de code de parrainage.</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <label>Moyen de Paiement <i style="color: red">*</i></label>
                    <select type="text" class="form-control" name="payement" id="payement" data-original-title="Entrer votre moyen de payement">
                      @foreach($mps as $mp)
                        <option>{{ $mp->libelle }}</option>
                      @endforeach
                    </select>
                  </div>
                </div>
                <!-- Sexe et Cout -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees--> 
                    <label>Sexe <i style="color: red">*</i></label>
                    <select type="text" class="form-control" name="sexe" id="sexe" placeholder="Entrer votre Sexe" data-original-title="Entrer votre Sexe">
                      <option>Masculin</option>
                      <option>Féminin</option>
                    </select>  
                  </div>
                  <!-- Education financière -->
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Formation <i style="color: red">*</i></label>
                  <select type="text" class="form-control" name="educ"  id="educ" placeholder="Education financière" data-original-title="Education financière">
                    <option>Education financière</option>
                  </select>
                  </div>
                </div>

                <!-- Pack d'adhesion et consentement -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees--> 
                    <label>Pack d'adhésion <i style="color: red">*</i></label>
                    <select type="text" class="form-control" name="pack" id="pack" placeholder="Entrer votre pack d'adhésion" data-original-title="Entrer votre pack d'adhésion">
                      <option>10 {{$monnaie[0]->Monnaie}}</option>
                      <option>70 {{$monnaie[0]->Monnaie}}</option>
                      <option>630 {{$monnaie[0]->Monnaie}}</option>
                      <option>5110 {{$monnaie[0]->Monnaie}}</option>
                    </select>  
                  </div>
                  <!-- Consentement -->
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Fait payer mon filleul <i style="color: red">*</i></label>
                  <select type="text" class="form-control" name="payerf"  id="payerf" placeholder="Payer" data-original-title="Payer">
                    <option>NON</option>
                    <option>OUI</option>
                  </select>
                  </div>
                </div>

                <!-- Password -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Mot de passe <i style="color: red">*</i></label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Entrer votre mot de passe" data-original-title="Entrer votre mot de passe">
                    @if($errors->has('password'))
                      <p style="color: red"> {{ $errors->first('password') }}</p>
                    @endif
                  </div>
                  
                  <div class="col-sm-6">
                    <label>Répété le mot de passe <i style="color: red">*</i></label>
                    <input type="password" class="form-control" name="passwordbis" id="password" placeholder="Entrer une fois de plus votre mot de passe" data-original-title="Entrer une fois de plus votre mot de passe">
                    @if($errors->has('passwordbis'))
                      <p style="color: red"> {{ $errors->first('passwordbis') }}</p>
                    @endif
                  </div>
                </div>

                <input type="submit" name="CREER COMPTE" value="CREER COMPTE" class="btn btn-user btn-block" id="but" />
                
              </form>
              <?php //location.reload(); 
              ?>
              <hr>
              <div class="text-center">
                <a class="small" href="{{route('fogot')}}" id="link">Mot de passe oublié?</a>
              </div>
              <div class="text-center">
                <a class="small" href="{{ route('seconnecter')}}" id="link">J'ai un compte. Se connecter!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

@endsection('content')
