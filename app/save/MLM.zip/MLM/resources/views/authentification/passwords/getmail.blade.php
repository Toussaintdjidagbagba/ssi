@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Réinitialiser mot de passe</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('content')
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="text-center">
          @include('flash::message')
        </div>
      </div>

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Réinitilisation de mot de passe</h1>
                  </div>
                  <form class="user" method="post" action="{{ route('fogotR') }}">
                    {{ csrf_field() }}
                    <div class="form-group">
                      <label>Email <i style="color: red">*</i></label>
                      <input type="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Entrer votre email" name="mail">
                      @if($errors->has('mail'))
                          <p style="color: red"> {{ $errors->first('mail') }}</p>
                      @endif
                    </div>

                    <div class="form-group">
                      <label>Identifiant <i style="color: red">*</i></label>
                      <input type="text" class="form-control form-control-user" id="" placeholder="Entrer votre identifiant" name="codeperso">
                      @if($errors->has('codeperso'))
                          <p style="color: red"> {{ $errors->first('codeperso') }}</p>
                      @endif
                    </div>

                    <div class="form-group">
                      <label>Pseudo</label>
                      <input type="text" class="form-control form-control-user" id="" placeholder="Ou entrer votre pseudo" name="nomuser">
                    </div>

                    <div class="text-center">
                      Un mail vous sera envoyé contenant un message.
                    </div>
                    
                    <button type="submit" class="btn btn-user btn-block" id="but">
                      <b>Envoyer</b>
                    </button>
                  
                  </form>
                  <hr>
                  <div class="text-center">
                    <a class="small" href="{{route('inscription')}}">Créer un compte!</a>
                  </div>
                  <div class="text-center">
                    <a class="small" href="{{route('seconnecter')}}">Je me rappel!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection('content')