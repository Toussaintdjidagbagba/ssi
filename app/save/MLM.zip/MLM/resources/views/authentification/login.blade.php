@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Se connecter ou S'inscrire</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('content')
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="text-center">
          @include('flash::message')
        </div>
      </div>

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Nous saluons votre retour!</h1>
                  </div>
                  <form class="user" method="post" action="{{ route('seconnecterS') }}">
                    {{ csrf_field() }}
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter pseudo or code identifiant" name="mail">
                      @if($errors->has('mail'))
                        <p style="color: red"> {{ $errors->first('mail') }}</p>
                      @endif
                    </div>
                     
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" name="password">
                      @if($errors->has('password'))
                        <p style="color: red"> {{ $errors->first('password') }}</p>
                      @endif
                    </div>
                    
                    <div class="form-group">
                      <div class="custom-control custom-checkbox small">
                        <input type="checkbox" class="custom-control-input" id="customCheck" name="sourvenir">
                        <label class="custom-control-label" for="customCheck">Se sourvenir de moi</label>
                      </div>
                    </div>
                    
                    <button type="submit" class="btn btn-user btn-block" id="but">
                      <b>CONNEXION</b>
                    </button>
                  
                  </form>
                  <hr>
                  <div class="text-center">
                    <a class="small" href="{{route('fogot')}}">Mot de passe oublié?</a>
                  </div>
                  <div class="text-center">
                    <a class="small" href="{{route('inscription')}}">Créer un compte!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection('content')