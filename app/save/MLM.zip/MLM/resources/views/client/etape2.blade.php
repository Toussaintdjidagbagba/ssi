@extends('layouts.template_client')

@section('content')
	<div class="row"> 
      <div class="col-lg-12">
        <h3 class="page-header">Mes Filleuls</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home">Vous n'être pas encore à l'étape 2 </i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <!-- Parrain -->
          <div class="col-lg-5">
            
          </div>
          <div class="col-lg-2">
            <!-- <center>{{ $moi[0]->nomuser }} ( {{ $moi[0]->codeperso }} ) <br> {{ $moi[0]->email }} <br> // <br> //</center> -->
            <center> ... ( ... ) <br> ... <br> // <br> //</center>
          </div>

        </section>
      </div>
      <!-- level 1 -->
      <div class="col-lg-12">
        <section class="panel">
          
          <div class="col-lg-6">
            @if(isset($mesfilleuls[6]->nomuser))
            <center>{{ $mesfilleuls[6]->nomuser }} ( {{ $mesfilleuls[6]->codeperso }} ) <br> {{ $mesfilleuls[6]->email }} <br> // <br> //</center>
            @else
              <center>inconnue ( inconnue ) <br> inconnue <br> // <br> //</center>
            @endif
          </div>
          <div class="col-lg-6">
            @if(isset($mesfilleuls[7]->nomuser))
            <center>{{ $mesfilleuls[7]->nomuser }} ( {{ $mesfilleuls[7]->codeperso }} ) <br> {{ $mesfilleuls[7]->email }} <br> // <br> //</center>
            @else
              <center>inconnue ( inconnue ) <br> inconnue <br> // <br> //</center>
            @endif
          </div>

        </section>
      </div>
      <!-- level 2 -->
      <div class="col-lg-12">
        <section class="panel">

          <!-- Gauche -->
          
          <div class="col-lg-6">
              <div class="col-lg-6">
              
              @if(isset($mesfilleuls[8]->nomuser))
              <center>{{ $mesfilleuls[8]->nomuser }} ( {{ $mesfilleuls[8]->codeperso }} ) <br> {{ $mesfilleuls[8]->email }} <br> // <br> //</center>
              @else
                <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
              @endif
            </div>
            <div class="col-lg-6">
              @if(isset($mesfilleuls[9]->nomuser))
              <center>{{ $mesfilleuls[9]->nomuser }} ( {{ $mesfilleuls[9]->codeperso }} ) <br> {{ $mesfilleuls[9]->email }} <br> // <br> //</center>
              @else
                <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
              @endif
            </div>
          </div>

          <!-- Droite -->
          <div class="col-lg-6">
            <div class="col-lg-6">
            
            @if(isset($mesfilleuls[10]->nomuser))
            <center>{{ $mesfilleuls[10]->nomuser }} ( {{ $mesfilleuls[10]->codeperso }} ) <br> {{ $mesfilleuls[10]->email }} <br> // <br> //</center>
            @else
              <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
            @endif
          </div>
          <div class="col-lg-6">
            @if(isset($mesfilleuls[11]->nomuser))
            <center>{{ $mesfilleuls[11]->nomuser }} ( {{ $mesfilleuls[11]->codeperso }} ) <br> {{ $mesfilleuls[11]->email }} <br> // <br> //</center>
            @else
              <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
            @endif
          </div>
          </div>

        </section>
      </div>
      <!-- level 3 -->
      <div class="col-lg-12">
        <section class="panel">

          <!-- Gauche -->
          
          <div class="col-lg-6">
              <div class="col-lg-6">
                <div class="col-lg-6">
                  @if(isset($mesfilleuls[12]->nomuser))
                  <center>{{ $mesfilleuls[12]->nomuser }} ( {{ $mesfilleuls[12]->codeperso }} ) <br> {{ $mesfilleuls[12]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>

                <div class="col-lg-6">
                  @if(isset($mesfilleuls[13]->nomuser))
                  <center>{{ $mesfilleuls[13]->nomuser }} ( {{ $mesfilleuls[13]->codeperso }} ) <br> {{ $mesfilleuls[13]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>
            </div>
            <div class="col-lg-6">
              <div class="col-lg-6">
                  @if(isset($mesfilleuls[14]->nomuser))
                  <center>{{ $mesfilleuls[14]->nomuser }} ( {{ $mesfilleuls[14]->codeperso }} ) <br> {{ $mesfilleuls[14]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>

                <div class="col-lg-6">
                  @if(isset($mesfilleuls[15]->nomuser))
                  <center>{{ $mesfilleuls[15]->nomuser }} ( {{ $mesfilleuls[15]->codeperso }} ) <br> {{ $mesfilleuls[15]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>
            </div>
          </div>

          <!-- Droite -->
          <div class="col-lg-6">
            <div class="col-lg-6">
              <div class="col-lg-6">
                  @if(isset($mesfilleuls[16]->nomuser))
                  <center>{{ $mesfilleuls[16]->nomuser }} ( {{ $mesfilleuls[16]->codeperso }} ) <br> {{ $mesfilleuls[16]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>

                <div class="col-lg-6">
                  @if(isset($mesfilleuls[17]->nomuser))
                  <center>{{ $mesfilleuls[17]->nomuser }} ( {{ $mesfilleuls[17]->codeperso }} ) <br> {{ $mesfilleuls[17]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>
            </div>

          <div class="col-lg-6">
              <div class="col-lg-6">
                  @if(isset($mesfilleuls[18]->nomuser))
                  <center>{{ $mesfilleuls[18]->nomuser }} ( {{ $mesfilleuls[18]->codeperso }} ) <br> {{ $mesfilleuls[18]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>

                <div class="col-lg-6">
                  @if(isset($mesfilleuls[19]->nomuser))
                  <center>{{ $mesfilleuls[19]->nomuser }} ( {{ $mesfilleuls[19]->codeperso }} ) <br> {{ $mesfilleuls[19]->email }} <br> // <br> //</center>
                  @else
                    <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
                  @endif
                </div>
          </div>
        </div>

        </section>
      </div>
    </div>
    
    <!--/.row-->

@endsection