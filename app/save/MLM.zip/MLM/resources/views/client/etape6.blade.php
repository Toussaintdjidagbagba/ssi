@extends('layouts.template_client')

@section('content')
	<div class="row"> 
      <div class="col-lg-12">
        <h3 class="page-header">Mes Filleuls</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home">Vous n'être pas encore à l'étape 6</i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <!-- Parrain -->
          <div class="col-lg-5">
            
          </div>
          <div class="col-lg-2">
            <!-- <center>{{ $moi[0]->nomuser }} ( {{ $moi[0]->codeperso }} ) <br> {{ $moi[0]->email }} <br> // <br> //</center> -->
          </div>

        </section>
      </div>
    </div>
@endsection