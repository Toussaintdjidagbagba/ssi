@extends('layouts.template_client')

@section('content')
	<div class="row"> 
      <div class="col-lg-12">
        <h3 class="page-header">Mes Filleuls</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <!-- Parrain -->
          <div class="col-lg-5">
            
          </div>
          <div class="col-lg-2">
            <center>{{ $moi[0]->nomuser }} ( {{ $moi[0]->codeperso }} ) <br> {{ $moi[0]->email }} <br> // <br> //</center>
          </div>

        </section>
      </div>
      <div class="col-lg-12">
        <section class="panel">
          
          <div class="col-lg-6">
            @if(isset($mesfilleuls[0]->nomuser))
            <center>{{ $mesfilleuls[0]->nomuser }} ( {{ $mesfilleuls[0]->codeperso }} ) <br> {{ $mesfilleuls[0]->email }} <br> // <br> //</center>
            @else
              <center>inconnue ( inconnue ) <br> inconnue <br> // <br> //</center>
            @endif
          </div>
          <div class="col-lg-6">
            @if(isset($mesfilleuls[1]->nomuser))
            <center>{{ $mesfilleuls[1]->nomuser }} ( {{ $mesfilleuls[1]->codeperso }} ) <br> {{ $mesfilleuls[1]->email }} <br> // <br> //</center>
            @else
              <center>inconnue ( inconnue ) <br> inconnue <br> // <br> //</center>
            @endif
          </div>

        </section>
      </div>
      <div class="col-lg-12">
        <section class="panel">
          
          <div class="col-lg-6">
              <div class="col-lg-6">
              
              @if(isset($mesfilleuls[2]->nomuser))
              <center>{{ $mesfilleuls[2]->nomuser }} ( {{ $mesfilleuls[2]->codeperso }} ) <br> {{ $mesfilleuls[2]->email }} <br> // <br> //</center>
              @else
                <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
              @endif
            </div>
            <div class="col-lg-6">
              @if(isset($mesfilleuls[3]->nomuser))
              <center>{{ $mesfilleuls[3]->nomuser }} ( {{ $mesfilleuls[3]->codeperso }} ) <br> {{ $mesfilleuls[3]->email }} <br> // <br> //</center>
              @else
                <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
              @endif
            </div>
          </div>
          <div class="col-lg-6">
            <div class="col-lg-6">
            
            @if(isset($mesfilleuls[4]->nomuser))
            <center>{{ $mesfilleuls[4]->nomuser }} ( {{ $mesfilleuls[4]->codeperso }} ) <br> {{ $mesfilleuls[4]->email }} <br> // <br> //</center>
            @else
              <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
            @endif
          </div>
          <div class="col-lg-6">
            @if(isset($mesfilleuls[5]->nomuser))
            <center>{{ $mesfilleuls[5]->nomuser }} ( {{ $mesfilleuls[5]->codeperso }} ) <br> {{ $mesfilleuls[5]->email }} <br> // <br> //</center>
            @else
              <center>n\a ( n\a ) <br> n\a <br> // <br> //</center>
            @endif
          </div>
          </div>

        </section>
      </div>
    </div>
    
    <!--/.row-->

@endsection