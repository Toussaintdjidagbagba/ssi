@extends('layouts.template_admin')
@section('css') 
  <!-- Custom fonts for this template -->
  <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="{{asset('css/clean-blog.min.css')}}" rel="stylesheet">
  <link href="{{asset('css/mlm.css')}}" rel="stylesheet">
  
@endsection
@section('content')
	<div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Profil</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

      <div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-8">
            <div class="p-5">
              <!-- Titre -->
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Votre profil</h1>
              </div>
   
              <div class="text-center">
                @include('flash::message')
              </div>
              <!-- Formulaire du profil -->
              <form class="user" method="post" action="{{ route('ajoutfilleul') }}">
                {{ csrf_field() }}
              
                <!-- Pseudo -->
                <div class="form-group">
                  <label>Code Personnel <i style="color: red">*</i></label>
                  <input type="number" class="form-control " name="codepersonnel" id="codepersonnel" value="{{ $users[0]->codeperso }}" disabled="true" >
                  @if($errors->has('codepersonnel'))
                    <p style="color: red"> {{ $errors->first('codepersonnel') }}</p>
                  @endif
                </div>

                <!-- Nom et Prénom -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Nom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="nom" value="{{ $users[0]->nom}}" id="nom" placeholder="Entrer votre nom" >
                    @if($errors->has('nom'))
                      <p style="color: red"> {{ $errors->first('nom') }}</p>
                    @endif
                  </div>
                  
                  <div class="col-sm-6">
                    <label>Prenom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="prenom" id="prenom" placeholder="Entrer votre prénom" data-original-title="Entrer votre prénom" value="{{ $users[0]->prenom}}">
                    @if($errors->has('prenom'))
                      <p style="color: red"> {{ $errors->first('prenom') }}</p>
                    @endif
                  </div>
                </div>
                  <!--sexe-->
                 <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees-->
                    <label>Sexe <i style="color: red">*</i></label>
                    <input value="{{ $users[0]->sexe}}" type="text" class="form-control"  name="sexe" id="sexe" placeholder="Entrer votre Sexe" data-original-title="Entrer votre Sexe">
                        
                  </div>

                  <!--telephone-->
                   <div class="col-sm-6">
                    <label>Téléphone <i style="color: red">*</i></label>
                    <input type="tel" class="form-control " value="{{ $users[0]->tel}}" name="tel" id="tel" placeholder="Entrer votre téléphone" data-original-title="Entrer votre téléphone">
                    @if($errors->has('tel'))
                      <p style="color: red"> {{ $errors->first('tel') }}</p>
                    @endif
                  </div>
                </div>

                 <!-- Mail -->
                <div class="form-group">
                  <label>E-mail <i style="color: red">*</i></label>
                  <input type="mail" class="form-control " name="mail" id="mail" value="{{ $users[0]->email}}" placeholder="Entrer votre E-mail" data-original-title="Entrer votre E-mail" disabled="true">
                  @if($errors->has('mail'))
                      <p style="color: red"> {{ $errors->first('mail') }}</p>
                  @endif
                </div>

                <!-- Parrain et Payement -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Mon parrain <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="parrain" id="parrain" placeholder="Code de parrainage" data-original-title="Entrer votre Parrain" disabled="true" value="{{ $users[0]->parrain}}" /> 
                    
                  </div>
                  <div class="col-sm-6">
                    <label>Mon code de parrainnage<i style="color: red">*</i></label>
                    <input value="{{ $users[0]->codeunique}}" type="text" class="form-control"  name="codeunique" id="codeunique" data-original-title="Entrer votre code unique" disabled="true"> 
                      
                    </input>
                  </div>
                </div>

          

                <div class="form-group">
                  <label>Nom d'utilisateur ou pseudo<i style="color: red">*</i></label>
                  <input type="text" class="form-control " name="nomuser" id="nomuser" value="{{ $users[0]->nomuser}}" disabled="true" >
                  @if($errors->has('nomuser'))
                    <p style="color: red"> {{ $errors->first('nomuser') }}</p>
                  @endif
                </div>

                <input type="submit" name="mettreajour" value="Mettre à jour" class="btn btn-user btn-block" id="but" />
                
              </form>
              <hr>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

    <!--/.row-->
</div>
@endsection