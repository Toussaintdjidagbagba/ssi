@extends('layouts.template_admin')

@section('content')
    <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Tableau de bord</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box blue-bg">
          <div class="count">{{ $compterecu[0]->compteavoirrecu }} $ SSI</div>
          <div class="title">GAIN RECOLTER</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box brown-bg">
            <div class="count">{{ $compterecu[0]->compteavoirsortant }} $ SSI </div>
          <div class="title">GAIN DEBITER</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box dark-bg">
          <div class="count">{{ $all }} </div>
          <div class="title">NOMBRE DE CLIENT</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="{{ route('nouveaufilleulG') }}">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px">{{$filleuladmin[0]->nombredefilleul}} </div> </div>
          <div class="title">Ajouter un filleul</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

    </div>
    <!--/.row-->
    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste de mes filleuls
          </header> 

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th><i class="icon_ol"></i> Nom Filleul</th>
                <th><i class="icon_pin_alt"></i> Prénom Filleul</th>
                <th><i class="icon_pin_alt"></i> Code de parrainage du Filleul</th>
                <th><i class="icon_pin_alt"></i> Identifiant du Filleul</th>
                <th><i class="icon_pin_alt"></i> Parrain du Filleul</th>
              </tr>
              @forelse($filleuls as $filleul)
                <tr>
                  <td>{{ $filleul->nom }}</td>
                  <td>{{ $filleul->prenom }}</td>
                  <td>{{ $filleul->codeunique }}</td>
                  <td>{{ $filleul->codeperso}}</td>
                  <td>{{ $filleul->parrain }}</td>
                </tr>
              @empty
                <tr >
                  <td colspan="6" style="text-align: center;">Pas de Filleul disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>

@endsection