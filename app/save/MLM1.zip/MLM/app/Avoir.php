<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Avoir extends Model
{
    //
    protected $fillable = ['gainvirtuel', 'gainespece', 'soldetotal', 'id_user'];
}
