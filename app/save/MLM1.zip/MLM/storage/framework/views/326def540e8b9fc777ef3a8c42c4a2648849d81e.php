<?php $__env->startSection('header'); ?>
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Accueil</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <style type="text/css">
    .rating {
       direction: rtl;
    }
    .rating a {
       color: #aaa;
       text-decoration: none;
       font-size: 2em;
       transition: color .4s;
    }
    .rating a:hover,
    .rating a:focus,
    .rating a:hover ~ a,
    .rating a:focus ~ a {
       color: orange;
       cursor: pointer;
    }
  </style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="col-xl-12 col-lg-12 col-md-11">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-1">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  
                    <div class="row">
                      <div class="col-lg-4">
                        <img src="img/ID-100348894.jpg" class="article_img">
                      </div>
                      <div class="col-lg-7">
                        <p>
                          <h4> <?php echo e($cour[0]->titre); ?> </h4>
                        </p>
                        <p>
                          Prix : <?php echo e($cour[0]->prix); ?> F CFA
                        </p> 
                        <hr>
                        <p> 
                          <div class="rating"><!--
                             --><a href="#5" title="Donner 5 étoiles">☆</a><!--
                             --><a href="#4" title="Donner 4 étoiles">☆</a><!--
                             --><a href="#3" title="Donner 3 étoiles">☆</a><!--
                             --><a href="#2" title="Donner 2 étoiles">☆</a><!--
                             --><a href="#1" title="Donner 1 étoile">☆</a> : Evaluation 
                          </div>

                        </p>
                        <hr>
                        
                          Desciption : <p style="text-align: justify;"><?php echo e($cour[0]->description); ?></p>
                        
                      </div>
                      <div class="col-lg-1">
                        
                      </div>
                      <div class="col-lg-2"> <br><br>
                        <a href="#" class="btn btn-primary" id="but">PAYER</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>