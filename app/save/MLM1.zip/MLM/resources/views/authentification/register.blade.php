@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">S'incrire</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('content')
  <div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <div class="progress">
            <div class=" progress-bar-striped progress-bar-animated" role="progressbar" style="width: 30%" id="progres" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-8">
            <div class="p-5">
              <!-- Titre -->
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Créer un Compte</h1>
              </div>

              <div class="text-center">
                @include('flash::message')
              </div>
              <!-- Formulaire de création de compte -->
              <form class="user" method="post" action="{{ route('inscriptionS') }}">
                {{ csrf_field() }}
                <!-- Nom et Prénom -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user" name="nom" id="nom" placeholder="Entrer votre nom" data-original-title="Entrer votre nom">
                    @if($errors->has('nom'))
                      <p style="color: red"> <?php echo "Le nom ne peux pas etre vide."; ?></p>
                    @endif
                  </div>
                  
                  <div class="col-sm-6">
                    <input type="text" class="form-control form-control-user" name="prenom" id="prenom" placeholder="Entrer votre prénom" data-original-title="Entrer votre prénom">
                    @if($errors->has('prenom'))
                      <p style="color: red"> {{ $errors->first('prenom') }}</p>
                    @endif
                  </div>
                </div>
                
                <!-- Pays et Tel -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees--> 
                    <select type="mail" class="form-control" style="margin-top: 8px" name="pays" id="pays" placeholder="Entrer votre Pays" data-original-title="Entrer votre Pays"> 
                        <option>Bénin</option>
                        <option>Togo</option>
                        <option>Cote d'ivoire</option>
                    </select>
                  </div>
                  <div class="col-sm-6">
                    <input type="tel" class="form-control form-control-user" name="tel" id="tel" placeholder="Entrer votre téléphone" data-original-title="Entrer votre téléphone">
                    @if($errors->has('tel'))
                      <p style="color: red"> {{ $errors->first('tel') }}</p>
                    @endif
                  </div>
                </div>
 
                <!-- Mail -->
                <div class="form-group">
                  <input type="mail" class="form-control form-control-user" name="mail" id="mail" placeholder="Entrer votre E-mail" value="{{ old('mail') }}" data-original-title="Entrer votre E-mail">
                  @if($errors->has('mail'))
                      <p style="color: red"> {{ $errors->first('mail') }}</p>
                  @endif
                </div>

                <!-- Parrain et Payement -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    
                    <input type="text" class="form-control form-control-user" name="parrain" id="parrain" placeholder="Code de parrainage" data-original-title="Entrer votre Pays" /> 
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="parain" name="cocherparrain" value="Pas de code de parrainage.">
                      <label class="form-check-label" for="parain">Pas de code de parrainage.</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <select type="text" class="form-control" style="margin-top: 8px" name="payement" id="payement" data-original-title="Entrer votre moyen de payement"> 
                        <option>MTN MONEY</option>
                        <option>MOOV MONEY</option>
                        <option>MASTER CARD</option>
                    </select>
                  </div>
                </div>

                
              
                <!-- Sexe et Cout -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees--> 
                    <select type="text" class="form-control" style="margin-top: 8px" name="sexe" id="sexe" placeholder="Entrer votre Sexe" data-original-title="Entrer votre Sexe">
                      <option>Masculin</option>
                      <option>Féminin</option>
                    </select>  
                  </div>
                  <!-- Education financière -->
                  <div class="col-sm-6 mb-3 mb-sm-0">
                  <select type="educ" class="form-control" name="educ" style="margin-top: 8px" id="educ" placeholder="Education financière" data-original-title="Education financière">
                    <option>Education financière</option>
                    <option> </option>
                  </select>
                  </div>
                </div>

                <input type="submit" name="CREER COMPTE" value="CREER COMPTE" class="btn btn-user btn-block" id="but" />
                
              </form>
              <hr>
              <div class="text-center">
                <a class="small" href="{{route('fogot')}}" id="link">Mot de passe oublié?</a>
              </div>
              <div class="text-center">
                <a class="small" href="{{ route('seconnecter')}}" id="link">J'ai un compte. Se connecter!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

@endsection('content')
