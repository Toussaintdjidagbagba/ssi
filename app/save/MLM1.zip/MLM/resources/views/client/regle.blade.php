@extends('layouts.template_client')

@section('content')
	<div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Règle du MLM</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="col-lg-12">
      Du contenu
    </div>
    
    </div>
    <!--/.row-->

@endsection