<!--sidebar start-->
<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu">
      <li class="active">
        <a class="" href="">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Tableau de bord</span>
        </a>
      </li>

      <li class="sub-menu">
        <a href="<?php echo e(route('index')); ?>" class="">
            <i class="fas fa-globe"></i>
            <span>Aller au SITE</span>
        </a>
      </li>      

      <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="fas fa-fw fa-cog"></i>
            <span>Formation</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
            <li><a class="" href="#">Règle du MLM</a></li>
            <li><a class="" href="#">Mes formations</a></li>
            <li><a class="" href="#"></a></li>
            
        </ul>
      </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>MLM</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="#">Mes Filleul</a></li>
                <li><a class="" href="#"><span>Ajouter Filleul</span></a></li>
                <li><a class="" href="#">Etapes</a></li>
            </ul>
        </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Porte-feuille</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="#">Gain Virtuel</a></li>
                <li><a class="" href="#">Transaction</a></li>
                <li><a class="" href="#"><span>Gain en Espèce</span></a></li>
            </ul>
        </li>

       <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="icon_cog"></i>
            <span>Paramètres</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
          <li><a class="" href="#">Profil</a></li>
          <!-- <li><a class="" href="#"><span>Gestion des droits</span></a></li> -->
        </ul>
      </li>

    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>
<!--sidebar end-->
