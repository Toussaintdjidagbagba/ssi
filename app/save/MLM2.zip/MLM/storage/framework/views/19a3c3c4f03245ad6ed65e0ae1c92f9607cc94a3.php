<?php $__env->startSection('css'); ?>
  <!-- Custom fonts for this template -->
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/clean-blog.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/mlm.css')); ?>" rel="stylesheet">
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-8">
            <div class="p-5">
              <!-- Titre -->
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Créer un compte pour un filleul</h1>
              </div>

              <div class="text-center">
                <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
              <!-- Formulaire de création de compte -->
              <form class="user" method="post" action="<?php echo e(route('ajoutfilleul')); ?>">
                <?php echo e(csrf_field()); ?>

              
                <!-- Pseudo -->
                <div class="form-group">
                  <label>Pseudo <i style="color: red">*</i></label>
                  <input type="text" class="form-control " name="pseudo" id="pseudo" placeholder="Entrer votre Pseudo" value="<?php echo e(old('pseudo')); ?>" data-original-title="Entrer votre Pseudo">
                  <?php if($errors->has('pseudo')): ?>
                      <p style="color: red"> <?php echo e($errors->first('pseudo')); ?></p>
                  <?php endif; ?>
                </div>

                <!-- Nom et Prénom -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Nom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="nom" id="nom" placeholder="Entrer votre nom" data-original-title="Entrer votre nom">
                    <?php if($errors->has('nom')): ?>
                      <p style="color: red"> <?php echo e($errors->first('nom')); ?></p>
                    <?php endif; ?>
                  </div>
                  
                  <div class="col-sm-6">
                    <label>Prenom <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="prenom" id="prenom" placeholder="Entrer votre prénom" data-original-title="Entrer votre prénom">
                    <?php if($errors->has('prenom')): ?>
                      <p style="color: red"> <?php echo e($errors->first('prenom')); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                
                <!-- Pays et Tel -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees-->
                    <label>Pays <i style="color: red">*</i></label> 
                    <select type="mail" class="form-control"  name="pays" id="pays" placeholder="Entrer votre Pays" data-original-title="Entrer votre Pays"> 
                        <option>Bénin</option>
                        <option>Togo</option>
                        <option>Cote d'ivoire</option>
                    </select>
                  </div>
                  <div class="col-sm-6">
                    <label>Téléphone <i style="color: red">*</i></label>
                    <input type="tel" class="form-control " name="tel" id="tel" placeholder="Entrer votre téléphone" data-original-title="Entrer votre téléphone">
                    <?php if($errors->has('tel')): ?>
                      <p style="color: red"> <?php echo e($errors->first('tel')); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
 
                <!-- Mail -->
                <div class="form-group">
                  <label>E-mail <i style="color: red">*</i></label>
                  <input type="mail" class="form-control " name="mail" id="mail" placeholder="Entrer votre E-mail" value="<?php echo e(old('mail')); ?>" data-original-title="Entrer votre E-mail">
                  <?php if($errors->has('mail')): ?>
                      <p style="color: red"> <?php echo e($errors->first('mail')); ?></p>
                  <?php endif; ?>
                </div>

                <!-- Parrain et Payement -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Code parrain <i style="color: red">*</i></label>
                    <input type="text" class="form-control " name="parrain" id="parrain" placeholder="Code de parrainage" data-original-title="Entrer votre Pays" /> 
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="parain" name="cocherparrain" value="Pas de code de parrainage.">
                      <label class="form-check-label" for="parain">Pas de code de parrainage.</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <label>Moyen de Paiement <i style="color: red">*</i></label>
                    <select type="text" class="form-control"  name="payement" id="payement" data-original-title="Entrer votre moyen de payement"> 
                      <?php $__currentLoopData = $mps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($mp->libelle); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
              
                <!-- Sexe et Cout -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <!-- Requete pour pays de la base de donnees-->
                    <label>Sexe <i style="color: red">*</i></label>
                    <select type="text" class="form-control"  name="sexe" id="sexe" placeholder="Entrer votre Sexe" data-original-title="Entrer votre Sexe">
                      <option>Masculin</option>
                      <option>Féminin</option>
                    </select>  
                  </div>
                  <!-- Education financière -->
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Formation <i style="color: red">*</i></label>
                  <select type="educ" class="form-control" name="educ" style="margin-top: 8px" id="educ" placeholder="Education financière" data-original-title="Education financière">
                    <option>Education financière</option>
                    <option>Developpement personnel</option>
                    
                  </select>
                  </div>
                </div>

                <!-- Password -->
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>Mot de passe <i style="color: red">*</i></label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Entrer votre mot de passe" data-original-title="Entrer votre mot de passe">
                    <?php if($errors->has('password')): ?>
                      <p style="color: red"> <?php echo e($errors->first('password')); ?></p>
                    <?php endif; ?>
                  </div>
                  
                  <div class="col-sm-6">
                    <label>Répété le mot de passe <i style="color: red">*</i></label>
                    <input type="password" class="form-control" name="passwordbis" id="password" placeholder="Entrer une fois de plus votre mot de passe" data-original-title="Entrer une fois de plus votre mot de passe">
                    <?php if($errors->has('passwordbis')): ?>
                      <p style="color: red"> <?php echo e($errors->first('passwordbis')); ?></p>
                    <?php endif; ?>
                  </div>
                </div>

                <input type="submit" name="CREER COMPTE" value="CREER COMPTE" class="btn btn-user btn-block" id="but" />
                
              </form>
              <hr>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>