<?php $__env->startSection('content'); ?>
	   <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Mes Gains</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="<?php echo e(route('gains')); ?>">
        <div class="info-box brown-bg">
            <div class="count"> 
              <?php if(isset($gains[0]->gainvirtuel)): ?> 
                <?php echo e($gains[0]->gainvirtuel); ?> F CFA 
              <?php else: ?>
                0 F CFA
              <?php endif; ?>
            </div>
          <div class="title">Gain Virtuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="<?php echo e(route('gains')); ?>">
        <div class="info-box dark-bg">
          <div class="count">
          <?php if(isset($gains[0]->gainespece)): ?> 
            <?php echo e($gains[0]->gainespece); ?> F CFA 
            <?php else: ?>
                0 F CFA
            <?php endif; ?>
          </div>
          <div class="title">Gain en Espèce</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template_client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>