<?php

Route::get('/text', function()
{
	/* Remplacez VOTRE_CLE_API par votre véritable clé API */
  \FedaPay\FedaPay::setApiKey("pk_sandbox_FWst7u92BZueM6Mdeazf5R_Z");

  /* Précisez si vous souhaitez exécuter votre requête en mode test ou live */
  \FedaPay\FedaPay::setEnvironment('sandbox'); //ou setEnvironment('live');

  /* Créer la transaction */
  \FedaPay\Transaction::create(array(
    "description" => "Transaction for john.doe@example.com",
    "amount" => 2000,
    "currency" => ["iso" => "XOF"],
    "callback_url" => "https://maplateforme.com/callback",
    "customer" => [
        "firstname" => "John",
        "lastname" => "Doe",
        "email" => "john.doe@example.com",
        "phone_number" => [
            "number" => "+22997808080",
            "country" => "bj"
        ]
    ]
  ));

});


/* Tout peut voir */
Route::get('/', 'IndexController@index')->name('index');
Route::get('/index', 'IndexController@index')->name('index');
Route::get('/article-{id}', 'IndexController@affichearticle')->name('article');
Route::get('/connexion', 'IndexController@seconnecter')->name('seconnecter');
Route::post('/connexion', 'IndexController@saveseconnecter')->name('seconnecterS');
Route::get('/inscription', 'IndexController@inscription')->name('inscription');
Route::post('/inscription', 'IndexController@saveinscription')->name('inscriptionS');
Route::get('/validerpayement', 'IndexController@validerpayement')->name('validerpayement');
Route::post('/validerpayement', 'IndexController@traitementpayement')->name('validerpayementT');
Route::get('/validerinscription-{id}', 'IndexController@valideinscription')->name('valideinscription');
Route::post('/validerinscription', 'IndexController@traitementinscription')->name('valideinscriptionT');

Route::get('/reinitialisation', 'IndexController@getfogot')->name('fogot');
Route::post('/reinitialisation', 'IndexController@fogot')->name('fogotR');
Route::post('/message', 'IndexController@rfogot')->name('fogotRR');
Route::get('/reinitialisation/renvoyer', 'IndexController@getp')->name('p');
Route::post('/reinitialisation/valider', 'IndexController@setfogot')->name('fogotS');

Route::get('/galerie','IndexController@galerie')->name('galerie');
Route::get('/evernement','IndexController@evernement')->name('evernement');
Route::get('/propos', 'IndexController@propos')->name('propos');
Route::get('/contact','IndexController@contact')->name('contact');
Route::post('/contact','IndexController@setcontact')->name('contactS');

Route::group([
	'middleware' => 'App\Http\Middleware\Auth'

], function(){
	/* Client */
	Route::post('/deconnexion', 'IndexController@sedeconnecter')->name('sedeconnecterS');
	Route::get('/dashboard', 'IndexController@clientdashboard')->name('dashboard');
	Route::get('/regle', 'IndexController@clientregle')->name('regle');
	Route::get('/formation', 'IndexController@clientformation')->name('formation');
	Route::post('/formation', 'IndexController@clientformationdelete')->name('formationS');
	Route::get('/mesfilleuls', 'IndexController@clientmesfilleuls')->name('mesfilleuls');
	Route::get('/gains', 'IndexController@clientgains')->name('gains');
	Route::post('/ajoutfilleul', 'IndexController@ajoutfilleul')->name('ajoutfilleul');
	Route::get('/ajoutfilleul', 'IndexController@getajoutfilleul')->name('ajoutfilleulG');

	/* Aministrateur */
	Route::get('/admin/dashboard', 'IndexController@admindashboard')->name('admin.dashboard');
	Route::post('/admin/ajoutfilleul', 'IndexController@ajoutfilleul')->name('nouveaufilleul');
	Route::get('/admin/ajoutfilleul', 'IndexController@getnouveaufilleul')->name('nouveaufilleulG');	
	Route::post('/admin/galerie', 'IndexController@setgalerie')->name('galerieS');
	Route::get('/admin/galerie', 'IndexController@getgalerie')->name('galerieG');
	Route::post('/admin/evernement', 'IndexController@setevernement')->name('evernementS');
	Route::get('/admin/evernement', 'IndexController@getevernement')->name('evernementG');
	Route::get('/accueil', 'IndexController@accueil')->name('admin.index');
	Route::get('/ajoutercours','IndexController@getajoutercours')->name('coursG');
	Route::post('/ajoutercours','IndexController@setajoutercours')->name('coursS');
	Route::post('/logout','IndexController@adminlogout')->name('admin.logout');
	Route::get('/logout','IndexController@adminlogout')->name('admin.logout');
});


Route::post('Sauvegarde','ArticlePDFController@SauvegardePDF');
/* lien dans navigateur */
Route::get('AjoutPDF','ArticlePDFController@Ajout');

Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
