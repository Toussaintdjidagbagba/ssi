<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notificationcontact extends Model
{
    //
    protected $fillable = ['Nom', 'Email', 'Tel', 'Message'];
}
