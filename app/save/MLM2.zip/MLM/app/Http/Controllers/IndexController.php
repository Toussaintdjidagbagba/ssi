<?php

namespace App\Http\Controllers;

use App\Articlepdf;
use App\Galerie;
use App\Evenement;
use App\Notificationcontact;
use App\User;
use App\Avoir;
use App\Etape;
use App\Mesformation;
use App\MoyenPayement;
use App\Niveau;
use App\Systemadmin;
use App\Translationuser;
use DB;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /* Les méthodes clients */
	public function index()
	{

        $cours = DB::table('articlepdfs')->select('id','path', 'titre', 'prix', 'description')->get();

        $data = ['cours' => $cours];

		return view('mlm.accueil', $data);
	}

	public function accueil()
	{
		
        $cours = DB::table('articlepdfs')->select('id','path', 'titre', 'prix', 'description')->get();
 
        $data = ['cours' => $cours];

        return view('mlm.accueil', $data);
	}

    public function affichearticle()
    {
        $cour = DB::table('articlepdfs')->select('path', 'titre', 'prix', 'description')->where('id', request('id'))->get();

        $data = ['cour' => $cour];

        return view('mlm.Article', $data);
    }

	public function contact()
	{
		return view('mlm.contact');
	}

    public function setcontact()
    {
        $nom = request('name');
        $email = request('email');
        $tel = request('phone');
        $message = request('message');

        $mes = Notificationcontact::create([
            'Nom' => $nom, 
            'Email' => $email, 
            'Tel' => $tel, 
            'Message' => $message
        ]);

        flash('Message envoyé avec succès!!! Consulter votre mail dans 1h pour avoir la réponse à votre préoccupation. SSI vous remercie.');
        return Back();
    }

	public function galerie()
	{
        $image = DB::table('galeries')->select('path', 'image', 'id_user')->get();

        $data = ['images' => $image];

		return view('mlm.galerie', $data);
	}

    public function getgalerie()
    {
        return view('admin.creergalerie');   
    }

    public function setgalerie()
    {
        request()->validate([
            'img' => ['required', 'mimes:png'],
           'titre' => 'required',
        ]);

        $path = request('img')->store('galerie', 'public');

        $image = './img';

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Galerie::create([
            'path' => $path,
            'image' => request('titre'), 
            'id_user' => auth()->user()->id
        ]);

        flash('Ajout avec succès!!!');
        return Back();

    }

    public function evernement()
    {
        $image = DB::table('evenements')->select('path', 'image', 'date', 'lieu', 'heure', 'description', 'id_user')->get();

        $data = ['images' => $image];

        return view('mlm.evernement', $data);
    }

    public function getevernement()
    {
        return view('admin.creerevernement');   
    }

    public function setevernement()
    {
        request()->validate([
            'img' => ['required', 'mimes:png'],
           'titre' => 'required',
           'date' => 'required',
           'lieu' => 'required',
           'heure' => 'required',
           'description' => 'required',
        ]);

        $path = request('img')->store('evenement', 'public');

        $image = './img';

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Evenement::create([
            'path' => $path,
            'image' => request('titre'),
            'date' => request('date'), 
            'lieu' => request('lieu'), 
            'heure' => request('heure'), 
            'description' => request('description'), 
            'id_user' => auth()->user()->id
        ]);

        flash('Ajout avec succès!!!');
        return Back();
    }

    public function propos()
    {
        return view('mlm.propos');
    }

    public function seconnecter()
    {
        return view('authentification.login');
    }

    public function clientdashboard()
    {
        $type = auth()->user()->type;

        if ($type == "client") {
            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

            $data = ['gains' => $gains];
            return view('client.dashboard', $data);
        }
        if ($type == "admin") {

            $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'id_user')->where('id_user', auth()->user()->id)->get();

            $data = ['gains' => $gains];

            return view('admin.dashboard', $data);
        }
    }

    public function admindashboard()
    {
        //return view('client.dashboard');
        
        $type = auth()->user()->type;

        if ($type == "client") {
            return view('client.dashboard');
        }
        if ($type == "admin") {
            return view('admin.dashboard');
        } 
    }

    public function clientregle()
    {
        return view('client.regle');
    }

    public function clientformation()
    {
        // recuperation de la base de donnée
        $formation = DB::table('mesformations')->select('id','titre', 'doc', 'id_user')->get();

        $data = ['formations' => $formation];
        return view('client.formation', $data);
    }

    public function clientformationdelete()
    {
        DB::table('mesformations')->where('id', request('id'))->delete();

        flash("Mail envoyé!!!");
        return Back();
        
    }

    public function clientmesfilleuls()
    {
        return view('client.mesfilleuls');
    }

    public function clientgains()
    {
        $gains = DB::table('avoirs')->select('gainvirtuel', 'gainespece', 'soldetotal', 'id_user')->where('id_user', auth()->user()->id)->get();

        $data = ['gains' => $gains];
        return view('client.gain', $data);
    }

    public function adminlogout()
    {
        auth()->logout();
        return redirect('/connexion');   
    }

    public function get_ip() {
        // IP si internet partagé
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        // IP derrière un proxy
        elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        // Sinon : IP normale
        else {
            return (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');
        }
    }

    public function saveseconnecter(Request $request)
    {

        request()->validate([
            'mail' => 'required|string|max:255',
            'password' => 'required'
        ]);

        $resultat = auth()->attempt([
            'nomuser' => request('mail'),
            'password' => request('password')
        ]);

        if ($resultat) {

            $activation = DB::table('users')
                ->select('compteactive')
                ->where('nomuser', request('mail'))
                ->get()[0]->compteactive;

            if ($activation == "oui") {
                
                if (IndexController::users(request('mail'))) {

                    $email = DB::table('users')
                            ->select('email')
                            ->where('nomuser', request('mail'))
                            ->get()[0]->email;

                    $ip = IndexController::get_ip();


                    // Envoie vers le mail
                    $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                    $message .= "<br>";
                    $message .= "<br>";

                    $sujet = "Connexion réussi!!!";
                    $objet = "Vous etre connecté à votre compte SSI";
                    IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                    return redirect('/admin/dashboard');    
                }
                if (!IndexController::users(request('mail'))) {

                    $email = DB::table('users')
                            ->select('email')
                            ->where('nomuser', request('mail'))
                            ->get()[0]->email;

                    $ip = IndexController::get_ip();

                    // Envoie vers le mail
                    $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                    $message .= "<br>";
                    $message .= "<br>";

                    $sujet = "Connexion réussi!!!";
                    $objet = "Vous etre connecté à votre compte SSI";
                    IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                    return redirect('/dashboard');    
                }                
            }
            else
            {
                $data = ['id_user' => auth()->user()->id ];
                return view('authentification.effectuerpayement', $data);
            }

        } else {

            $resultat = auth()->attempt([
            'codeperso' => request('mail'),
            'password' => request('password')
            ]);

            if ($resultat) {

                $activation = DB::table('users')
                    ->select('compteactive')
                    ->where('codeperso', request('mail'))
                    ->get()[0]->compteactive;

                if ($activation == "oui") {
                    
                    if (IndexController::usersid(request('mail'))) {
                    
                        $email = DB::table('users')
                            ->select('email')
                            ->where('codeperso', request('mail'))
                            ->get()[0]->email;

                        $ip = IndexController::get_ip();

                        // Envoie vers le mail
                        $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                        $message .= "<br>";
                        $message .= "<br>";

                        $sujet = "Connexion réussi!!!";
                        $objet = "Vous etre connecté à votre compte SSI";
                        IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);

                        return redirect('/admin/dashboard');    
                    }
                    if (!IndexController::usersid(request('mail'))) {
             
                        $email = DB::table('users')
                            ->select('email')
                            ->where('codeperso', request('mail'))
                            ->get()[0]->email;

                            $ip = IndexController::get_ip();

                            // Envoie vers le mail
                            $message = "Connexion éffectuer depuis l'adresse ip : $ip";
                            $message .= "<br>";
                            $message .= "<br>";

                            $sujet = "Connexion réussi!!!";
                            $objet = "Vous etre connecté à votre compte SSI";
                            IndexController::EnvoieMailConnexion($email, $message, $sujet, $objet);
                        return redirect('/dashboard');    
                    }                
                }
                else
                {
                    $data = ['id_user' => auth()->user()->id ];
                    return view('authentification.effectuerpayement', $data);
                }

            }
        }
        return Back()->withInput()->withErrors([
                    'mail' => 'Veuillez vérifier le pseudo ou identifiant code',
                    'password' => 'Veuillez vérifier le mot de passe'
                ]);
    }

    public function users($value)
    {
        // Verification du type de l'utilisateur
        $var = DB::table('users')
            ->select('type')
            ->where('nomuser', $value)
            ->get()[0]->type;

        if ($var == "admin") {
            return true;
        }
        if ($var == "client") {
            return false;
        }
    }

    public function usersid($value)
    {
        // Verification du type de l'utilisateur
        $var = DB::table('users')
            ->select('type')
            ->where('codeperso', $value)
            ->get()[0]->type;

        if ($var == "admin") {
            return true;
        }
        if ($var == "client") {
            return false;
        }
    }

    public function sedeconnecter(Request $request)
    {
        auth()->logout();
        return redirect('/connexion');
    }

    public function inscription()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps];

        return view('authentification.register', $data);   
    }

    public function getfogot()
    {
        return view('authentification.passwords.getmail');
    }

    public function fogot(Request $request)
    {

        request()->validate([
            'mail' => 'required|string|email|max:255'
        ]);

        // Générer message
        $string = "";
        $universal_key = 12;

        $user_ramdom_key = 
    "(aLABbC0cEd1[eDf2FghR3ij4kYXQl5Um-OPn6pVq7rJs8*tuW9I+vGw@xHTy&#)K]Z%§!M_S";
        srand((double)microtime()*time());
        for($i=0; $i<$universal_key; $i++) {
        $string .= $user_ramdom_key[rand()%strlen($user_ramdom_key)];
        }

        // Envoie de mail
        $message = $string;

        IndexController::EnvoieMail(request('mail'), $message, "Réinitialisation de mot de passe", "Réinitialiser votre mot de passe en renseignant l'information qui suit dans le site");
        // Recuperer d'abord l'adresse email depuis une fenetre
        flash("Mail envoyé!!!");
        $data = ['mail'=> request('mail'), 'message'=> $message];
        return view('authentification.passwords.forgot-password', $data);
    }

    public function rfogot()
    {
        IndexController::EnvoieMail(request('mail'), request('message'), "Réinitialisation de mot de passe", "Réinitialiser votre mot de passe en renseignant l'information qui suit dans le site");
        // Recuperer d'abord l'adresse email depuis une fenetre
        flash("Mail renvoyé!!!");
        $data = ['mail'=> request('mail'), 'message'=> request('message')];
        return Back();
        //return view('authentification.passwords.forgot-password', $data);   
    }

    public function setfogot(Request $request)
    {
        request()->validate([
            'password' => 'required|confirmed',
            'passwordbis' => 'required',
            'mes' =>'required'
        ]);

        if (request('mail') == false) {
            flash("Erreur!!! Votre session à expirer. Veuillez réeassayer la réinitialisation")->error();
        }
        else
        {
            if (request('mes') == request('message')) {
                flash("Les informations ne sont pas correct.");
                return Back();
            }
            else
            {
                DB::table('users')
                    ->where('email', request('mail'))
                    ->update(['password' => bcrypt(request('password'))]);

                return redirect('/connexion');
            }
        }

        flash("Les informations ne sont pas correct.");
        return Back();
    }

    public function getajoutfilleul()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps];

        return view('client.ajoutfilleul', $data);
    }

    public function getnouveaufilleul()
    {
        $mps = DB::table('moyen_payements')
            ->select('libelle')
            ->get();

        $data = ['mps' => $mps];
        return view('admin.nouveaufilleul', $data);
    }

    public function ajoutfilleul()
    {
        request()->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'pays' => 'required|max:255',
            'tel' => 'required|int',
            'mail' => 'required|string|email|max:255',
            'educ' => 'required|max:255',
            'sexe' => 'required|max:10',
            'parrain' => 'max:7',
            'pseudo' => 'required|string|max:255',
            'password' => 'required',
            'passwordbis' => 'required',
        ]);

        $code_pays = '+229';

        if (request('pays') == "Bénin") {
            $code_pays = '+229';
        }

        if (request('pays') == "Togo") {
            $code_pays = '+228';
        }

        // Verification si parrain existe

        $exit = IndexController::verificationCodeUnique(request('parrain'));

        // Préparation du compte du filleul
        $coher = request('cocherparrain');

        //dd($exit);

        if ($exit != "0") {
            // C'est bon
            // Le code de parrainage est bon

            
            $parrain = 0;

            if (isset($cocher)) { // Verification sur checkbox est true 
                // Si oui donner le code parrainage de l'administrateur

                // Code de parrainage de l'admin
                $parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
            }
            else
            {
                $parrain = request('parrain');
            }

            // Si code parrain est de l'admin alors passe

            $var_type = DB::table('users')->select('type')->where('codeunique', $parrain)->get()[0]->type;

            if ($var_type == "admin") {
                // Générer un code Unique comme code de parrainage pour filleul

                $code_unique = IndexController::generercodeunique();

                $code_id_unique = IndexController::genereridunique();

                $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;

                if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => request('pseudo'),
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                    $users_id = DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->id;

                    $data = [
                        'id_user' => $users_id
                    ];

                    IndexController::EnvoieMail(request('mail'), "https://sourcedusuccesinternational.com/validerpayement", "Validation de compte sur SSI", "Cliquez sur le lien suivant pour finaliser votre inscription");                    
                    
                        flash("Demander à votre filleul de consulter sa boite mail pour valider le paiement et valider son inscription");
                        return Back();
                }
                else
                {
                    flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                    return Back();

                }
            }
            else
            {// si non verifier le nombre de filleul ou d'etape du parrain
                $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

                // Vérification du nombre de filleul trouver
                $filleul = DB::table('users')
                     ->select(DB::raw('count(*) as user_count'))
                     ->where('parrain', $parrain)
                     ->get()[0]->user_count;

                if($filleul > 512)
                {
                    flash("Le parrain à atteint le seuil maximal. Veuillez lui demandé ou cocher l'option inconnue pour construire son nouveau réseau.")->error();
                    return Back();
                }
                else
                {
                    // Laisser passer

                    $code_unique = IndexController::generercodeunique();

                    $code_id_unique = IndexController::genereridunique();

                    $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;
                    
                    if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => request('pseudo'),
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                        $users_id = DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', request('pseudo'))
                                ->get()[0]->id;

                        $data = [
                            'id_user' => $users_id
                        ];

                        IndexController::EnvoieMail(request('mail'), "https://sourcedusuccesinternational.com/validerpayement", "Validation de compte sur SSI", "Cliquez sur le lien suivant pour finaliser votre inscription");

                        flash("Demander à votre filleul de consulter sa boite mail pour valider le paiement et valider son inscription");
                        return Back();
                        //return view('authentification.effectuerpayement', $data);   
                    }
                    else
                    {
                        flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                        return Back();

                    }
                }
            }
        }
        else
        {   // renvoyer un message disant que le code de parrainage est inconnue et aucune option n'est cocher.

            flash("Le code de parrainage est inconnue et aucune option n'est cocher. Veuillez vérifier")->error();
            return Back();
        }
    }


    public function saveinscription(Request $request)
    {
        request()->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'pays' => 'required|max:255',
            'tel' => 'required|int',
            'mail' => 'required|string|email|max:255',
            'educ' => 'required|max:255',
            'sexe' => 'required|max:10',
            'parrain' => 'max:7',
            'pseudo' => 'required|string|max:255',
            'password' => 'required',
            'passwordbis' => 'required',
        ]);

        $code_pays = '+229';

        if (request('pays') == "Bénin") {
            $code_pays = '+229';
        }

        if (request('pays') == "Togo") {
            $code_pays = '+228';
        }

        // Verification si parrain existe

        $exit = IndexController::verificationCodeUnique(request('parrain'));

        // Préparation du compte du filleul
        $coher = request('cocherparrain');

        //dd($exit);

        if ($exit != "0") {
            // C'est bon
            // Le code de parrainage est bon
            
            $parrain = 0;

            if (isset($cocher)) { // Verification sur checkbox est true 
                // Si oui donner le code parrainage de l'administrateur

                // Code de parrainage de l'admin
                $parrain = DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
            }
            else
            {
                $parrain = request('parrain');
            }

            // Si code parrain est de l'admin alors passe

            $var_type = DB::table('users')->select('type')->where('codeunique', $parrain)->get()[0]->type;

            if ($var_type == "admin") {
            
                // Générer un code Unique comme code de parrainage

                $code_unique = IndexController::generercodeunique();
                
                $code_id_unique = IndexController::genereridunique();

                $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;

                if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => request('pseudo'),
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                    $users_id = DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->id;

                    $data = [
                        'id_user' => $users_id
                    ];

                    
                    return view('authentification.effectuerpayement', $data);   
                }
                else
                {
                    flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                    return Back();

                } 
            }
            else
            {// si non verifier le nombre de filleul ou d'etape du parrain
                $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

                // Vérification du nombre de filleul trouver
                $filleul = DB::table('users')
                     ->select(DB::raw('count(*) as user_count'))
                     ->where('parrain', $parrain)
                     ->get()[0]->user_count;

                if($filleul > 512)
                {
                    flash("Le parrain à atteint le seuil maximal. Veuillez lui demandé ou cocher l'option inconnue pour construire son nouveau réseau.")->error();
                    return Back();
                }
                else
                {
                    // Laisser passer

                    $code_unique = IndexController::generercodeunique();

                    $code_id_unique = IndexController::genereridunique();

                    $paiement_id = DB::table('moyen_payements')->select('id')->where('libelle', request('payement'))->get()[0]->id;
                    
                    if (!isset(DB::table('users')
                            ->where('email', request('mail'))
                            ->where('nomuser', request('pseudo'))
                            ->get()[0]->nomuser)) {
                        
                    $create = User::create([
                        'nom' => request('nom'),
                        'prenom' => request('prenom'),
                        'sexe'=> request('sexe'), 
                        'tel' => $code_pays.''.request('tel'), 
                        'compteactive' => "non",
                        'email' => request('mail'),
                        'password' => bcrypt(request('password')), 
                        'type' => "client", 
                        'codeunique' => $code_unique, 
                        'otp' => '', 
                        'nomuser' => request('pseudo'),
                        'codeperso' => $code_id_unique,
                        'compteavoir' => '',
                        'parrain' => $parrain,
                        'moyendepayement' => $paiement_id
                    ]);

                        $users_id = DB::table('users')
                                ->where('email', request('mail'))
                                ->where('nomuser', request('pseudo'))
                                ->get()[0]->id;

                        $data = [
                            'id_user' => $users_id
                        ];

                        
                        return view('authentification.effectuerpayement', $data);   
                    }
                    else
                    {
                        flash("Le pseudo existe déjà pour ce mail... Veuillez vous connecter ou cliquer sur mot de passe oublié si vous ne sourvenez pas.")->error();
                        return Back();

                    }
                }
            }
            // Lorsque le parrain valide une etape qui consiste à avoir un certain 
            // nombre de filleul, envoyer une mail au parrain disant qu'il a valide une etape.

            // Si le parrain atteint les  8 etapes alors impossible de continuer
        }
        else
        {   // renvoyer un message disant que le code de parrainage est inconnue et aucune option n'est cocher.

            flash("Le code de parrainage est inconnue et aucune option n'est cocher. Veuillez vérifier")->error();
            return Back();
        }
    }

    public function valideinscription()
    {
        $id = request('id');

        $trans = '';
        if (isset($_GET['transaction_id'])) {
            $trans = $_GET['transaction_id'];
        }

        // Initialisation du compte avoir de l'utilisateur

        $id_avoirs = IndexController::user_init($id, $trans);

        $id_user = $id;

        $valeur_payer = 10;

        // Premiere translation du filleul

        //IndexController::first_Translation($id_user, $id_avoirs, $trans, $valeur_payer);

        // Premiere etapes consiste a mettre a jour les filleuls

        // Recuperer le parrain enregistrer pour l'utilisateur
        //dd($id_user);

        $codeunique_parrain = IndexController::mon_parrain($id_user);

        //dd($codeunique_parrain);
        $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

        // Verification de l'etape actuel du parrain

        $etape_actuel = IndexController::Etape_ActuelParrain($id_parrain);

        // Code parrain de l'administrateur du site

        $code_parrain_admin = IndexController::Code_Parrain_Admin();

        if ($etape_actuel > 8) {
            // Mon parrain n'est plus capable de me prendre comme filleul
            // Je beneficie du code parrain de l'administrateur du site

            $codeunique_parrain = $code_parrain_admin;

            // Mise à jour dans la table du client

            DB::table('users')
                ->where('id', $id_user)
                ->update(['codeunique' => $codeunique_parrain]);        
        }

        // Verification du code parrain

        $typeparrain = IndexController::TypeParrain($codeunique_parrain);

        if ($typeparrain == "admin") {
            // Recuperer id parrain

            $id_parrain = IndexController::id_mon_parrain($codeunique_parrain);

            $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

            $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

            DB::table('niveaux')
                ->where('id_user', $id_parrain)
                ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);
        }
        else
        {
            // verification du nombre possible pour le l'etape actuel du parrain dans la table etape

            $nombrepossible = IndexController::FilleulPossible($etape_actuel);

            $nbrefilleul = IndexController::NbrefilleulActuel($id_parrain);

            if ($nbrefilleul < $nombrepossible) {
                $nbrefilleul_mise_a_jour = $nbrefilleul + 1;

                DB::table('niveaux')
                    ->where('id_user', $id_parrain)
                    ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]);       
            }
            else
            {
                if ($nbrefilleul == $nombrepossible) {
                    
                    // Augmente etape de +1
                    $etape_actuel_mise_a_jour = $etape_actuel + 1;

                    DB::table('niveaux')
                    ->where('id_user', $id_parrain)
                    ->update(['id_etape' => $etape_actuel_mise_a_jour]);

                    // Une etape valider; une valeur ajouter sur gain en espece

                    // Recuperer valeur ajouter de l'etape valider
                    $valeurajout = IndexController::ValeurAjouterEtape($etape_actuel);

                    $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

                    $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $valeurajout;
                    DB::table('avoirs')
                                ->where('id_user', $id_parrain)
                                ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

                    // Bravo!!!!!!!!!!!!!!!!!!!!!!!
                    // Une etape franchise

                    // Mail si possible     

                    // initialiser nombrefilleul a 1
                    $nbrefilleul_mise_a_jour = 1;

                    DB::table('niveaux')
                        ->where('id_user', $id_parrain)
                        ->update(['nombredefilleul' => $nbrefilleul_mise_a_jour]); 
                }
                // En cas de probleme
            }
        }

        // Deuxieme etapes a mettre a jour les gains

        // Les pourcentage definir du systeme

        $pourcentageespece = IndexController::PourcentageFilleulEspece();

        $pourcentagevirtuel = IndexController::PourcentageFilleulVirtuel();

        // Calcule de la valeur en %

        $gain_espece = $valeur_payer * ($pourcentageespece / 100);

        $gain_virtuel = $valeur_payer * ($pourcentagevirtuel / 100);

        // alors le parrain beneficie de ces valeurs

        $gainsespece_actuel = IndexController::VirtuelActuel($id_parrain);

        $gainsespece_actuel_mise_a_jour = $gainsespece_actuel + $gain_espece;
        DB::table('avoirs')
                    ->where('id_user', $id_parrain)
                    ->update(['gainespece' => $gainsespece_actuel_mise_a_jour]);

        $gainsvirtuel_actuel = IndexController::VirtuelEspece($id_parrain);

        $gainsvirtuel_actuel_mise_a_jour = $gainsvirtuel_actuel + $gain_virtuel;
        DB::table('avoirs')
                    ->where('id_user', $id_parrain)
                    ->update(['gainvirtuel' => $gainsvirtuel_actuel_mise_a_jour]);

        // Compte de l'administrateur
        $gainsadmin_actuel = IndexController::AdminCompteRecu();

        $gainsadmin_actuel_mise_a_jour = $gainsadmin_actuel + $valeur_payer;
        DB::table('systemadmins')
                    ->where('Admin', 'oui')
                    ->update(['compteavoirrecu' => $gainsadmin_actuel_mise_a_jour]);

        // Activer le compte

        DB::table('users')
                ->where('id', $id_user)
                ->update(['compteactive' => 'oui']);

        $niv = Niveau::create([
            'nombredefilleul' => 0, 
            'id_user' => $id_user,
            'id_etape' => 1
        ]);

        $u = DB::table('users')
            ->select('nom', 'prenom', 'sexe', 'email', 'codeunique', 'nomuser', 'codeperso', 'parrain')
            ->where('id', $id_user)
            ->get();

        $data = [
            'id' => $id_user, 
            'trans' => $trans,
            'us' => $u
        ];

        return view('authentification.validerregister', $data);
    }


    /* Des methodes pour la validation */

    public function AdminCompteSortant()
    {
        return DB::table('systemadmins')->select('compteavoirsortant')->where('Admin', 'oui')->get()[0]->compteavoirsortant;   
    }

    public function AdminCompteRecu()
    {
        return DB::table('systemadmins')->select('compteavoirrecu')->where('Admin', 'oui')->get()[0]->compteavoirrecu;   
    }

    public function VirtuelActuel($id_parrain)
    {
       return DB::table('avoirs')->select('gainvirtuel')->where('id_user', $id_parrain)->get()[0]->gainvirtuel; 
    }  

    public function VirtuelEspece($id_parrain)
    {
        return DB::table('avoirs')->select('gainespece')->where('id_user', $id_parrain)->get()[0]->gainespece;  
    }

    public function PourcentageFilleulEspece()
    {
        return DB::table('systemadmins')->select('pourcentagefilleulespece')->where('Admin', 'oui')->get()[0]->pourcentagefilleulespece;
    }

    public function PourcentageFilleulVirtuel()
    {
        return DB::table('systemadmins')->select('pourcentagefilleulvirtuel')->where('Admin', 'oui')->get()[0]->pourcentagefilleulvirtuel;
    }

    public function ValeurAjouterEtape($etape)
    {
        return DB::table('etapes')->select('ValeurAjouter')->where('id', $etape)->get()[0]->ValeurAjouter;
    }

    public function FilleulPossible($etape)
    {
        return DB::table('etapes')->select('NombrePossible')->where('id', $etape)->get()[0]->NombrePossible;
    }

    public function NbrefilleulActuel($id_user)
    {
        return DB::table('niveaux')->select('nombredefilleul')->where('id_user', $id_user)->get()[0]->nombredefilleul;
    }

    public function TypeParrain($valeur)
    {
        return DB::table('users')->select('type')->where('codeunique', $valeur)->get()[0]->type;
    }

    public function Code_Parrain_Admin()
    {
        return DB::table('systemadmins')->select('codeparrainadmin')->where('Admin', 'oui')->get()[0]->codeparrainadmin;
    }

    public function user_init($id, $trans)
    {
        $user_ini = Avoir::create([
                'gainvirtuel' => 0, 
                'gainespece' => 0, 
                'id_user' => $id,
                'translation_first' => $trans
            ]);

        return DB::table('avoirs')->select('id')->where('id_user', $id)->get()[0]->id;
    }

    public function first_Translation($user, $avoirs, $trans, $valeur_payer)
    {
        $user_ini = Translationuser::create([
                'id_user' => $user, 
                'id_avoir' => $avoirs,
                'translation_id' => $trans, 
                'montantrecu' => 0, 
                'montantenvoye' => $valeur_payer
            ]);

        return 0;
    }

    public function mon_parrain($id)
    {
        return DB::table('users')->select('parrain')->where('id', $id)->get()[0]->parrain;
    }

    public function id_mon_parrain($codeunique)
    {
        return DB::table('users')->select('id')->where('codeunique', $codeunique)->get()[0]->id;  
    }

    public function Etape_ActuelParrain($id_parrain)
    {

        //dd($id_parrain);
        return DB::table('niveaux')->select('id_etape')->where('id_user', $id_parrain)->get()[0]->id_etape; 
    }

    /* End Methode */

    public function traitementinscription()
    {

        // Avant d'enregistrer le filleul

        // Verifier le message de retour de kkiapaye

        // Enregistrer l'information dans une table translaction par exemple.


        // Vérification du parrain
        $var_id_parrain = DB::table('users')->select('id')->where('codeunique', $parrain)->get()[0]->id;

        // Vérification de l'etape du parrain
        $etape_actuel = DB::table('niveaux')->select('id_etape')->where('id_user', $var_id_parrain)->get()[0]->id_etape;

        // Nombre de filleul possible pour cette etape
        $nombre_filleul_possible = DB::table('etapes')->select('NombrePossible')->where('id', $etape_actuel)->get()[0]->NombrePossible;

        // Vérification du nombre de filleul trouver
        $filleul = DB::table('users')
                ->select(DB::raw('count(*) as user_count'))
                ->where('parrain', $parrain)
                ->get()[0]->user_count;

        // Incrémenter le compte des avoirs du parrain de
        // 500 dans gain en espece et 500 dans gain virtuel et somme dans somme

        // Enregistrer dans la table niveaux : le nombre de filleul
        // id_user et id_etape

        // Actver compte filleul
    }

    public function validerpayement()
    {
        return view('authentification.effectuerpayement');
    }

    public function traitementpayement()
    {
        // Envoie de mail
        
    }

    public function getajoutercours()
    {
        return view('admin.upload_cours');   
    }

    public function setajoutercours()
    {
        request()->validate([
            'cours' => ['required', 'mimes:pdf'],
            'cout' => 'required',
            'titre' => 'required',
            'description' => 'required'
        ]);

        $path = request('cours')->store('cours', 'public');

        $image = './img';

        //$b = IndexController::extract($path, './img', 'png');

        // Ensuite, ajoute public comme second paramètre du store
        //$path = request('image')->store('img', 'public');
        // Pour afficher image 
        // <img src="/storage/{{$path}}"> 
        // Pour afficher un lien vers pdf
        // <a href="/storage/{{$path}}"> Name PDF </a> 

        $article = Articlepdf::create([
            'path' => $path,
            'image' => $image,
            'titre' => request('titre'),
            'prix' => request('cout'),
            'description' => request('description')
        ]);

        flash('Ajout avec succès!!!');
        return Back();

    }

    const FORMAT_JPG = 'jpg';
    const FORMAT_PNG = 'png';

    /**
     * @param string $source      source filepath
     * @param string $destination destination filepath
     * @param string $format      destination format
     *
     * @return bool
     */
    public function extract($source, $destination, $format = self::FORMAT_PNG)
    {
        if (!extension_loaded('Imagick')) {
            return false;
        }

        $imagick = new \Imagick($source . '[0]');
        $imagick->setFormat($format);

        return $imagick->writeImage($destination);
    }

    public function verificationCodeUnique($value)
    {
        if (isset(DB::table('users')->select('codeunique')->where('codeunique', $value)->get()[0]->codeunique)) {
            
            return DB::table('users')->select('codeunique')->where('codeunique', $value)->get()[0]->codeunique;
            
        } else {
            return '0';
        }
    }

    public function generercodeunique()
    {
        $code_unique = rand(10000000, 99999999);

        if (IndexController::verificationCodeUnique($code_unique) == 0) {
            return $code_unique;
        }
        else
        {
            IndexController::generercodeunique();
        }
    }

    public function verificationIdUnique($value)
    {
        if (isset(DB::table('users')->select('codeperso')->where('codeperso', $value)->get()[0]->codeperso)) {
            
            return DB::table('users')->select('codeperso')->where('codeperso', $value)->get()[0]->codeperso;
            
        } else {
            return '0';
        }   
    }

    public function genereridunique()
    {
        $id_unique = rand(10000000, 99999999);

        if (IndexController::verificationIdUnique($id_unique) == 0) {
            return $id_unique;
        }
        else
        {
            IndexController::genereridunique();
        }
    }

	public function create()
    {
        //$pdf = app('Fpdf');


        //return view('admins.PDFOM');

        //return PDF::loadFile(public_path().'../resources/views/admins/PDFOM')->save('/path-to/my_stored_file.pdf')->stream('download.pdf');

        //$data = ['title' => 'Welcome to OM'];
        //$pdf = PDF::loadView('admins.PDFOM', $data);
        //$pdf = App::make('dompdf.wrapper');

        //create pdf document
        $pdf = app('Fpdf');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(40,10,'Hello World!');
        $pdf->Output('F', 'test.PDF');
        //save file
        //Storage::put('',$pdf->Output('F', 'tous.pdf'));

        /* Exemple sur site debut */
        /*
        use Illuminate\Support\Facades\Storage;

        //create pdf document
        $pdf = app('Fpdf');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(40,10,'Hello World!');

        //save file
        Storage::put($pdf->Output('S'));
        */
        /* Exemple sur site */



        //$html = "";

        //$pdf->loadHTML($pdf);
        //return $pdf->stream();

        //return $pdf->download('tom.pdf');
    }


    public function EnvoieMailConnexion($destinataire, $message, $sujet, $objet)
    {
        $controle = 0;

    $to = $destinataire; // Mettez l'email de réception
    $from = "ssi@sourcedusuccesinternational.com"; // Adresse email du destinataire de l'envoi

    $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
    $HEURE = date("H:i"); // Heure d'envoi de l'email

    $Subject = "$sujet - $JOUR $HEURE";
    $mail_Data = "";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <center> <h1 style=\"color : #25599C;\"> La Source du Succès International </h1> </center> <br><br><br>\n";
    $mail_Data .= "<center> </center> \n";
    $mail_Data .= "<h2> $objet </h2> \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <h3> </h3>  $message \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br> \n";
    $mail_Data .= " Si vous n'avez pas une idée du message, veuillez ignorer ou supprimer ce message.  \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $headers  = "MIME-Version: 1.0 \n";
    $headers .= "Content-type: text/html; charset=iso-8859-1 \n";
    $headers .= "From: $from  \n";
    $headers .= "Disposition-Notification-To: $from  \n";

   // Message de Priorité haute
   // -------------------------
   $headers .= "X-Priority: 1  \n";
   $headers .= "X-MSMail-Priority: High \n";

   $CR_Mail = TRUE;

   $CR_Mail = @mail($to, $Subject, $mail_Data, $headers);
 
   if ($CR_Mail === FALSE)   
        $controle = 1;
        //echo " ### CR_Mail=$CR_Mail - Erreur envoi mail \n";
   else                      
        $controle = 0;
        //echo " *** CR_Mail=$CR_Mail - Mail envoyé \n";  

    // Controle du success

    //if ($controle != 0) echo "Succes..."; else echo "Echec...";

    }

    public function EnvoieMail($destinataire, $message, $sujet, $objet)
    {
        $controle = 0;

    $to = $destinataire; // Mettez l'email de réception
    $from = "ssi@sourcedusuccesinternational.com"; // Adresse email du destinataire de l'envoi

    $JOUR = date("Y-m-d");  // Jour de l'envoi de l'email
    $HEURE = date("H:i"); // Heure d'envoi de l'email

    $Subject = "$sujet - $JOUR $HEURE";
    $mail_Data = "";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <center> <h1 style=\"color : #25599C;\"> La Source du Succès International </h1> </center> <br><br><br>\n";
    $mail_Data .= "<center> </center> \n";
    $mail_Data .= "<h2> $objet </h2> \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <h3> </h3>  $message \n";
    $mail_Data .= " <br>\n";
    $mail_Data .= " <br> \n";
    $mail_Data .= " Si vous ne savez pas l'origine du message, veuillez ignorer ou supprimer ce message.  \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $mail_Data .= " \n";
    $headers  = "MIME-Version: 1.0 \n";
    $headers .= "Content-type: text/html; charset=iso-8859-1 \n";
    $headers .= "From: $from  \n";
    $headers .= "Disposition-Notification-To: $from  \n";

   // Message de Priorité haute
   // -------------------------
   $headers .= "X-Priority: 1  \n";
   $headers .= "X-MSMail-Priority: High \n";

   $CR_Mail = TRUE;

   $CR_Mail = @mail($to, $Subject, $mail_Data, $headers);
 
   if ($CR_Mail === FALSE)   
        $controle = 1;
        //echo " ### CR_Mail=$CR_Mail - Erreur envoi mail \n";
   else                      
        $controle = 0;
        //echo " *** CR_Mail=$CR_Mail - Mail envoyé \n";  

    // Controle du success

    //if ($controle != 0) echo "Succes..."; else echo "Echec...";

    }
}
  