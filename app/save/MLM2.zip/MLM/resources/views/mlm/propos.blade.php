@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">A propos de nous</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">

    .img-galerie{
    	text-align: center;
    	width: 100%
    }
  </style>

@endsection


@section('content')
	
	<nav class="navbar">
      <div class="img-galerie" >
          A propos. <br>  
      </div>
	</nav>
@endsection