@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Contactez-nous</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">

    .but{
      background-color: #65BBD6;
      text-align: center;
      
    }
  </style>

@endsection


@section('content')
  
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">

        @include('flash::message')

        <p>Besoin d'une information ? <br> Laissez nous un petit message et nous saurons vous aidé</p>
            
          <form method="post" action="{{ route('contactS') }}"  name="sentMessage" id="contactForm" novalidate>
             {{ csrf_field() }}
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Nom</label>
              <input type="text" class="form-control" placeholder="Nom" id="name" name="name" required data-validation-required-message="Veuillez entrer votre nom s'il vous plaît.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Email</label>
              <input type="email" class="form-control" placeholder="Email" name="email" id="email" required data-validation-required-message="Veuillez entrer votre adresse mail s'il vous plaît.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group col-xs-12 floating-label-form-group controls">
              <label>Numero de téléphone</label>
              <input type="tel" class="form-control" placeholder="Numero de téléphone" id="phone" name="phone" required data-validation-required-message="Veuillez entrer votre numero de téléphone s'il vous plaît.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Message</label>
              <textarea rows="5" name="message" class="form-control" placeholder="Message" id="message" required data-validation-required-message="Veuillez entrer votre message s'il vous plaît."></textarea>
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <br>
          <div id="success"></div>
          <button type="submit" class="btn btn-user btn-block" id="but">
                      <b>Envoyer</b>
          </button>
        </form>
      </div>
    </div>
@endsection