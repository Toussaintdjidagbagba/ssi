@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Accueil</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">
    .articlepdf{
      background-color: #f0f8ff;
      text-align: center;
      width: 300px;
      max-width: 250px;
      border-radius: 3px; 
      max-height: 450px;
      height: 500px;
      margin: 5px;
      padding: 5px;
    }

    .articledescription{
      max-height: 100px;
      word-wrap: break-word;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  </style>

@endsection


@section('content')
	
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>BIENVENU A LA SOURCE DU SUCCÈS INTERNATIONAL</h3>
      </div>
    </div>
  </div>

	<nav class="navbar">
    @forelse($cours as $cour)
    
        <div class="articlepdf " >
          {{ $cour->titre}} <br> 
         <a href="article-{{$cour->id}}"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : {{ $cour->prix }} F CFA<br></p>
         
         {{ $cour->description }}
          <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px">
          </div>
          <div>
            <a href="article-{{$cour->id}}" style="text-align: right; margin-right: 15px">PLUS >> </a>
          </div>
          </div>
    @empty
      <div class="articlepdf " >
          Pas de cours disponible <br> 
         <a href="#"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : 0 F CFA<br></p>
         
         {{ $cour->description }}
          <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px"> Pas de description
          </div>
          </div>
    @endforelse

	</nav>
@endsection