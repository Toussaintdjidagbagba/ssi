@extends('layouts.template_admin')

@section('content')
    <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Dashboard</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box blue-bg">
          <div class="count">GR</div>
          <div class="title">GAIN RECOLTER</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box brown-bg">
            <div class="count">T </div>
          <div class="title">MES TRANSACTONS</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box dark-bg">
          <div class="count">C </div>
          <div class="title">NOMBRE DE CLIENT</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px">V </div><?php //echo $valorisationcarburans[0]->coutunitaire.' F / 513 F'; ?>  </div>
          <div class="title">NOMBRE DE VISITEUR</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

    </div>
    <!--/.row-->

@endsection