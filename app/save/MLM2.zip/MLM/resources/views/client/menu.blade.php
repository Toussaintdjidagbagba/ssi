<!--sidebar start-->

<aside>
  <div id="sidebar" class="nav-collapse " >
    <!-- sidebar menu start-->
    <ul class="sidebar-menu" >
      <li class="active">
        <a class="" href="{{ route('dashboard') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Tableau de bord</span>
        </a>
      </li>

      <li class="sub-menu">
        <a href="{{ route('index') }}" class="">
            <i class="fas fa-globe"></i>
            <span>Aller au SITE</span>
        </a>
      </li>

      <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="fas fa-fw fa-cog"></i>
            <span>Formation</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
            <li><a class="" href="{{ route('regle') }}">Règle du MLM</a></li>
            <li><a class="" href="{{ route('formation')}}">Mes formations</a></li>
            
        </ul>
      </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>MLM</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('mesfilleuls') }}">Mes Filleuls</a></li>
                 <li><a class="" href="{{ route('ajoutfilleul') }}"><span>Ajouter Filleul</span></a></li> 
                <!-- <li><a class="" href="#">Etapes</a></li> -->
            </ul>
        </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Porte-feuille</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('gains') }}">Mes Gains</a></li>
                <!--<li><a class="" href="#">Transaction</a></li> -->
            </ul>
        </li>

       <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="icon_cog"></i>
            <span>Paramètres</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
          <li><a class="" href="#">Profil</a></li>
          <!-- <li><a class="" href="#"><span>Gestion des droits</span></a></li> -->
        </ul>
      </li>

    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>
<!--sidebar end-->
