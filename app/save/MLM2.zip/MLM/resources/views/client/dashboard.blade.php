@extends('layouts.template_client')

@section('content')
	   <div class="row">
        
      <div class="col-lg-12">
        <h3 class="page-header">Dashboard</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="{{ route('mesfilleuls') }}">
        <div class="info-box blue-bg">
          <div class="count">F</div>
          <div class="title">Mes Filleuls</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="{{ route('gains') }}">
        <div class="info-box brown-bg">
            <div class="count"> 
              @if(isset($gains[0]->gainvirtuel)) 
                {{ $gains[0]->gainvirtuel }} F CFA 
              @else
                0 F CFA
              @endif
            </div>
          <div class="title">Gain Virtuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="{{ route('gains') }}">
        <div class="info-box dark-bg">
          <div class="count">
          @if(isset($gains[0]->gainespece)) 
            {{ $gains[0]->gainespece }} F CFA 
            @else
                0 F CFA
            @endif
          </div>
          <div class="title">Gain en Espèce</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <a href="{{ route('regle') }}">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px"> R </div><?php //echo $valorisationcarburans[0]->coutunitaire.' F / 513 F'; ?>  </div>
          <div class="title">Règle</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

    </div>
    <!--/.row-->

@endsection