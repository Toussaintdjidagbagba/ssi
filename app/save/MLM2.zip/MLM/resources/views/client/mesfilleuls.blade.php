@extends('layouts.template_client')

@section('content')
	<div class="row"> 
      <div class="col-lg-12">
        <h3 class="page-header">Mes Filleuls</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          
          

        </section>
      </div>
    </div>
    
    <!--/.row-->

@endsection