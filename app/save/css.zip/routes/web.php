<?php
 
Route::get('/act', 'IndexController@img');
Route::get('/sms', 'IndexController@sms');

/* Tout peut voir */
Route::get('/', 'IndexController@index')->name('index');
Route::get('/index', 'IndexController@index')->name('index');
Route::get('/article-{id}', 'IndexController@affichearticle')->name('article');
Route::get('/connexion', 'IndexController@seconnecter')->name('seconnecter');
Route::post('/connexion', 'IndexController@saveseconnecter')->name('seconnecterS');

Route::get('/inscription', 'IndexController@inscription')->name('inscription');
Route::get('/inscription-monparrain-{parrain}', 'IndexController@inscriptionlink')->name('inscriptionlink');


Route::post('/inscription', 'IndexController@saveinscription')->name('inscriptionS');
Route::get('/validerpayement', 'IndexController@validerpayement')->name('validerpayement');
Route::post('/validerpayement', 'IndexController@traitementpayement')->name('validerpayementT');
Route::post('/activer', 'IndexController@valideinscription')->name('activer');
Route::get('/validerinscription-{id}', 'IndexController@valideinscription')->name('valideinscription');
Route::post('/validerinscription', 'IndexController@traitementinscription')->name('valideinscriptionT');
Route::post('/valideparrain', 'IndexController@continueinscription')->name('valideParrain');
Route::get('/reinitialisation', 'IndexController@getfogot')->name('fogot');
Route::post('/reinitialisation', 'IndexController@fogot')->name('fogotR');
Route::post('/message', 'IndexController@rfogot')->name('fogotRR');
Route::get('/reinitialisation/renvoyer', 'IndexController@getp')->name('p');
Route::post('/reinitialisation/valider', 'IndexController@setfogot')->name('fogotS');

Route::get('/galerie','IndexController@galerie')->name('galerie');
Route::get('/evernement','IndexController@evernement')->name('evernement');
Route::get('/propos', 'IndexController@propos')->name('propos');
Route::get('/contact','IndexController@contact')->name('contact');
Route::post('/contact','IndexController@setcontact')->name('contactS'); 

Route::group([
	'middleware' => 'App\Http\Middleware\Auth' 

], function(){

	Route::get('/code', 'IndexController@genecode')->name('genecode');
	/* Client */
	Route::get('/transfert', 'IndexController@gettransfert')->name('transfert');
	Route::post('/transfert', 'IndexController@settransfert')->name('transfertS');
	Route::get('/profil', 'IndexController@getprofil')->name('profil');
	Route::post('/profil', 'IndexController@setprofil')->name('profilS');
	Route::post('/deconnexion', 'IndexController@sedeconnecter')->name('sedeconnecterS');
	Route::get('/dashboard', 'IndexController@clientdashboard')->name('dashboard');
	Route::get('/regle', 'IndexController@clientregle')->name('regle');
	Route::get('/formation', 'IndexController@clientformation')->name('formation');
	Route::post('/formation', 'IndexController@clientformationdelete')->name('formationS');
	
	Route::get('/Etape1', 'IndexController@clientmesfilleuls')->name('mesfilleuls');
	Route::get('/Etape2', 'IndexController@clientmesfilleuls2')->name('mesfilleuls2');
	Route::get('/Etape3', 'IndexController@clientmesfilleuls3')->name('mesfilleuls3');
	Route::get('/Etape4', 'IndexController@clientmesfilleuls4')->name('mesfilleuls4');
	Route::get('/Etape5', 'IndexController@clientmesfilleuls5')->name('mesfilleuls5');
	Route::get('/Etape6', 'IndexController@clientmesfilleuls6')->name('mesfilleuls6');
	Route::get('/Etape7', 'IndexController@clientmesfilleuls7')->name('mesfilleuls7');
	Route::get('/Etape8', 'IndexController@clientmesfilleuls8')->name('mesfilleuls8');
	

	Route::get('/gains', 'IndexController@clientgains')->name('gains');
	Route::post('/ajoutfilleul', 'IndexController@ajoutfilleul')->name('ajoutfilleul');
	Route::get('/ajoutfilleul', 'IndexController@getajoutfilleul')->name('ajoutfilleulG');

	/* Aministrateur */
	Route::get('/admin/listecontact', 'IndexController@getlistecontact')->name('listecontact');
	Route::post('/admin/listecontact', 'IndexController@setlistecontact')->name('listecontactS');
	Route::get('/admin/repondre', 'IndexController@getrepondret')->name('repondre');
	Route::post('/admin/repondre', 'IndexController@setrepondre')->name('repondreS');
	Route::get('/admin/prelevement', 'IndexController@getprelevement')->name('prelevement');
	Route::post('/admin/prelevement', 'IndexController@setprelevement')->name('prelevementS');//fait
	Route::get('/admin/listeFilleuls', 'IndexController@listfilleuls')->name('listclient');
	Route::get('/codeotp', 'IndexController@genecodeadmin')->name('genecodeA');
	Route::get('/admin/transfertadmin', 'IndexController@gettransfertadmin')->name('transfertadmin');
	Route::post('/admin/transfertadmin', 'IndexController@settransfertadmin')->name('transfertadminS');
	Route::get('/admin/profiladmin', 'IndexController@getprofiladmin')->name('profiladmin');
	Route::post('admin/profiladmin', 'IndexController@setprofiladmin')->name('profiladminS');
	Route::get('/admin/dashboard', 'IndexController@admindashboard')->name('admin.dashboard');
	Route::post('/admin/ajoutfilleul', 'IndexController@ajoutfilleul')->name('nouveaufilleul');
	Route::get('/admin/ajoutfilleul', 'IndexController@getnouveaufilleul')->name('nouveaufilleulG');	
	Route::post('/admin/galerie', 'IndexController@setgalerie')->name('galerieS');
	Route::get('/admin/galerie', 'IndexController@getgalerie')->name('galerieG');
	Route::post('/admin/evernement', 'IndexController@setevernement')->name('evernementS');
	Route::get('/admin/evernement', 'IndexController@getevernement')->name('evernementG');
	Route::get('/accueil', 'IndexController@accueil')->name('admin.index');
	Route::get('/ajoutercours','IndexController@getajoutercours')->name('coursG');
	Route::post('/ajoutercours','IndexController@setajoutercours')->name('coursS');
	Route::post('/logout','IndexController@adminlogout')->name('admin.logout');
	Route::get('/logout','IndexController@adminlogout')->name('admin.logout');
	Route::get('/admin/activercompte', 'IndexController@activeraccount')->name('admin.active');
});