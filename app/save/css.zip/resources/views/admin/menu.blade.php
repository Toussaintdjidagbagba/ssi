<!--sidebar start-->
<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu">
      <li class="active">
        <a class="" href="{{ route('admin.dashboard') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Tableau de bord</span>
        </a>
      </li>

      <li class="sub-menu">
        <a href="{{ route('admin.index') }}" class="">
            <i class="fas fa-globe"></i>
            <span>Aller au SITE</span>
        </a>
      </li>      

      <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="fas fa-fw fa-cog"></i>
            <span>Configuration</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
            <li><a class="" href="{{ route('coursG') }}">Ajouter un cours</a></li>
            <li><a href="{{ route('nouveaufilleulG') }}">Ajouter un filleul</a></li>
            <li><a href="{{ route('admin.active') }}">Activer compte filleul</a></li>
        </ul>
      </li>

        <li class="sub-menu">
            <a class="" href="javascript:;">
                <i class="fas fa-fw fa-wrench"></i>
                <span>Opération MLM</span>
                <span class="menu-arrow arrow_carrot-right"></span>
            </a>
            <ul class="sub">
                <li><a class="" href="{{ route('transfertadmin') }}">Transfert de fond</a></li>
                <li><a class="" href="{{ route('prelevement') }}">Prélever des fonds</a></li>
            </ul>
        </li>

       <li class="sub-menu">
        <a href="javascript:;" class="">
            <i class="icon_cog"></i>
            <span>Paramètres</span>
            <span class="menu-arrow arrow_carrot-right"></span>
        </a>
        <ul class="sub">
          <li><a class="" href="{{ route('profiladmin') }}">Profil</a></li>
          <li><a class="" href="{{ route('galerieG')}}">Ajouter d'image</a></li>
          <li><a class="" href="{{ route('evernementG') }}">Créer Conférence</a></li>
          <li><a class="" href="{{ route('listecontact') }}">Liste des contacts</a></li>
        </ul>
      </li>

    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>
<!--sidebar end-->
