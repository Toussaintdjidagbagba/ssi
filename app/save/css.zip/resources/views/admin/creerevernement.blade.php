@extends('layouts.template_admin')

@section('css')
	
	<style type="text/css">
		#sidebar_right
		{
		    background-color: #f0f8ff;
		    border-bottom: 1px solid #688a7e !important;
		    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.176) !important;
		    
		}

		#link{
		    color: #65BBD6;
		}
		.bg-link
		{
			background-color: #65BBD6;
			color: white; 
		}
	</style>

@endsection

@section('content')
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="text-center">
          @include('flash::message')
        </div>
      </div>

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-2">
                
              </div>
              <div class="col-lg-8">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Créer une conférence</h1>
                  </div>
                  <form class="user" method="post" action="{{ route('evernementS') }}">
                    {{ csrf_field() }}
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" placeholder="Enter le thème de la conférence" name="theme">
                      @if($errors->has('theme'))
                        <p style="color: red"> {{ $errors->first('theme') }}</p>
                      @endif
                    </div>

                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" placeholder="Entrer le lieu" name="lieu">
                      @if($errors->has('lieu'))
                        <p style="color: red"> {{ $errors->first('lieu') }}</p>
                      @endif
                    </div>
                     
                    <div class="form-group">
                      <input type="date" class="form-control form-control-user" id="exampleInputPassword" placeholder="Entrer la date" name="date">
                      @if($errors->has('date'))
                        <p style="color: red"> {{ $errors->first('date') }}</p>
                      @endif
                    </div>


                    <div class="form-group">
                      <input type="time" class="form-control form-control-user" placeholder="Entrer l'heure" name="heure">
                      @if($errors->has('heure'))
                        <p style="color: red"> {{ $errors->first('heure') }}</p>
                      @endif
                    </div>
                    
                    <div class="form-group">
				              <label for="reponse">Entrer une courte description de la conférence (<i style="color: red">*</i>)</label>
				              <textarea class="form-control" name="description" placeholder="Entrer description" value="{{ old('description') }}" autofocus autocomplete style="height: 150px"></textarea>
				            	@if($errors->has('description'))
			                      <p style="color: red">{{ $errors->first('description') }}</p>
			                  	@endif
				            </div>
                    
                    <button type="submit" class="btn btn-user btn-block">
                      <b>CREER UNE CONFERENCE</b>
                    </button>
                  
                  </form>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

@endsection