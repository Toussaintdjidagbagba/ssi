@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/logg.png')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Accueil</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">
    .articlepdf{
      background-color: #f0f8ff;
      text-align: center;
      width: 300px;
      max-width: 250px;
      border-radius: 3px; 
      max-height: 450px;
      height: 500px;
      margin: 5px;
      padding: 5px;
    }

    .articledescription{
      max-height: 100px;
      word-wrap: break-word;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  </style>

@endsection


@section('content')
	
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h5 style="color: blue"><center>BIENVENUE À LA SOURCE DU SUCCÈS INTERNATIONAL</center></h5>
        
          <div class="col-lg-12">
          <img src="img/bas2.png" class="bas" style="width: 35%; height: 35%; margin-left: 32%; margin-top: -15px" >
        </div>
         <p style="text-align: justify;">
          LA PLATE-FORME QUI A POUR MISSION DE VOUS SERVIR, TRANSFORMER VOTRE VIE, VOUS AIDER À LUTTER CONTRE LE CHOMAGE, LA PAUVRETÉ, VOUS CONDUIRE A LA RÉALISATION DE VOS PROJETS DE VIE, VOUS PROPULSER AU SOMMET ET S'OCCUPER DE VOTRE BIEN ÊTRE.
          ELLE MET À LA DISPOSITION DE SES MEMBRES DES FORMATIONS EN ÉDUCATION FINANCIÈRE, DÉVELOPPEMENT PERSONNEL, SÉCURITÉ ALIMENTAIRE ET FINANCIÈRE AFIN DE LES AMENER À DEVENIR UNE AIDE POUR LA SOCIÉTÉ.
        </p>

        <hr>
        <div class="col-lg-12">
        <center><h5 style="color: blue">À PROPOS DE NOUS</h5></center>
        <img src="img/bas1.png" class="bas" style="width: 32%; height: 32%; margin-left: 33%; margin-top: -15px" ></div>
       
        
        <p style="text-align: justify;">
          La Source du Succès International est une plate-forme basée sur des formations en éducation financière, entrepreneuriat, E-commerce et des œuvres sociales. Elle est ouverte à toute personne ayant la volonté d'entreprendre; de réaliser ses projets, ses rêves et atteindre ses objectifs de vie. Elle dispose également des services comme le payement des factures d'électricité , d'eau , réabonnement CANAL+ , achat de bien meuble ou immobilier etc.
          </p>
        </div>
       
      </div>
    </div>
  </div>

  <div class="container"><div class="row"><div class="col-lg-12">
    <hr>
    <div class="col-lg-12">
          <center><h5 style="color: blue">LES FORMATIONS DISPONIBLES</h5></center>
          <img src="img/bas1.png" class="bas" style="width: 32%; height: 32%; margin-left: 33%; margin-top: -15px" ></div>
        </div>
	<nav class="navbar">
    @forelse($cours as $cour)
    
        <div class="articlepdf " >
          {{ $cour->titre}} <br> 
         <a href="article-{{$cour->id}}"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : {{ $cour->prix }} $ SSI<br></p>
         
         {{ $cour->description }}
          <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px">
          </div>
          <div>
            <a href="article-{{$cour->id}}" style="text-align: right; margin-right: 15px">PLUS >> </a>
          </div>
          </div>
    @empty
      <div class="articlepdf " >
          Bientôt disponible <br> 
         <a href="#"> <img src="img/ID-100348894.jpg" class="article_img"> </a> <br> <br>
         <p style="text-align: left; margin-left: 20px">Prix : 0 $ SSI<br></p>
         
        <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px"> Pas de description
          </div>
          </div>
    @endforelse
    </div></div></div>


	</nav>

  <br><br>

        <center><h5 style="color: blue">LES SERVICES DISPONIBLES</h5></center><br><br>
        <div class="container"><div class="row">
        <div class="col-lg-12">
        <nav class="navbar col-lg-12" >
        
	<!--
        <div >
         <a href="#"> <img src="img/soneb.jpg" class="article_img"> </a> <br><br>
         <p style="text-align: left; margin-left: 50px">SONEB<br></p>
        </div> -->

        <div >
         <a href="#"> <img src="img/canal.png" class="article_img"> </a><br><br> 
         <p style="text-align: left; margin-left: 50px">CANAL+<br></p>
        </div>
        </nav>
        </div>
        </div></div>
@endsection