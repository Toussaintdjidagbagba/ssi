@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Galerie</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">
    .articlepdf{
      background-color: rgb(255,255,255);
      text-align: center;
      width: 300px;
      max-width: 250px;
      border-radius: 3px; 
      max-height: 450px;
      margin: 5px;
      padding: 5px;
    }

    .img-galerie{
    	text-align: center;
    	width: 100%
    }
  </style>

@endsection


@section('content')
	
	<nav class="navbar">
    @forelse($images as $image)
    
        <div class="articlepdf" >
          {{ $image->image}} <br> 
          <?php 
            echo "<img src='storage/$image->path' style='width : 100%' />";  
          ?> 
        </div>
    @empty
      <div class="img-galerie" >
          Pas d'image disponible dans la galerie. <br>  
      </div>
    @endforelse

	</nav>
@endsection