@extends('layouts.template')

@section('header')
  <header class="masthead" style="background-image: url('img/img.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h2>La Source du Succès International</h2>
            <span class="subheading">Evènement</span>
          </div>
        </div>
      </div>
    </div> 
  </header>
@endsection

@section('stylesheet')

  <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <style type="text/css">
    .articlepdf{
      text-align: center;
      width: 400px;
      max-width: 250px;
      border-radius: 3px; 
      max-height: 550px;
      
      margin: 5px;
      padding: 5px;
    }

    .img-galerie{
    	text-align: center;
    	width: 100%
    }
  </style>

@endsection


@section('content')
	
	<nav class="navbar">
    @forelse($images as $image)
    
        <div class="articlepdf" >
         <i> Thème : </i> <b>{{ $image->image}}</b> <br> 
         
         <p style="text-align: left; margin-left: 20px"> <b><u> Adresse :</u></b> {{ $image->lieu }}<br></p>
         
         <p style="text-align: left; margin-left: 20px"> <b><u> Date et heure : </u></b> {{ $image->date }} à {{ $image->heure }}<br></p>
         <i>Administrateur</i> <br>
         {{ $image->description }}
          <div class="articledescription" style="text-align: left; margin-left: 15px; padding-bottom: 15px">
          </div>
        </div>
    @empty
      <div class="img-galerie" >
          Pas d'évènement prévu. <br>  
      </div>
    @endforelse

	</nav>
@endsection