@extends('layouts.template_client')

@section('content')
	   <div class="row">
         
      <div class="col-lg-12">
        <h3 class="page-header">Tableau de bord</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb ">
          <a href="{{ route('gains') }}">
        <div class="info-box brown-bg">
            <div class="count"> 
              @if(isset($gains[0]->gainvirtuel)) 
                {{ $gains[0]->gainvirtuel }} $ SSI
              @else
                0 $ SSI
              @endif
            </div>
          <div class="title">Gain Virtuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="{{ route('gains') }}">
        <div class="info-box " style="background-color: #E0B05D">
          <div class="count">
          @if(isset($gains[0]->gainespece)) 
            {{ $gains[0]->gainespece }} $ SSI
            @else
                0 $ SSI
            @endif
          </div>
          <div class="title">Gain en Espèce</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="#">
        <div class="info-box" style="background-color: #838B8B">
          <div class="count">
            
                0 $ SSI
            
          </div>
          <div class="title">Commission sur vente</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itemb">
          <a href="#">
        <div class="info-box dark-bg">
          <div class="count">
            
                0 $ SSI
            
          </div>
          <div class="title">Commission sur Trading</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-item">
          <a href="{{ route('mesfilleuls') }}">
        <div class="info-box blue-bg">
          <div class="count"> 
            @if(isset($filleuladmin[0]->nombredefilleul))
              {{$filleuladmin[0]->nombredefilleul}}
            @else
                0
            @endif
          </div>
          <div class="title">Mes Filleuls à l'Etape Actuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 at-itema">
          <a href="{{ route('regle') }}">
        <div class="info-box " style="background-color: #7AC5CD">
          <div class="count"><div style="font-size: 16px"> {{ $etape }} </div>  </div>
          <div class="title">Etape Actuel</div>
        </div>
          </a>
        <!--/.info-box-->
      </div>
      <!--/.col-->

    </div>
    <!--/.row-->
<div class="horizontal-scrollable">
    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <header class="panel-heading">
            Liste de mes filleuls
          </header>

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr style="font-size: 12px">
                <th style="text-align: center;"><i class="icon_ol"></i> Nom & Prénom Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Code de parrainage du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Identifiant du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Statut</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Parrain du Filleul</th>
                <th style="text-align: center;"><i class="icon_pin_alt"></i> Inscrire le</th>
              </tr>
              @forelse($filleuls as $filleul)
                <tr style="text-align: center;">
                  <td>{{ $filleul->nom }} {{ $filleul->prenom }}</td>
                  
                  <td>{{ $filleul->codeunique }}</td>
                  <td>{{ $filleul->codeperso}}</td>
                  <td>
                    @if($filleul->compteactive == "oui")
                        <i style="color: white; background-color: green">actif</i>
                    @else
                        <i style="color: white; background-color: red">inactif</i> 
                    @endif
                  </td>
                  <td>{{ $filleul->parrain }}</td>
                  <td>{{ $filleul->created_at}}</td>
                </tr>
              @empty
                <tr >
                  <td colspan="6" style="text-align: center;">Pas de Filleul disponible!!!</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>
</div>
@endsection