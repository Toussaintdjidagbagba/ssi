@extends('layouts.template_client')

@section('content')
	<div class="row"> 
      <div class="col-lg-12">
        <h3 class="page-header">Règle du MLM</h3>
        <ol class="breadcrumb">
          <li><i class="fa fa-home"></i></li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <section class="panel">
          <!--<header class="panel-heading">
            Advanced Table
          </header>-->

          <table class="table table-striped table-advance table-hover">
            <tbody>
              <tr>
                <th><i class="icon_ol"></i> id </th>
                <th><i class="icon_pin_alt"></i> Titre Formation </th>
                <th><i class="icon_pin_alt"></i> Document</th>
                <th style="text-align: center !important;"><i class="icon_cogs"></i> Action</th>
              </tr>
              @forelse($formations as $formation)
                  <tr>
                    <td>{{ $formation->id }}</td>
                    <td>{{ $formation->titre }}</td>
                    <td>{{ $formation->doc }}</td>
                    <td style="text-align: center !important;">
                        <form action="{{ route('formationS') }}" method="post">
                            {{ csrf_field() }}
                            <input type="hidden" value="{{ $formation->id }}" name="id" />
                            <input type="submit"  style="margin-right: 20px; background-color: blue; color: #fff;" value="SUPPRIMER" />
                        </form>
                    </td>
                </tr>
              @empty
                <tr >
                  <td colspan="4" style="text-align: center;">Pas de cours disponible.</td>
                </tr>
              @endforelse
            </tbody>
          </table>

        </section>
      </div>
    </div>
    
    <!--/.row-->

@endsection