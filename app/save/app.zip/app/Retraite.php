<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Retraite extends Model
{
    //
    protected $fillable = ['nmbrfilleulerejoint', 'id_equipe','id_user'];
}
